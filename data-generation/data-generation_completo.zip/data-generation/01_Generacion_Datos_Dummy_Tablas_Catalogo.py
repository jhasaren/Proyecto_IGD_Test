# Databricks notebook source
# MAGIC %md
# MAGIC ### Generación de Datos Dummy - Tablas Catálogo
# MAGIC #### Prueba Ingeniería de Datos - Dataknow 
# MAGIC Escenario C: SALUD Y SERVICIOS MEDICOS<br />
# MAGIC Autor: John A. Sanchez | Fecha: 04/Jul/2026

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Parámetros

# COMMAND ----------

import json

# Lee configuración centralizada desde archivo JSON
# ===========================================================================
CONFIG_PATH = "./config.json"

with open(CONFIG_PATH) as f:
    cfg = json.load(f)

# Parámetros de entorno
schema_db_local = cfg["schema_db_local"]
storage_base = cfg["storage_base"]
temp_dir_csv = f"{storage_base}/data-generation/csv/temp_csv"
temp_dir_parquet = f"{storage_base}/data-generation/parquet/temp_parquet"
RANDOM_SEED = cfg["random_seed"]

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Importación de Librerías

# COMMAND ----------

# Importa lib necesarias
# ===========================================================================
from pyspark.sql.types import StructType, StructField, IntegerType, StringType
from pyspark.sql.functions import concat, lit, col
import random
from datetime import datetime, timedelta

# Inicialización de semilla y fechas de rango (leídas desde config.json)
# Nota: la semilla y las fechas en este  notebook no son utilizadas ya que se usaron dict fijos
random.seed(RANDOM_SEED)
start_date = datetime.strptime(cfg["start_date"], "%Y-%m-%d")
end_date = datetime.strptime(cfg["end_date"], "%Y-%m-%d")


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Definición de Funciones

# COMMAND ----------

# export_df_to_csv: permite exportar un csv con spark en un solo archivo
# Autor: John A. Sanchez
# ====================================================================
def export_df_to_csv(df, output_filename):
    final_file = f"{storage_base}/data-generation/csv/{output_filename}.csv"
    df.coalesce(1).write \
      .format("csv") \
      .option("header", "true") \
      .option("delimiter", ";") \
      .mode("overwrite") \
      .save(temp_dir_csv)
    files = dbutils.fs.ls(temp_dir_csv)
    csv_part_file = [f.path for f in files if f.name.endswith(".csv")][0]
    dbutils.fs.mv(csv_part_file, final_file)
    dbutils.fs.rm(temp_dir_csv, recurse=True)

# COMMAND ----------

# export_df_to_parquet: permite exportar un parquet con spark en un solo archivo
# Autor: John A. Sanchez
# ====================================================================
def export_df_to_parquet(df, output_filename):
    final_file = f"{storage_base}/data-generation/parquet/{output_filename}.parquet"
    df.coalesce(1).write \
      .format("parquet") \
      .mode("overwrite") \
      .save(temp_dir_parquet)
    files = dbutils.fs.ls(temp_dir_parquet)
    parquet_part_file = [f.path for f in files if f.name.endswith(".parquet")][0]
    dbutils.fs.mv(parquet_part_file, final_file)
    dbutils.fs.rm(temp_dir_parquet, recurse=True)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Construcción de DF

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Tabla: pais

# COMMAND ----------

# Conjunto de datos Dummy
data = [(1, "COLOMBIA"), (2, "PERU"), (3, "ECUADOR")]

# Estructura DF
schema = StructType([
    StructField("id_pais", IntegerType(), False),
    StructField("nombre", StringType(), False)
])

# Creacion del DF
df_pais = spark.createDataFrame(data, schema)

# Previsualizacion
# display(df_pais)

# COMMAND ----------

# Agrega columna con sentencia INSERT SQL Server
df_pais_sql = df_pais.withColumn(
    "insert_sql",
    concat(
        lit("INSERT INTO "),
        lit(schema_db_local), lit(".PAIS (id_pais, nombre) VALUES ("),
        col("id_pais"), lit(", '"), col("nombre"), lit("');")
    )
)

# Previsualizacion
display(df_pais_sql)

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Tabla: departamento

# COMMAND ----------

# Conjunto de datos Dummy
data = [(1, "VALLE DEL CAUCA", 1), (2, "ANTIOQUIA", 1), (3, "CALDAS", 1),
        (4, "AREQUIPA", 2), (5, "LIMA", 2), (6, "LAMBAYEQUE", 2),
        (7, "GUAYAS", 3), (8, "MANABI", 3), (9, "PICHINCHA", 3)]

# Estructura DF
schema = StructType([
    StructField("id_depto", IntegerType(), False),
    StructField("nombre", StringType(), False),
    StructField("id_pais", IntegerType(), False),
])

# Creacion del DF
df_depto = spark.createDataFrame(data, schema)

# Previsualizacion
# display(df_depto)

# COMMAND ----------

# Agrega columna con sentencia INSERT SQL Server
df_depto_sql = df_depto.withColumn(
    "insert_sql",
    concat(
        lit("INSERT INTO "),
        lit(schema_db_local), lit(".DEPARTAMENTO (id_depto, nombre, id_pais) VALUES ("),
        col("id_depto"), lit(", '"), col("nombre"), lit("', "), col("id_pais"), lit(");")
    )
)

# Previsualizacion
display(df_depto_sql)

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Tabla: ciudad

# COMMAND ----------

# Conjunto de datos Dummy
data = [(1, "CALI", 1), (2, "TULUA", 1), (3, "MEDELLIN", 2), (4, "RIONEGRO", 2), (5, "MANIZALEZ", 3), (6, "CHINCHINA", 3),
        (7, "AREQUIPA", 4), (8, "CARAVELI", 4), (9, "LIMA", 5), (10, "MIRAFLORES", 5), (11, "CHICLAYO", 6), (12, "MOTUPE", 6),
        (13, "GUAYAQUIL", 7), (14, "DURAN", 7), (15, "PORTOVIEJO", 8), (16, "MANTA", 8), (17, "MACHACHI", 9), (18, "TABACUNDO", 9),]

# Estructura DF
schema = StructType([
    StructField("id_ciudad", IntegerType(), False),
    StructField("nombre", StringType(), False),
    StructField("id_depto", IntegerType(), False),
])

# Creacion del DF
df_ciudad = spark.createDataFrame(data, schema)

# Previsualizacion
# display(df_ciudad)

# COMMAND ----------

# Agrega columna con sentencia INSERT SQL Server
df_ciudad_sql = df_ciudad.withColumn(
    "insert_sql",
    concat(
        lit("INSERT INTO "),
        lit(schema_db_local), lit(".CIUDAD (id_ciudad, nombre, id_depto) VALUES ("),
        col("id_ciudad"), lit(", '"), col("nombre"), lit("', "), col("id_depto"), lit(");")
    )
)

# Previsualizacion
display(df_ciudad_sql)

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Tabla: EPS

# COMMAND ----------

# Conjunto de datos Dummy
data = [(1, "NUEVA EPS", 1), (2, "EPS SURA", 1), (3, "EPS SANITAS", 1), (4, "SALUD TOTAL", 1),
        (5, "PACIFICO SEGUROS", 2), (6, "RIMAC SEGUROS", 2), (7, "MAPFRE", 2), (8, "SANITAS PERU", 2),
        (9, "SALUDSA", 3), (10, "BMI DEL ECUADOR", 3), (11, "BUPA ECUADOR", 3), (12, "CONFIAMED", 3),]

# Estructura DF
schema = StructType([
    StructField("id_eps", IntegerType(), False),
    StructField("nombre", StringType(), False),
    StructField("id_pais", IntegerType(), False),
])

# Creacion del DF
df_eps = spark.createDataFrame(data, schema)

# Previsualizacion
# display(df_eps)

# COMMAND ----------

# Agrega columna con sentencia INSERT SQL Server
df_eps_sql = df_eps.withColumn(
    "insert_sql",
    concat(
        lit("INSERT INTO "),
        lit(schema_db_local), lit(".EPS (id_eps, nombre, id_pais) VALUES ("),
        col("id_eps"), lit(", '"), col("nombre"), lit("', "), col("id_pais"), lit(");")
    )
)

# Previsualizacion
display(df_eps_sql)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Salida de Datos
# MAGIC
# MAGIC Exportar en CSV los archivos en el Storage

# COMMAND ----------

# Pais
export_df_to_csv(df_pais_sql, '01_PAIS')
export_df_to_parquet(df_pais_sql, '01_PAIS')

# COMMAND ----------

# Departamento
export_df_to_csv(df_depto_sql, '02_DEPARTAMENTO')
export_df_to_parquet(df_depto_sql, '02_DEPARTAMENTO')

# COMMAND ----------

# Ciudad
export_df_to_csv(df_ciudad_sql, '03_CIUDAD')
export_df_to_parquet(df_ciudad_sql, '03_CIUDAD')

# COMMAND ----------

# EPS
export_df_to_csv(df_eps_sql, '04_EPS')
export_df_to_parquet(df_eps_sql, '04_EPS')