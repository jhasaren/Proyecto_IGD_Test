# Databricks notebook source
# MAGIC %md
# MAGIC ### Generación de Datos Dummy - Tablas Maestro
# MAGIC #### Prueba Ingeniería de Datos - Dataknow 
# MAGIC Escenario C: SALUD Y SERVICIOS MEDICOS<br />
# MAGIC Autor: John A. Sanchez | Fecha: 04/Jul/2026

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Parámetros

# COMMAND ----------

import json

# Lee configuración centralizada desde archivo JSON
# ===========================================================================
CONFIG_PATH = "./config.json"

with open(CONFIG_PATH) as f:
    cfg = json.load(f)

# Parámetros de entorno
schema_db_local = cfg["schema_db_local"]
storage_base = cfg["storage_base"]
temp_dir_csv = f"{storage_base}/data-generation/csv/temp_csv"
temp_dir_parquet = f"{storage_base}/data-generation/parquet/temp_parquet"
RANDOM_SEED = cfg["random_seed"]

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Importación de Librerías

# COMMAND ----------

# Importa lib necesarias
# ===========================================================================
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType
from pyspark.sql.functions import sha2, concat_ws, concat, lit, col, monotonically_increasing_id, row_number, to_date, when
from pyspark.sql import Row
import random
from datetime import datetime, timedelta
from pyspark.sql.window import Window

# Inicialización de semilla y fechas de rango (leídas desde config.json)
random.seed(RANDOM_SEED)
start_date = datetime.strptime(cfg["start_date"], "%Y-%m-%d")
end_date = datetime.strptime(cfg["end_date"], "%Y-%m-%d")


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Definición de Funciones

# COMMAND ----------

# export_df_to_csv: permite exportar un csv con spark en un solo archivo
# Autor: John A. Sanchez
# ====================================================================
def export_df_to_csv(df, output_filename):
    final_file = f"{storage_base}/data-generation/csv/{output_filename}.csv"
    df.coalesce(1).write \
      .format("csv") \
      .option("header", "true") \
      .option("delimiter", ";") \
      .mode("overwrite") \
      .save(temp_dir_csv)
    files = dbutils.fs.ls(temp_dir_csv)
    csv_part_file = [f.path for f in files if f.name.endswith(".csv")][0]
    dbutils.fs.mv(csv_part_file, final_file)
    dbutils.fs.rm(temp_dir_csv, recurse=True)

# COMMAND ----------

# export_df_to_parquet: permite exportar un parquet con spark en un solo archivo
# Autor: John A. Sanchez
# ====================================================================
def export_df_to_parquet(df, output_filename):
    final_file = f"{storage_base}/data-generation/parquet/{output_filename}.parquet"
    df.coalesce(1).write \
      .format("parquet") \
      .mode("overwrite") \
      .save(temp_dir_parquet)
    files = dbutils.fs.ls(temp_dir_parquet)
    parquet_part_file = [f.path for f in files if f.name.endswith(".parquet")][0]
    dbutils.fs.mv(parquet_part_file, final_file)
    dbutils.fs.rm(temp_dir_parquet, recurse=True)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Construcción de DF

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Tabla: red_sedes

# COMMAND ----------

# Lee ciudades desde csv en storage separado por ;
ciudades = spark.read.option('header', True).option('delimiter', ';').option('inferSchema', True).csv(f"{storage_base}/data-generation/csv/03_CIUDAD.csv")
ciudades = ciudades.select('id_ciudad', 'nombre', 'id_depto')

# Lee paises desde csv en storage separado por ;
paises = spark.read.option('header', True).option('delimiter', ';').option('inferSchema', True).csv(f"{storage_base}/data-generation/csv/01_PAIS.csv")
paises = paises.select('id_pais', 'nombre')

# COMMAND ----------

# Definición de valores
tipos_sede = ["HOSPITAL", "CLINICA", "CENTRO MEDICO", "CENTRO DIAGNOSTICO"]
niveles_complejidad = ['ALTA', 'MEDIA', 'AMBULATORIO', 'ESPECIALIZADO']

# Cantidades requeridas
sedes_config = [
    ("HOSPITAL", "ALTA", 3),
    ("CLINICA", "MEDIA", 16),
    ("CENTRO MEDICO", "AMBULATORIO", 42),
    ("CENTRO DIAGNOSTICO", "ESPECIALIZADO", 21)
]

# COMMAND ----------

# Construccion de DF
# =====================

data = []
id_sede = 1
ciudades_list = ciudades.collect()
ciudades_count = len(ciudades_list)
idx_ciudad = 0

for tip_sede, nivel_complejidad, cantidad in sedes_config:
    for _ in range(cantidad):

        # Genera valores aleatorios
        id_ciudad, nom_ciudad, id_depto = ciudades_list[idx_ciudad % ciudades_count]
        id_pais = 1 if id_ciudad <= 6 else 2 if id_ciudad <= 12 else 3
        nom_sede = f"{nom_ciudad} Sede {random.randint(1000,9999)}"

        # Generación de capacidad de camas segun el tipo de sede
        if tip_sede == 'CENTRO MEDICO':
            cap_camas_gen = random.randint(5, 30)
            cap_camas_uci = random.randint(0, 0)
            cap_camas_cirugia = random.randint(0, 2)
            cap_camas_urg = random.randint(3, 10)
        
        if tip_sede == 'CENTRO DIAGNOSTICO':
            cap_camas_gen = random.randint(5, 20)
            cap_camas_uci = random.randint(0, 0)
            cap_camas_cirugia = random.randint(0, 0)
            cap_camas_urg = random.randint(0, 0)

        if tip_sede == 'HOSPITAL':
            cap_camas_gen = random.randint(10, 200)
            cap_camas_uci = random.randint(10, 35)
            cap_camas_cirugia = random.randint(35, 50)
            cap_camas_urg = random.randint(25, 40)
        
        if tip_sede == 'CLINICA':
            cap_camas_gen = random.randint(50, 120)
            cap_camas_uci = random.randint(0, 10)
            cap_camas_cirugia = random.randint(25, 55)
            cap_camas_urg = random.randint(35, 80)
        
        # Agrega al DF
        data.append(Row(
            id_sede=id_sede,
            nom_sede=nom_sede,
            tip_sede=tip_sede,
            id_ciudad=id_ciudad,
            id_pais=id_pais,
            cap_camas_gen=cap_camas_gen,
            cap_camas_uci=cap_camas_uci,
            cap_camas_cirugia=cap_camas_cirugia,
            cap_camas_urg=cap_camas_urg,
            nivel_complejidad=nivel_complejidad
        ))
        id_sede += 1
        idx_ciudad += 1

schema = StructType([
    StructField("id_sede", IntegerType(), False),
    StructField("nom_sede", StringType(), False),
    StructField("tip_sede", StringType(), False),
    StructField("id_ciudad", IntegerType(), False),
    StructField("id_pais", IntegerType(), False),
    StructField("cap_camas_gen", IntegerType(), False),
    StructField("cap_camas_uci", IntegerType(), False),
    StructField("cap_camas_cirugia", IntegerType(), False),
    StructField("cap_camas_urg", IntegerType(), False),
    StructField("nivel_complejidad", StringType(), False)
])

# Creacion del DF
df_red_sedes = spark.createDataFrame(data, schema)

# Previsualización
# display(df_red_sedes)

# COMMAND ----------

# Agrega columna con sentencia INSERT SQL Server
df_red_sedes_sql = df_red_sedes.withColumn(
    "insert_sql",
    concat(
        lit("INSERT INTO "),
        lit(schema_db_local), lit(".RED_SEDES (id_sede, nom_sede, tip_sede, id_ciudad, id_pais, cap_camas_gen, cap_camas_uci, cap_camas_cirugia, cap_camas_urg, nivel_complejidad) VALUES ("),
        col("id_sede"), lit(", '"), col("nom_sede"), lit("', '"),
        col("tip_sede"), lit("', "), col("id_ciudad"), lit(", "), col("id_pais"), lit(", "),
        col("cap_camas_gen"), lit(", "), col("cap_camas_uci"), lit(", "),
        col("cap_camas_cirugia"), lit(", "), col("cap_camas_urg"), lit(", '"),
        col("nivel_complejidad"), lit("');")
    )
)

# Previsualización
display(df_red_sedes_sql)

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Tabla: pac_registro

# COMMAND ----------

# Carga catálogo de EPS desde Storage
eps = spark.read.option('header', True).option('delimiter', ';').option('inferSchema', True).csv(f"{storage_base}/data-generation/csv/04_EPS.csv")
eps_ids = [row.id_eps for row in eps.select('id_eps').collect()]


# COMMAND ----------

# Definición de aseguradoras y estratos
tipos_aseguradora = [
    'MEDICINA PREPAGADA', 
    'PLAN COMPLEMENTARIO',
    'COBERTURA INTERNACIONAL', 
    'POLIZA DE REEMBOLSO'
]

estratos = [1, 2, 3, 4, 5, 6]

# Tipos de documento por país
tipos_doc_col = ['CC', 'RC', 'TI', 'PA']
tipos_doc_ecu = ['CI', 'PA']
tipos_doc_peru = ['DNI', 'PA']


# COMMAND ----------

# Balanceo por ciudad: CALI 28%, AREQUIPA 18%, LIMA 20%, resto 34% igual
ciudades_list = ciudades.collect()
num_ciudades = len(ciudades_list)
total_registros = 100000

# Identifica id_ciudad de CALI, AREQUIPA y LIMA
id_cali = next(c.id_ciudad for c in ciudades_list if c.nombre.upper() == "CALI")
id_arequipa = next(c.id_ciudad for c in ciudades_list if c.nombre.upper() == "AREQUIPA")
id_lima = next(c.id_ciudad for c in ciudades_list if c.nombre.upper() == "LIMA")

# Asigna cantidades x ciudad
registros_cali = 28000
registros_arequipa = 18000
registros_lima = 20000
total_otras = 34000  # total a distribuir entre todas las demás ciudades

# Ciudades distintas a CALI, AREQUIPA y LIMA
otras_ciudades = [c for c in ciudades_list if c.id_ciudad not in (id_cali, id_arequipa, id_lima)]

# Calcula registros para otras ciudades (distribución equitativa)
registros_por_otra_ciudad = total_otras // len(otras_ciudades) if otras_ciudades else 0

# Lista balanceada de ciudades
ciudades_balanceadas = (
    [c for c in ciudades_list if c.id_ciudad == id_cali] * registros_cali +
    [c for c in ciudades_list if c.id_ciudad == id_arequipa] * registros_arequipa +
    [c for c in ciudades_list if c.id_ciudad == id_lima] * registros_lima
)
for c in otras_ciudades:
    ciudades_balanceadas += [c] * registros_por_otra_ciudad

# Completa el resto (residuo de la división) con ciudades aleatorias del grupo
resto = total_otras - (registros_por_otra_ciudad * len(otras_ciudades))
if resto > 0:
    ciudades_balanceadas += random.choices(otras_ciudades, k=resto)
    
# Balanceo de género
generos = ['M'] * int(0.65 * total_registros) + ['F'] * int(0.35 * total_registros)
random.shuffle(generos)

# Balanceo de activo
activos = ['S'] * int(0.99 * total_registros) + ['N'] * int(0.01 * total_registros)
random.shuffle(activos)

# Fechas de nacimiento balanceadas (0 a 65 años)
hoy = datetime.today()
min_fecha = hoy - timedelta(days=65*365)
fechas_nac = [min_fecha + timedelta(days=int(i*(65*365)/total_registros)) for i in range(total_registros)]
random.shuffle(fechas_nac)

data = []
for idx in range(total_registros):
    ciudad = ciudades_balanceadas[idx]
    id_ciudad = ciudad.id_ciudad
    id_depto = ciudad.id_depto
    nom_ciudad = ciudad.nombre

    # Determina país
    if id_ciudad <= 6:
        tipos_doc = tipos_doc_col
    elif id_ciudad <= 12:
        tipos_doc = tipos_doc_ecu
    else:
        tipos_doc = tipos_doc_peru

    tip_doc = random.choice(tipos_doc)
    num_doc = f"{random.randint(10000000,99999999)}"
    fec_nac = fechas_nac[idx].date()
    genero = generos[idx]
    tip_aseguradora = random.choice(tipos_aseguradora)
    id_eps = eps_ids[idx % len(eps_ids)]
    estrato_socioec = random.choice(estratos)
    fec_primer_atencion = hoy - timedelta(days=random.randint(0, 365*5)) if random.random() < 0.7 else None
    activo = activos[idx]

    data.append(Row(
        pac_id = idx+1,
        tip_doc=tip_doc,
        num_doc_hash=num_doc,
        fec_nac=fec_nac,
        genero=genero,
        id_ciudad_res=id_ciudad,
        tip_aseguradora=tip_aseguradora,
        id_eps=id_eps,
        estrato_socioec=estrato_socioec,
        fec_primer_atencion=fec_primer_atencion,
        activo=activo
    ))

schema = StructType([
    StructField("pac_id", IntegerType(), False),
    StructField("tip_doc", StringType(), False),
    StructField("num_doc_hash", StringType(), False),
    StructField("fec_nac", DateType(), False),
    StructField("genero", StringType(), False),
    StructField("id_ciudad_res", IntegerType(), False),
    StructField("tip_aseguradora", StringType(), False),
    StructField("id_eps", IntegerType(), True),
    StructField("estrato_socioec", IntegerType(), False),
    StructField("fec_primer_atencion", DateType(), True),
    StructField("activo", StringType(), False)
])

df_pac_registro = spark.createDataFrame(data, schema)

# Encripta el num_doc como hash usando sha2
df_pac_registro_enc = df_pac_registro.withColumn("num_doc_hash", sha2(col("num_doc_hash"), 256))

# previsualizacion
# display(df_pac_registro_enc)

# COMMAND ----------

# introducir errores documentados en los datos
# ==============================================

# 1. En fec_nac actualizar aleatoriamente 2500 registros con fecha 1900-01-01, y 4500 registros con fecha 2999-01-01
df_pac_registro_err = df_pac_registro_enc.withColumn(
    "fec_nac",
    when(col("pac_id") <= 2500, to_date(lit("1900-01-01")))
     .when((col("pac_id") > 45000) & (col("pac_id") <= 49500), to_date(lit("2999-01-01")))
     .otherwise(col("fec_nac"))
)


# COMMAND ----------

# Agrega columna con sentencia INSERT SQL Server
df_pac_registro_enc_sql = df_pac_registro_err.withColumn(
    "insert_sql",
    concat_ws(
        "",
        lit("INSERT INTO "),
        lit(schema_db_local), lit(".PAC_REGISTRO (pac_id, tip_doc, num_doc_hash, fec_nac, genero, id_ciudad_res, tip_aseguradora, id_eps, estrato_socioec, fec_primer_atencion, activo) VALUES ('"),
        col("pac_id"), lit("', '"),
        col("tip_doc"), lit("', '"),
        col("num_doc_hash"), lit("', '"),
        col("fec_nac"), lit("', '"),
        col("genero"), lit("', "),
        col("id_ciudad_res"), lit(", '"),
        col("tip_aseguradora"), lit("', "),
        col("id_eps"), lit(", "),
        col("estrato_socioec"), lit(", '"),
        col("fec_primer_atencion"), lit("', '"),
        col("activo"), lit("');")
    )
)

# Previsualización
display(df_pac_registro_enc_sql.limit(10))

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Tabla: med_planta

# COMMAND ----------

# definicion de especialidades
especialidades_principal = [
    "MEDICINA INTERNA", "PEDIATRIA", "CIRUGIA GENERAL", "CARDIOLOGIA", "NEUROLOGIA",
    "GINECOLOGIA", "DERMATOLOGIA", "UROLOGIA", "TRAUMATOLOGIA", "ANESTESIOLOGIA",
    "ONCOLOGIA", "PSIQUIATRIA", "OFTALMOLOGIA", "OTORRINOLARINGOLOGIA", "ENDOCRINOLOGIA"
]

especialidades_secundaria = [
    "MEDICINA FAMILIAR", "REUMATOLOGIA", "HEMATOLOGIA", "NEFROLOGIA", "GASTROENTEROLOGIA",
    "ALERGOLOGIA", "MEDICINA DEL DEPORTE", "MEDICINA NUCLEAR", "MEDICINA DEL TRABAJO", None
]

# Defincion de jornada
jornadas = ['ORDINARIA', 'TURNOS', 'MEDIO TIEMPO']


# COMMAND ----------

# Obtiene lista de id_sede
id_sedes = [row.id_sede for row in df_red_sedes.select('id_sede').collect()]

# Configuración de antigüedad, 1 año, 3 años, 5 años, mas de 5 años hasta max 10 años
antiguedades = (
    [1]*750 + [3]*600 + [5]*400 + [random.randint(6,10) for _ in range(250)]
)
random.shuffle(antiguedades)

data = []
hoy = datetime.today()

for idx in range(2000):

    # asignacion de esp aleatoriamente
    esp_principal = random.choice(especialidades_principal)
    esp_secundaria = random.choice(especialidades_secundaria)

    # asignacion aleatoria de sede
    id_sede = random.choice(id_sedes)

    # asignacion de antigudad
    antiguedad = antiguedades[idx]

    # asignacion de fecha ingreso
    fec_ingreso = (hoy - timedelta(days=antiguedad*365)).date()

    # contrato indef para los que tengan 5 años o más
    if antiguedad >= 5:
        tip_contrato = 'INDEFINIDO'
    else:
        tip_contrato = random.choice(['INDEFINIDO', 'TERMINO FIJO'])

    # asignacion aleat de jornada
    jornada = random.choice(jornadas)

    # a todos los med_planta registrados se les coloca activos
    estado_activo = 'S'

    data.append(Row(
        med_id=idx+1,
        esp_principal=esp_principal,
        esp_secundaria=esp_secundaria,
        id_sede=id_sede,
        fec_ingreso=fec_ingreso,
        tip_contrato=tip_contrato,
        jornada=jornada,
        estado_activo=estado_activo
    ))

schema = StructType([
    StructField("med_id", IntegerType(), False),
    StructField("esp_principal", StringType(), False),
    StructField("esp_secundaria", StringType(), True),
    StructField("id_sede", IntegerType(), False),
    StructField("fec_ingreso", DateType(), False),
    StructField("tip_contrato", StringType(), False),
    StructField("jornada", StringType(), False),
    StructField("estado_activo", StringType(), False)
])

df_med_planta = spark.createDataFrame(data, schema)

# display(df_med_planta)

# COMMAND ----------

display(df_med_planta)

# COMMAND ----------

# introducir errores documentados en los datos
# ==============================================

# 1. En tip_contrato actualizar a null 120 registros
df_med_planta_err = df_med_planta.withColumn(
    "tip_contrato",
    when(col("med_id") <= 120, lit(None))
     .otherwise(col("tip_contrato"))
)

# 2. En jornada actualizar a null 200 registros
df_med_planta_err = df_med_planta_err.withColumn(
    "jornada",
    when((col("med_id") > 1300) & (col("med_id") <= 1500), lit(None))
     .otherwise(col("jornada"))
)

# COMMAND ----------

# Agrega columna con sentencia INSERT SQL Server
df_med_planta_sql = df_med_planta_err.withColumn(
    "insert_sql",
    concat_ws(
        "",
        lit("INSERT INTO "),
        lit(schema_db_local), lit(".MED_PLANTA (med_id, esp_principal, esp_secundaria, id_sede, fec_ingreso, tip_contrato, jornada, estado_activo) VALUES ('"),
        col("med_id"), lit("', '"),
        col("esp_principal"), lit("', '"),
        col("esp_secundaria"), lit("', "),
        col("id_sede"), lit(", '"),
        col("fec_ingreso"), lit("', '"),
        col("tip_contrato"), lit("', '"),
        col("jornada"), lit("', '"),
        col("estado_activo"), lit("');")
    )
)

# previsualzación
display(df_med_planta_sql.limit(10))

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Salida de Datos
# MAGIC
# MAGIC Exportar en CSV los archivos en el Storage

# COMMAND ----------

# Sedes
export_df_to_csv(df_red_sedes_sql, '05_RED_SEDES')
export_df_to_parquet(df_red_sedes_sql, '05_RED_SEDES')

# COMMAND ----------

# pac_registro
export_df_to_csv(df_pac_registro_enc_sql, '06_PAC_REGISTRO')
export_df_to_parquet(df_pac_registro_enc_sql, '06_PAC_REGISTRO')

# COMMAND ----------

# med_planta
export_df_to_csv(df_med_planta_sql, '07_MED_PLANTA')
export_df_to_parquet(df_med_planta_sql, '07_MED_PLANTA')