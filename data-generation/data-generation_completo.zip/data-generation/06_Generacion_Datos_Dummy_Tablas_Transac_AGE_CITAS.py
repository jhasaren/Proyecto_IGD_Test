# Databricks notebook source
# MAGIC %md
# MAGIC ### Generación de Datos Dummy - Tablas Transaccionales
# MAGIC
# MAGIC AGE_CITAS - 1'500.000 registros
# MAGIC
# MAGIC #### Prueba Ingeniería de Datos - Dataknow 
# MAGIC Escenario C: SALUD Y SERVICIOS MEDICOS<br />
# MAGIC Autor: John A. Sanchez | Fecha: 04/Jul/2026

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Parámetros

# COMMAND ----------

import json

# Lee configuración centralizada desde archivo JSON
# ===========================================================================
CONFIG_PATH = "./config.json"

with open(CONFIG_PATH) as f:
    cfg = json.load(f)

# Parámetros de entorno
schema_db_local = cfg["schema_db_local"]
storage_base = cfg["storage_base"]
temp_dir_csv = f"{storage_base}/data-generation/csv/temp_csv"
temp_dir_parquet = f"{storage_base}/data-generation/parquet/temp_parquet"
RANDOM_SEED = cfg["random_seed"]

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Importación de Librerías

# COMMAND ----------

# Importa lib necesarias
# ===========================================================================
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType, DoubleType, TimestampType
from pyspark.sql.functions import sha2, concat_ws, concat, lit, col, monotonically_increasing_id, row_number, when
from pyspark.sql import Row
import random
from datetime import datetime, timedelta
from pyspark.sql.window import Window

# Inicialización de semilla y fechas de rango (leídas desde config.json)
random.seed(RANDOM_SEED)
start_date = datetime.strptime(cfg["start_date"], "%Y-%m-%d")
end_date = datetime.strptime(cfg["end_date"], "%Y-%m-%d")


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Definición de Funciones

# COMMAND ----------

# export_df_to_csv: permite exportar un csv con spark en un solo archivo
# Autor: John A. Sanchez
# ====================================================================
def export_df_to_csv(df, output_filename):
    final_file = f"{storage_base}/data-generation/csv/{output_filename}.csv"
    df.coalesce(1).write \
      .format("csv") \
      .option("header", "true") \
      .option("delimiter", ";") \
      .mode("overwrite") \
      .save(temp_dir_csv)
    files = dbutils.fs.ls(temp_dir_csv)
    csv_part_file = [f.path for f in files if f.name.endswith(".csv")][0]
    dbutils.fs.mv(csv_part_file, final_file)
    dbutils.fs.rm(temp_dir_csv, recurse=True)

# COMMAND ----------

# export_df_to_parquet: permite exportar un parquet con spark en un solo archivo
# Autor: John A. Sanchez
# ====================================================================
def export_df_to_parquet(df, output_filename):
    final_file = f"{storage_base}/data-generation/parquet/{output_filename}.parquet"
    df.coalesce(1).write \
      .format("parquet") \
      .mode("overwrite") \
      .save(temp_dir_parquet)
    files = dbutils.fs.ls(temp_dir_parquet)
    parquet_part_file = [f.path for f in files if f.name.endswith(".parquet")][0]
    dbutils.fs.mv(parquet_part_file, final_file)
    dbutils.fs.rm(temp_dir_parquet, recurse=True)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Construcción de DF

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Tabla: age_citas

# COMMAND ----------

Generar la tabla age_citas que contiene el registro de todas las citas programadas que han sido agendadas por el usuario, se deben generar 1500000 registros. Aleatoriamente se puede seleccionar un pac_id de la tabla pac_registro. El campo med_id se debe obtener de la tabla med_planta y el id_sede es tambien obtenido de los datos de med_planta. El campo fec_agendamiento debe estar entre un rango temporal de 3 años y solo entre horarios de 8am a 4pm que es el horario en que se asignan citas. La fec_cita_programada es la fecha posterior al agendamiento puede oscilar entre 0 y 5 dias siguientes. La hora de la cita programada oscila entre 7am y 5pm. La hora de llegada del paciente puede oscilar entre 20 minutos antes de la hora de la cita programada y 10 minutos despues. La hora de inicio de la atencion oscila entre 10 minutos antes de la hora de la cita programada y 20 minutos despues. La esp_solicitada (especialidad solicitada) tambien se debe obtener de la especialidad principal del medico. El tipo de cita es 'PRIMERA VEZ' o 'CITA DE CONTROL'. El estado_cita puede obtenerse desde un diccionario con los valores  'cancelada', 'reprogramada', 'incumplida', 'atendida'. Si una cita es 'cancelada', 'reprogramada' o 'incumplida' no debe tener dato en hra_llegada_paciente ni en hra_inicio_atencion. 

la estructura de la tabla es:

-- 3.4. AGE_CITAS
CREATE TABLE dbo.AGE_CITAS (
    id_cita INTEGER IDENTITY(1,1) PRIMARY KEY,
    pac_id INTEGER NOT NULL,
    med_id INTEGER NOT NULL,
    id_sede INTEGER NOT NULL,
    fec_agendamiento DATETIME2(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fec_cita_programada DATE NOT NULL,
    hra_cita_programada TIME NOT NULL,
    hra_llegada_paciente TIME NULL,
    hra_inicio_atencion TIME NULL,
    esp_solicitada VARCHAR(150) NOT NULL,
    tip_cita VARCHAR(50) NOT NULL,
    estado_cita VARCHAR(30) NOT NULL,
    FOREIGN KEY (pac_id) REFERENCES PAC_REGISTRO(pac_id),
    FOREIGN KEY (med_id) REFERENCES MED_PLANTA(med_id),
    FOREIGN KEY (id_sede) REFERENCES RED_SEDES(id_sede)
);

# COMMAND ----------

# Carga pacientes desde parquet
df_pacientes = spark.read.parquet(f"{storage_base}/data-generation/parquet/06_PAC_REGISTRO.parquet")
pacientes = df_pacientes.select('pac_id').collect()

# Carga med_planta desde parquet
df_med_planta = spark.read.parquet(f"{storage_base}/data-generation/parquet/07_MED_PLANTA.parquet")
medicos = df_med_planta.select('med_id', 'id_sede', 'esp_principal').collect()

# COMMAND ----------

# Define dicc de estados de cita y tipo de cita
estados_cita = ['cancelada', 'reprogramada', 'incumplida', 'atendida']
tipos_cita = ['PRIMERA VEZ', 'CITA DE CONTROL'] #  se usan los mismos valores que tipo_consulta en hce_encuentros

# COMMAND ----------

# Fecha de inicio y fin (rango temporal desde 3 años atrás)
# start_date = datetime(2023,7,5)
# end_date = datetime(2026,7,5)
total_days = (end_date - start_date).days


# COMMAND ----------

# Construccion de df
# ==========================

data_citas = []
total_citas = 1500000

for idx in range(total_citas):
    pac = random.choice(pacientes)
    med = random.choice(medicos)
    pac_id = pac['pac_id']
    med_id = med['med_id']
    id_sede = med['id_sede']
    esp_solicitada = med['esp_principal']

    # Fecha de agendamiento
    day_offset = random.randint(0, total_days-1)
    base_date = start_date + timedelta(days=day_offset)
    hour_agend = random.randint(8,16) # agendamiento solo entre 8am y 4pm
    minute_agend = random.randint(0,59)
    second_agend = random.randint(0,59)
    fec_agendamiento = base_date.replace(hour=hour_agend, minute=minute_agend, second=second_agend)

    # Fecha cita programada (0-5 días después)
    days_cita = random.randint(0,5)
    cita_date = fec_agendamiento.date() + timedelta(days=days_cita)
    hour_cita = random.randint(7,17)
    minute_cita = random.randint(0,59)
    second_cita = random.randint(0,59)
    hra_cita_programada = datetime(2023, 1, 1, hour_cita, minute_cita, second_cita).time()

    estado_cita = random.choice(estados_cita)
    tip_cita = random.choice(tipos_cita)

    hra_llegada_paciente = None
    hra_inicio_atencion = None

    if estado_cita == 'atendida':
        # Llegada: 20 min antes a 10 min después
        delta_llegada = random.randint(-20,10)
        llegada_dt = datetime.combine(cita_date, hra_cita_programada) + timedelta(minutes=delta_llegada)
        hra_llegada_paciente = llegada_dt.time()
        # Inicio atención: 10 min antes a 20 min después
        delta_inicio = random.randint(-10,20)
        inicio_dt = datetime.combine(cita_date, hra_cita_programada) + timedelta(minutes=delta_inicio)
        hra_inicio_atencion = inicio_dt.time()

    data_citas.append(Row(
        id_cita=idx+1,
        pac_id=pac_id,
        med_id=med_id,
        id_sede=id_sede,
        fec_agendamiento=fec_agendamiento,
        fec_cita_programada=cita_date,
        hra_cita_programada=hra_cita_programada,
        hra_llegada_paciente=hra_llegada_paciente,
        hra_inicio_atencion=hra_inicio_atencion,
        esp_solicitada=esp_solicitada,
        tip_cita=tip_cita,
        estado_cita=estado_cita
    ))

schema_citas = StructType([
    StructField("id_cita", IntegerType(), False),
    StructField("pac_id", IntegerType(), False),
    StructField("med_id", IntegerType(), False),
    StructField("id_sede", IntegerType(), False),
    StructField("fec_agendamiento", TimestampType(), False),
    StructField("fec_cita_programada", DateType(), False),
    StructField("hra_cita_programada", StringType(), False),
    StructField("hra_llegada_paciente", StringType(), True),
    StructField("hra_inicio_atencion", StringType(), True),
    StructField("esp_solicitada", StringType(), False),
    StructField("tip_cita", StringType(), False),
    StructField("estado_cita", StringType(), False)
])

df_age_citas = spark.createDataFrame(data_citas, schema_citas)


# COMMAND ----------

# Previsualización
display(df_age_citas.limit(10))

# COMMAND ----------

# introducir errores documentados en los datos
# ==============================================

# 1. En hra_inicio_atencion actualizar a valor 00:01:01 un total de 50000 registros para que queden negativos
df_age_citas_err = df_age_citas.withColumn(
    "hra_inicio_atencion",
    when((col("id_cita") > 900000) & (col("id_cita") <= 950000), lit('00:01:01'))
     .otherwise(col("hra_inicio_atencion"))
)


# COMMAND ----------

# Salida de datos en Storage - far_dispensacion
# csv
print(df_age_citas_err.count())
export_df_to_csv(df_age_citas_err, '11_AGE_CITAS')

# COMMAND ----------

# Salida de datos en Storage - far_dispensacion
# parquet
export_df_to_parquet(df_age_citas_err, '11_AGE_CITAS')