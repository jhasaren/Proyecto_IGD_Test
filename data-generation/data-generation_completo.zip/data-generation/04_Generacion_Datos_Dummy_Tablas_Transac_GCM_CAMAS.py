# Databricks notebook source
# MAGIC %md
# MAGIC ### Generación de Datos Dummy - Tablas Transaccionales
# MAGIC
# MAGIC GCM_CAMAS - 500.000 registros mínimos
# MAGIC
# MAGIC #### Prueba Ingeniería de Datos - Dataknow 
# MAGIC Escenario C: SALUD Y SERVICIOS MEDICOS<br />
# MAGIC Autor: John A. Sanchez | Fecha: 04/Jul/2026

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Parámetros

# COMMAND ----------

import json

# Lee configuración centralizada desde archivo JSON
# ===========================================================================
CONFIG_PATH = "./config.json"

with open(CONFIG_PATH) as f:
    cfg = json.load(f)

# Parámetros de entorno
schema_db_local = cfg["schema_db_local"]
storage_base = cfg["storage_base"]
temp_dir_csv = f"{storage_base}/data-generation/csv/temp_csv"
temp_dir_parquet = f"{storage_base}/data-generation/parquet/temp_parquet"
RANDOM_SEED = cfg["random_seed"]

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Importación de Librerías

# COMMAND ----------

# Importa lib necesarias
# ===========================================================================
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType, DoubleType, TimestampType
from pyspark.sql.functions import sha2, concat_ws, concat, lit, col, monotonically_increasing_id, row_number
from pyspark.sql import Row
import random
from datetime import datetime, timedelta
from pyspark.sql.window import Window

# Inicialización de semilla y fechas de rango (leídas desde config.json)
random.seed(RANDOM_SEED)
start_date = datetime.strptime(cfg["start_date"], "%Y-%m-%d")
end_date = datetime.strptime(cfg["end_date"], "%Y-%m-%d")


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Definición de Funciones

# COMMAND ----------

# export_df_to_csv: permite exportar un csv con spark en un solo archivo
# Autor: John A. Sanchez
# ====================================================================
def export_df_to_csv(df, output_filename):
    final_file = f"{storage_base}/data-generation/csv/{output_filename}.csv"
    df.coalesce(1).write \
      .format("csv") \
      .option("header", "true") \
      .option("delimiter", ";") \
      .mode("overwrite") \
      .save(temp_dir_csv)
    files = dbutils.fs.ls(temp_dir_csv)
    csv_part_file = [f.path for f in files if f.name.endswith(".csv")][0]
    dbutils.fs.mv(csv_part_file, final_file)
    dbutils.fs.rm(temp_dir_csv, recurse=True)

# COMMAND ----------

# export_df_to_parquet: permite exportar un parquet con spark en un solo archivo
# Autor: John A. Sanchez
# ====================================================================
def export_df_to_parquet(df, output_filename):
    final_file = f"{storage_base}/data-generation/parquet/{output_filename}.parquet"
    df.coalesce(1).write \
      .format("parquet") \
      .mode("overwrite") \
      .save(temp_dir_parquet)
    files = dbutils.fs.ls(temp_dir_parquet)
    parquet_part_file = [f.path for f in files if f.name.endswith(".parquet")][0]
    dbutils.fs.mv(parquet_part_file, final_file)
    dbutils.fs.rm(temp_dir_parquet, recurse=True)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Construcción de DF

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Tabla: gcm_camas

# COMMAND ----------

Generar una tabla aleatoria con minimo 500.000 registros de la disponibilidad de camas por cada una de las sedes. Cada sede reporta al menos dos veces por dia la disponibilidad en la sede de camas por cada tipo (GENERAL, UCI, CIRUGIA y URGENCIAS) teniendo en cuenta la capacidad maxima que tiene configurada cada sede (tabla RED_SEDES). La fecha hora de registro debe tener un rango temporal de 3 años. El campo motivo indisponibilidad debe estar diligenciado cuando el valor sea 0 en algun campo (se debe tener en cuenta que hay sedes donde no hay camas para ese tipo de unidad, en ese caso no debe reportar nada en el motivo de indisponibilidad.

La estructura de la tabla es la siguiente:

-- 3.2. GCM_CAMAS
CREATE TABLE dbo.GCM_CAMAS (
    id_registro_cama INTEGER IDENTITY(1,1) PRIMARY KEY,
    id_sede INTEGER NOT NULL,
    tip_unidad VARCHAR(50) NOT NULL,
    fec_hora_registro DATETIME2(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    num_camas_ocupadas INTEGER NOT NULL DEFAULT 0,
    num_camas_disp INTEGER NOT NULL DEFAULT 0,
    num_camas_mant INTEGER NOT NULL DEFAULT 0,
    motivo_indisponibilidad VARCHAR(250) NULL,
    FOREIGN KEY (id_sede) REFERENCES RED_SEDES(id_sede)
);

# COMMAND ----------

# Carga tabla RED_SEDES
df_red_sedes = spark.read.option('header', True).option('delimiter', ';').option('inferSchema', True).csv(f"{storage_base}/data-generation/csv/05_RED_SEDES.csv")
sedes = df_red_sedes.collect()


# COMMAND ----------

# Definir tipos de unidad y motivos de indisponibilidad
tipos_unidad = ['GENERAL', 'UCI', 'CIRUGIA', 'URGENCIAS']

motivos = [
    "Mantenimiento programado",
    "Falta de personal",
    "Emergencia sanitaria",
    "Reparación de equipos",
    "No disponible por demanda"
]

# COMMAND ----------

# Fecha de inicio y fin (rango temporal desde 3 años atrás)
# start_date = datetime(2023,7,5)
# end_date = datetime(2026,7,5)
total_days = (end_date - start_date).days


# COMMAND ----------

# Generación de DF
# =========================================

data_camas = []
min_registros = 800000
registros_por_sede = max(3 * total_days * len(tipos_unidad), min_registros // len(sedes))

# recorre sede x sede
for sede in sedes:

    id_sede = sede['id_sede']

    # obtiene capacidad configurada de cada sede
    capacidades = {
        'GENERAL': sede['cap_camas_gen'] if 'cap_camas_gen' in sede else 0,
        'UCI': sede['cap_camas_uci'] if 'cap_camas_uci' in sede else 0,
        'CIRUGIA': sede['cap_camas_cirugia'] if 'cap_camas_cirugia' in sede else 0,
        'URGENCIAS': sede['cap_camas_urg'] if 'cap_camas_urg' in sede else 0
    }

    for day in range(total_days):

        for rep in range(3):  # al menos 3 reportes por día

            # fecha de registro
            base_date = start_date + timedelta(days=day)
            hour = random.randint(0,23)
            minute = random.randint(0,59)
            fec_hora_registro = base_date.replace(hour=hour, minute=minute, second=random.randint(0,59))

            # para cada tipo de unidad
            for tip_unidad in tipos_unidad:

                capacidad = capacidades.get(tip_unidad, 0)
                if capacidad == 0:
                    continue  # no reportar nada si no hay camas para ese tipo en la cap max de la sede

                num_camas_mant = random.randint(0, capacidad // 10)
                num_camas_ocupadas = random.randint(0, capacidad - num_camas_mant)
                num_camas_disp = capacidad - num_camas_ocupadas - num_camas_mant
                motivo_indisponibilidad = None

                if num_camas_disp == 0 or num_camas_ocupadas == 0 or num_camas_mant == 0: # si no hay disponibilidad registra motivo
                    if num_camas_disp == 0:
                        motivo_indisponibilidad = random.choice(motivos)
                    elif num_camas_ocupadas == 0:
                        motivo_indisponibilidad = "Sin pacientes"
                    elif num_camas_mant == 0:
                        motivo_indisponibilidad = "No hay mantenimiento"

                data_camas.append(Row(
                    id_registro_cama=0, #se asigna valor 0 ya que en el cargue este es autoincremental
                    id_sede=id_sede,
                    tip_unidad=tip_unidad,
                    fec_hora_registro=fec_hora_registro,
                    num_camas_ocupadas=num_camas_ocupadas,
                    num_camas_disp=num_camas_disp,
                    num_camas_mant=num_camas_mant,
                    motivo_indisponibilidad=motivo_indisponibilidad
                ))
                if len(data_camas) >= min_registros:
                    break
            if len(data_camas) >= min_registros:
                break
        if len(data_camas) >= min_registros:
            break
    if len(data_camas) >= min_registros:
        break

schema_camas = StructType([
    StructField("id_registro_cama", IntegerType(), True),
    StructField("id_sede", IntegerType(), False),
    StructField("tip_unidad", StringType(), False),
    StructField("fec_hora_registro", TimestampType(), False),
    StructField("num_camas_ocupadas", IntegerType(), False),
    StructField("num_camas_disp", IntegerType(), False),
    StructField("num_camas_mant", IntegerType(), False),
    StructField("motivo_indisponibilidad", StringType(), True)
])

df_gcm_camas = spark.createDataFrame(data_camas, schema_camas)


# COMMAND ----------

# previsualizacion
display(df_gcm_camas.limit(10))

# COMMAND ----------

# Salida de datos en Storage - gcm_camas
# csv
print(df_gcm_camas.count())
export_df_to_csv(df_gcm_camas, '09_GCM_CAMAS')

# COMMAND ----------

# Salida de datos en Storage - gcm_camas
# parquet
export_df_to_parquet(df_gcm_camas, '09_GCM_CAMAS')