# Databricks notebook source
# MAGIC %md
# MAGIC ### Generación de Datos Dummy - Tablas Transaccionales
# MAGIC
# MAGIC FAR_DISPENSACION - 3'000.000 de registros
# MAGIC
# MAGIC #### Prueba Ingeniería de Datos - Dataknow 
# MAGIC Escenario C: SALUD Y SERVICIOS MEDICOS<br />
# MAGIC Autor: John A. Sanchez | Fecha: 04/Jul/2026

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Parámetros

# COMMAND ----------

import json

# Lee configuración centralizada desde archivo JSON
# ===========================================================================
CONFIG_PATH = "./config.json"

with open(CONFIG_PATH) as f:
    cfg = json.load(f)

# Parámetros de entorno
schema_db_local = cfg["schema_db_local"]
storage_base = cfg["storage_base"]
temp_dir_csv = f"{storage_base}/data-generation/csv/temp_csv"
temp_dir_parquet = f"{storage_base}/data-generation/parquet/temp_parquet"
RANDOM_SEED = cfg["random_seed"]

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Importación de Librerías

# COMMAND ----------

# Importa lib necesarias
# ===========================================================================
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType, DoubleType, TimestampType
from pyspark.sql.functions import sha2, concat_ws, concat, lit, col, monotonically_increasing_id, row_number
from pyspark.sql import Row
import random
from datetime import datetime, timedelta
from pyspark.sql.window import Window

# Inicialización de semilla y fechas de rango (leídas desde config.json)
random.seed(RANDOM_SEED)
start_date = datetime.strptime(cfg["start_date"], "%Y-%m-%d")
end_date = datetime.strptime(cfg["end_date"], "%Y-%m-%d")


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Definición de Funciones

# COMMAND ----------

# export_df_to_csv: permite exportar un csv con spark en un solo archivo
# Autor: John A. Sanchez
# ====================================================================
def export_df_to_csv(df, output_filename):
    final_file = f"{storage_base}/data-generation/csv/{output_filename}.csv"
    df.coalesce(1).write \
      .format("csv") \
      .option("header", "true") \
      .option("delimiter", ";") \
      .mode("overwrite") \
      .save(temp_dir_csv)
    files = dbutils.fs.ls(temp_dir_csv)
    csv_part_file = [f.path for f in files if f.name.endswith(".csv")][0]
    dbutils.fs.mv(csv_part_file, final_file)
    dbutils.fs.rm(temp_dir_csv, recurse=True)

# COMMAND ----------

# export_df_to_parquet: permite exportar un parquet con spark en un solo archivo
# Autor: John A. Sanchez
# ====================================================================
def export_df_to_parquet(df, output_filename):
    final_file = f"{storage_base}/data-generation/parquet/{output_filename}.parquet"
    df.coalesce(1).write \
      .format("parquet") \
      .mode("overwrite") \
      .save(temp_dir_parquet)
    files = dbutils.fs.ls(temp_dir_parquet)
    parquet_part_file = [f.path for f in files if f.name.endswith(".parquet")][0]
    dbutils.fs.mv(parquet_part_file, final_file)
    dbutils.fs.rm(temp_dir_parquet, recurse=True)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Construcción de DF

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Tabla: far_dispensacion

# COMMAND ----------

Generar una tabla far_dispensacion con 3000000 de registros, esta tabla contiene los registros de los medicamentos entregados al cliente para cada atencion (encuentro) es posible que para una atencion no existan medicamentos entregados o que una misma atencion tenga entre 1 y 3 registros de entrega de medicamentos. El id del encuentro viene de la tabla hce_encuentros, el pac_id es el id del paciente de la tabla pac_registro. el id_sede es el mismo que esta registrado en el encuentro. la fecha de dispensacion corresponde a la fecha en que se le entregaron los medicamentos al paciente (esta puede calcularse entre el mismo dia de la fecha de egreso del encuentro hasta 5 dias despues). El cod_medicamento y el nombre del medicamento y su valor unitario puede usarse desde un diccionario con al menos 50 distintos medicamentos. Para el campo cantidad este puede variar entre 1 y 5. El tipo de prescripcion puede ser aleatoria tambien obtenida desde un diccionario con al menos 20 tipos de prescripciones distintas entre estas debe existir 'hospitalizacion' o 'diagnósticos oncológicos en el ano'. 

La estructura de la tabla es la siguiente:

-- 3.3. FAR_DISPENSACION
CREATE TABLE dbo.FAR_DISPENSACION (
    id_dispensacion INTEGER IDENTITY(1,1) PRIMARY KEY,
    id_encuentro INTEGER NOT NULL,
    pac_id INTEGER NOT NULL,
    id_sede INTEGER NOT NULL,
    fec_dispensacion DATETIME2(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    cod_medicamento VARCHAR(50) NOT NULL,
    nom_medicamento VARCHAR(150) NOT NULL,
    cantidad INTEGER NOT NULL CHECK (cantidad > 0),
    vr_unitario DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    tip_prescripcion VARCHAR(50) NOT NULL,
    FOREIGN KEY (id_encuentro) REFERENCES HCE_ENCUENTROS(id_encuentro),
    FOREIGN KEY (pac_id) REFERENCES PAC_REGISTRO(pac_id),
    FOREIGN KEY (id_sede) REFERENCES RED_SEDES(id_sede)
);

# COMMAND ----------

# Carga encuentros desde parquet
df_hce_encuentros = spark.read.parquet(f"{storage_base}/data-generation/parquet/08_HCE_ENCUENTROS.parquet")
encuentros = df_hce_encuentros.select('id_encuentro', 'pac_id', 'id_sede', 'fec_egreso').collect()

# COMMAND ----------

# Definir dicc de medicamentos (100 distintos)
medicamentos = [
    {"cod": f"M{str(i+1).zfill(3)}", "nom": f"Medicamento_{i+1}", "vr_unitario": round(random.uniform(5, 80), 2)}
    for i in range(100)
]

# Definir dicc de tipos de prescripción (100 distintos)
tipos_prescripcion = [
    "hospitalizacion", "diagnósticos oncológicos en el ano", "tratamiento ambulatorio", "control de dolor",
    "profilaxis", "antibiótico", "antiviral", "antifúngico", "antiparasitario", "antihipertensivo",
    "antidiabético", "anticoagulante", "antidepresivo", "antipsicótico", "anticonvulsivo", "antiinflamatorio",
    "analgésico", "inmunosupresor", "inmunomodulador", "terapia biológica", "terapia hormonal",
    "terapia nutricional", "terapia física", "terapia ocupacional", "terapia respiratoria", "terapia psicológica",
    "terapia de rehabilitación", "tratamiento paliativo", "tratamiento preventivo", "tratamiento curativo",
    "tratamiento crónico", "tratamiento agudo", "tratamiento de soporte", "tratamiento de mantenimiento",
    "tratamiento de rescate", "tratamiento de emergencia", "tratamiento de seguimiento", "tratamiento de control",
    "tratamiento de sustitución", "tratamiento de inmunización", "tratamiento de desintoxicación",
    "tratamiento de desensibilización", "tratamiento de sensibilización", "tratamiento de estimulación",
    "tratamiento de supresión", "tratamiento de inhibición", "tratamiento de activación", "tratamiento de modulación",
    "tratamiento de regulación", "tratamiento de estabilización", "tratamiento de restauración",
    "tratamiento de regeneración", "tratamiento de protección", "tratamiento de prevención secundaria",
    "tratamiento de prevención terciaria", "tratamiento de prevención primaria", "tratamiento de profilaxis post-exposición",
    "tratamiento de profilaxis pre-exposición", "tratamiento de profilaxis universal", "tratamiento de profilaxis selectiva",
    "tratamiento de profilaxis específica", "tratamiento de profilaxis inespecífica", "tratamiento de profilaxis individual",
    "tratamiento de profilaxis colectiva", "tratamiento de profilaxis comunitaria", "tratamiento de profilaxis institucional",
    "tratamiento de profilaxis familiar", "tratamiento de profilaxis escolar", "tratamiento de profilaxis laboral",
    "tratamiento de profilaxis ambiental", "tratamiento de profilaxis social", "tratamiento de profilaxis cultural",
    "tratamiento de profilaxis genética", "tratamiento de profilaxis epigenética", "tratamiento de profilaxis farmacológica",
    "tratamiento de profilaxis biológica", "tratamiento de profilaxis inmunológica", "tratamiento de profilaxis nutricional",
    "tratamiento de profilaxis física", "tratamiento de profilaxis psicológica", "tratamiento de profilaxis espiritual",
    "tratamiento de profilaxis emocional", "tratamiento de profilaxis conductual", "tratamiento de profilaxis cognitiva",
    "tratamiento de profilaxis educativa", "tratamiento de profilaxis recreativa", "tratamiento de profilaxis deportiva",
    "tratamiento de profilaxis artística", "tratamiento de profilaxis tecnológica", "tratamiento de profilaxis digital",
    "tratamiento de profilaxis virtual", "tratamiento de profilaxis presencial", "tratamiento de profilaxis domiciliaria",
    "tratamiento de profilaxis ambulatoria", "tratamiento de profilaxis hospitalaria", "tratamiento de profilaxis institucionalizada",
    "tratamiento de profilaxis personalizada", "tratamiento de profilaxis grupal", "tratamiento de profilaxis masiva"
]

# COMMAND ----------

# Construccion de df
# ==========================

total_dispensaciones = 3000000
data_dispensacion = []

# Distribución de registros por encuentro
dispensaciones_por_encuentro = []
while len(dispensaciones_por_encuentro) < total_dispensaciones:
    for enc in encuentros:
        n = random.randint(0,3) # 0 a 3 registros por encuentro
        dispensaciones_por_encuentro.extend([enc]*n)
        if len(dispensaciones_por_encuentro) >= total_dispensaciones:
            break
dispensaciones_por_encuentro = dispensaciones_por_encuentro[:total_dispensaciones]

for idx, enc in enumerate(dispensaciones_por_encuentro):
    id_encuentro = enc['id_encuentro']
    pac_id = enc['pac_id']
    id_sede = enc['id_sede']
    fec_egreso = enc['fec_egreso']
    # la fec de entrega puede estar entre el mismo dia del encuentro o 5 dias despues
    fec_dispensacion = fec_egreso + timedelta(days=random.randint(0,5), hours=random.randint(0,23), minutes=random.randint(0,59), seconds=random.randint(0,59))
    med = random.choice(medicamentos)
    cod_medicamento = med['cod']
    nom_medicamento = med['nom']
    vr_unitario = med['vr_unitario']
    cantidad = random.randint(1,5)
    tip_prescripcion = random.choice(tipos_prescripcion)

    data_dispensacion.append(Row(
        id_dispensacion=idx+1,
        id_encuentro=id_encuentro,
        pac_id=pac_id,
        id_sede=id_sede,
        fec_dispensacion=fec_dispensacion,
        cod_medicamento=cod_medicamento,
        nom_medicamento=nom_medicamento,
        cantidad=cantidad,
        vr_unitario=vr_unitario,
        tip_prescripcion=tip_prescripcion
    ))

schema_dispensacion = StructType([
    StructField("id_dispensacion", IntegerType(), False),
    StructField("id_encuentro", IntegerType(), False),
    StructField("pac_id", IntegerType(), False),
    StructField("id_sede", IntegerType(), False),
    StructField("fec_dispensacion", TimestampType(), False),
    StructField("cod_medicamento", StringType(), False),
    StructField("nom_medicamento", StringType(), False),
    StructField("cantidad", IntegerType(), False),
    StructField("vr_unitario", DoubleType(), False),
    StructField("tip_prescripcion", StringType(), False)
])

df_far_dispensacion = spark.createDataFrame(data_dispensacion, schema_dispensacion)


# COMMAND ----------

# Previsualización
display(df_far_dispensacion.limit(10))

# COMMAND ----------

# Salida de datos en Storage - far_dispensacion
# csv
print(df_far_dispensacion.count())
export_df_to_csv(df_far_dispensacion, '10_FAR_DISPENSACION')

# COMMAND ----------

# Salida de datos en Storage - far_dispensacion
# parquet
export_df_to_parquet(df_far_dispensacion, '10_FAR_DISPENSACION')