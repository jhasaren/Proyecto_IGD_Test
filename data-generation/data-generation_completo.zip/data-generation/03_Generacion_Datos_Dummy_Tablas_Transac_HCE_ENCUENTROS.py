# Databricks notebook source
# MAGIC %md
# MAGIC ### Generación de Datos Dummy - Tablas Transaccionales
# MAGIC
# MAGIC HCE_ENCUENTROS - 2'000.000 de registros
# MAGIC
# MAGIC #### Prueba Ingeniería de Datos - Dataknow 
# MAGIC Escenario C: SALUD Y SERVICIOS MEDICOS<br />
# MAGIC Autor: John A. Sanchez | Fecha: 04/Jul/2026

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Parámetros

# COMMAND ----------

import json

# Lee configuración centralizada desde archivo JSON
# ===========================================================================
CONFIG_PATH = "./config.json"

with open(CONFIG_PATH) as f:
    cfg = json.load(f)

# Parámetros de entorno
schema_db_local = cfg["schema_db_local"]
storage_base = cfg["storage_base"]
temp_dir_csv = f"{storage_base}/data-generation/csv/temp_csv"
temp_dir_parquet = f"{storage_base}/data-generation/parquet/temp_parquet"
RANDOM_SEED = cfg["random_seed"]

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Importación de Librerías

# COMMAND ----------

# Importa lib necesarias
# ===========================================================================
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType, DoubleType, TimestampType
from pyspark.sql.functions import sha2, concat_ws, concat, lit, col, monotonically_increasing_id, row_number, when
from pyspark.sql import Row
import random
from datetime import datetime, timedelta
from pyspark.sql.window import Window

# Inicialización de semilla y fechas de rango (leídas desde config.json)
random.seed(RANDOM_SEED)
start_date = datetime.strptime(cfg["start_date"], "%Y-%m-%d")
end_date = datetime.strptime(cfg["end_date"], "%Y-%m-%d")


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Definición de Funciones

# COMMAND ----------

# export_df_to_csv: permite exportar un csv con spark en un solo archivo
# Autor: John A. Sanchez
# ====================================================================
def export_df_to_csv(df, output_filename):
    final_file = f"{storage_base}/data-generation/csv/{output_filename}.csv"
    df.coalesce(1).write \
      .format("csv") \
      .option("header", "true") \
      .option("delimiter", ";") \
      .mode("overwrite") \
      .save(temp_dir_csv)
    files = dbutils.fs.ls(temp_dir_csv)
    csv_part_file = [f.path for f in files if f.name.endswith(".csv")][0]
    dbutils.fs.mv(csv_part_file, final_file)
    dbutils.fs.rm(temp_dir_csv, recurse=True)

# COMMAND ----------

# export_df_to_parquet: permite exportar un parquet con spark en un solo archivo
# Autor: John A. Sanchez
# ====================================================================
def export_df_to_parquet(df, output_filename):
    final_file = f"{storage_base}/data-generation/parquet/{output_filename}.parquet"
    df.coalesce(1).write \
      .format("parquet") \
      .mode("overwrite") \
      .save(temp_dir_parquet)
    files = dbutils.fs.ls(temp_dir_parquet)
    parquet_part_file = [f.path for f in files if f.name.endswith(".parquet")][0]
    dbutils.fs.mv(parquet_part_file, final_file)
    dbutils.fs.rm(temp_dir_parquet, recurse=True)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Construcción de DF

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Tabla: hce_encuentros

# COMMAND ----------

Se necesita crear la tabla hce_encuentros con 2.000.000 de registros, en una temporalidad de 3 años. Debe asignar pacientes aleatoriamente y pueden existir pacientes con encuentros registrados de 1 a 20 veces. El med_id (medico que atiende) tambien es aleatorio y la sede del registro debe ser la misma sede que tiene el medico. En cuanto a la fecha de registro esta solo debe reportarse en un 70% en el horario laboral de 7am a 6pm, el otro 30% en el horario de 6:01pm hasta las 6:59am. La fecha de inicio de la atencion debe calcular a partir de la fecha de registro deben oscilar entre 30 y 190 minutos despues, la fecha de egreso si puede registrarse entre 5 y 10 minutos despues de la fecha de atencion. Los tipos de consulta son 'CONSULTA GENERAL', 'ESPECIALISTA', 'URGENCIAS', 'CITA DE CONTROL' las cuales tambien se deben distribuir aleatoriamente entre todos los registros de atencion. La esp_atendida debe corresponder con alguna de las dos especialidades que tiene el medico. Los diagnosticos cie10 (principal y secundario) se deben registrar aleatoriamente tomando como referencia la clasificacion CIE10 con un rango que va desde A00.0 hasta Z99.9 tambien asignado aleatoriamente. Para los codigos de procedimiento generar estos tambien aleatoriamente segun la nomenclatura CUPS de 6 digitos (capitulo va de 01 hasta 24, subgrupo de 00 a 99, y procedimiento de 01 a 99) estos tambien se deben asignar aleatoriamente y un registro puede tener entre 1 a 3 procedimientos separados por comas en el mismo campo. El valor facturado generar un valor aleatorio entre 18 dolares y 72 dolares para consulta general, especialista entre 100 dolares y 500 dolares, urgencias entre 80 dolares y 300 dolares y cita de control entre 45 dolares y 60 dolares. Los estados de las facturas son 'PAGADO', 'PENDIENTE' los cuales tambien se deben asignar un 75% pagado y 25% pendiente, asignado aleatoriamente.

La estructura de la tabla es la siguiente:

-- 3.1. HCE_ENCUENTROS
CREATE TABLE dbo.HCE_ENCUENTROS (
    id_encuentro INTEGER IDENTITY(1,1) PRIMARY KEY,
    pac_id INTEGER NOT NULL,
    med_id INTEGER NOT NULL,
    id_sede INTEGER NOT NULL,
    fec_registro DATETIME2(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fec_inicio_atencion DATETIME2(0) NULL,
    fec_egreso DATETIME2(0) NULL,
    tip_consulta VARCHAR(50) NOT NULL,
    esp_atendida VARCHAR(150) NOT NULL,
    diag_principal_cie10 VARCHAR(10) NOT NULL,
    diag_sec1_cie10 VARCHAR(10) NULL,
    cod_procedimientos VARCHAR(250) NULL,
    vr_facturado DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    estado_factura VARCHAR(30) NOT NULL,
    FOREIGN KEY (pac_id) REFERENCES PAC_REGISTRO(pac_id),
    FOREIGN KEY (med_id) REFERENCES MED_PLANTA(med_id),
    FOREIGN KEY (id_sede) REFERENCES RED_SEDES(id_sede)
);

# COMMAND ----------

# Carga pacientes
df_pac_registro = spark.read.option('header', True).option('delimiter', ';').option('inferSchema', True).csv(f"{storage_base}/data-generation/csv/06_PAC_REGISTRO.csv")
pacientes = df_pac_registro.select('pac_id').distinct().collect()

# Carga medicos
df_med_planta = spark.read.option('header', True).option('delimiter', ';').option('inferSchema', True).csv(f"{storage_base}/data-generation/csv/07_MED_PLANTA.csv")
medicos = df_med_planta.select('med_id', 'id_sede', 'esp_principal', 'esp_secundaria').collect()

# COMMAND ----------

# Definicion de tipo consulta y estado fact
tipos_consulta = ['PRIMERA VEZ', 'CITA DE CONTROL']
estado_factura_choices = ['PAGADO', 'PENDIENTE']


# COMMAND ----------

# Rangos para creacion de CIE10
cie10_letras = [chr(i) for i in range(ord('A'), ord('Z')+1)]
cie10_nums = [f"{i:02d}" for i in range(0,100)]
cie10_sub = [str(i) for i in range(0,10)]


# COMMAND ----------

# Set de funciones basicas para calculos aleatorios
# ================================================

def random_cie10():
    letra = random.choice(cie10_letras)
    num = random.randint(0,99)
    sub = random.randint(0,9)
    return f"{letra}{num:02d}.{sub}"

def random_cups():
    capitulo = random.randint(1,24)
    subgrupo = random.randint(0,99)
    procedimiento = random.randint(1,99)
    return f"{capitulo:02d}{subgrupo:02d}{procedimiento:02d}"

def random_procedimientos():
    n = random.randint(0,3)
    return ','.join([random_cups() for _ in range(n)])

def random_vr_facturado(cod_procedimientos):
    if cod_procedimientos == '':
        return round(random.uniform(45,60),0) # tarifa base (sin proc)
    elif len(cod_procedimientos.split(',')) == 1:
        return round(random.uniform(65,100),0)
    elif len(cod_procedimientos.split(',')) == 2:
        return round(random.uniform(120,300),0)
    elif len(cod_procedimientos.split(',')) == 3:
        return round(random.uniform(150,500),0)
    elif len(cod_procedimientos.split(',')) == 0:
        return round(random.uniform(45,60),0) # tarifa base (sin proc)
    return 0.0

def random_estado_factura():
    return 'PAGADO' if random.random() < 0.75 else 'PENDIENTE'

# COMMAND ----------

# Fecha de inicio y fin (rango temporal desde 3 años atrás)
# start_date = datetime(2023,7,5)
# end_date = datetime(2026,7,5)
total_days = (end_date - start_date).days


# COMMAND ----------

# Generación de DF
# =========================================

data = []
encuentros_count = 2000000

# Distribución de encuentros por paciente
pacientes_encuentros = []
while len(pacientes_encuentros) < encuentros_count:
    for pac in pacientes:
        n = random.randint(1,20) # un paciente puede tener entre 1 y 20 registros en encuentros
        pacientes_encuentros.extend([pac['pac_id']]*n)
        if len(pacientes_encuentros) >= encuentros_count:
            break
pacientes_encuentros = pacientes_encuentros[:encuentros_count]


for idx in range(encuentros_count):
    # asignacion de valores
    pac_id = pacientes_encuentros[idx]
    med = random.choice(medicos)
    med_id = med['med_id']
    id_sede = med['id_sede']
    esp_atendida = random.choice([med['esp_principal'], med['esp_secundaria']])
    tip_consulta = random.choice(tipos_consulta)
    diag_principal_cie10 = random_cie10()
    diag_sec1_cie10 = random_cie10()
    cod_procedimientos = random_procedimientos()
    vr_facturado = random_vr_facturado(cod_procedimientos) # de acuerdo a la cant de proc
    estado_factura = random_estado_factura()

    # Fecha de registro
    day_offset = random.randint(0, total_days-1)
    base_date = start_date + timedelta(days=day_offset)
    if random.random() < 0.7: # 70% en horario lab entre 7 y 6pm, y 30% por fuera de ese horario
        hour = random.randint(7,18)
        minute = random.randint(0,59)
    else:
        hour = random.choice(list(range(19,24)) + list(range(0,7)))
        minute = random.randint(0,59)
    fec_registro = base_date.replace(hour=hour, minute=minute, second=random.randint(0,59))

    # Fecha inicio atención, aleat entre 30-190 min después de la fecha registro
    fec_inicio_atencion = fec_registro + timedelta(minutes=random.randint(30,190))

    # Fecha egreso, aleat 20-240 min después de la fecha en que inicio la atencion
    fec_egreso = fec_inicio_atencion + timedelta(minutes=random.randint(20,180))

    data.append(Row(
        id_encuentro = idx+1,
        pac_id=pac_id,
        med_id=med_id,
        id_sede=id_sede,
        fec_registro=fec_registro,
        fec_inicio_atencion=fec_inicio_atencion,
        fec_egreso=fec_egreso,
        tip_consulta=tip_consulta,
        esp_atendida=esp_atendida,
        diag_principal_cie10=diag_principal_cie10,
        diag_sec1_cie10=diag_sec1_cie10,
        cod_procedimientos=cod_procedimientos,
        vr_facturado=vr_facturado,
        estado_factura=estado_factura
    ))

schema = StructType([
    StructField("id_encuentro", IntegerType(), False),
    StructField("pac_id", IntegerType(), False),
    StructField("med_id", IntegerType(), False),
    StructField("id_sede", IntegerType(), False),
    StructField("fec_registro", TimestampType(), False),
    StructField("fec_inicio_atencion", TimestampType(), True),
    StructField("fec_egreso", TimestampType(), True),
    StructField("tip_consulta", StringType(), False),
    StructField("esp_atendida", StringType(), True), #recibe vacios
    StructField("diag_principal_cie10", StringType(), False),
    StructField("diag_sec1_cie10", StringType(), True), #recibe vacios
    StructField("cod_procedimientos", StringType(), True),
    StructField("vr_facturado", DoubleType(), False),
    StructField("estado_factura", StringType(), False)
])

df_hce_encuentros = spark.createDataFrame(data, schema)


# COMMAND ----------

# Previsualización
display(df_hce_encuentros.limit(10))

# COMMAND ----------

# introducir errores documentados en los datos
# ==============================================

# 1. En diag_principal_cie10 actualizar a valor NANANA un total de 3000 registros
df_hce_encuentros_err = df_hce_encuentros.withColumn(
    "diag_principal_cie10",
    when((col("id_encuentro") > 150000) & (col("id_encuentro") <= 153000), lit('NANANA'))
     .otherwise(col("diag_principal_cie10"))
)

# 2. En diag_principal_cie10 actualizar a valor XXXXXX un total de 3000 registros
df_hce_encuentros_err = df_hce_encuentros_err.withColumn(
    "diag_principal_cie10",
    when((col("id_encuentro") > 550000) & (col("id_encuentro") <= 553000), lit('XXXXXX'))
     .otherwise(col("diag_principal_cie10"))
)

# 3. En vr_facturado actualizar a valor 0 un total de 5000 registros
df_hce_encuentros_err = df_hce_encuentros_err.withColumn(
    "vr_facturado",
    when((col("id_encuentro") > 950000) & (col("id_encuentro") <= 955000), lit(0))
     .otherwise(col("vr_facturado"))
)


# COMMAND ----------

# Salida de datos en Storage - hce_encuentros
# csv
print(df_hce_encuentros_err.count())
export_df_to_csv(df_hce_encuentros_err, '08_HCE_ENCUENTROS')

# COMMAND ----------

# Salida de datos en Storage - hce_encuentros
# parquet
export_df_to_parquet(df_hce_encuentros_err, '08_HCE_ENCUENTROS')

# COMMAND ----------

# Agrega columna con sentencia INSERT SQL Server
# Nota: por el volumen de datos, no se genera la  columna del insert manual.
# df_hce_encuentros_sql = df_hce_encuentros.withColumn(
#     "insert_sql",
#     concat(
#         lit("INSERT INTO "),
#         lit(schema_db_local), lit(".HCE_ENCUENTROS (id_encuentro, pac_id, med_id, id_sede, fec_registro, fec_inicio_atencion, fec_egreso, tip_consulta, esp_atendida, diag_principal_cie10, diag_sec1_cie10, cod_procedimientos, vr_facturado, estado_factura) VALUES ("),
#         col("id_encuentro"), lit(", "), col("pac_id"), lit(", "), col("med_id"), lit(", "),
#         col("id_sede"), lit(", '"), col("fec_registro"), lit("', '"),
#         col("fec_inicio_atencion"), lit("', '"),
#         col("fec_egreso"), lit("', '"),
#         col("tip_consulta"), lit("', '"),
#         col("esp_atendida"), lit("', '"),
#         col("diag_principal_cie10"), lit("', '"),
#         col("diag_sec1_cie10"), lit(", '"),
#         col("cod_procedimientos"), lit("', "),
#         col("vr_facturado"), lit(", '"),
#         col("estado_factura"), lit("');")
#     )
# )

# # Previsualización
# display(df_hce_encuentros_sql)