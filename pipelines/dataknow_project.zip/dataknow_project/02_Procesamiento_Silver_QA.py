# Databricks notebook source
# MAGIC %md
# MAGIC ### Evaluaciones de Calidad (Silver)
# MAGIC #### Prueba Ingeniería de Datos - Dataknow 
# MAGIC
# MAGIC En este script se realizan una serie de evaluaciones de calidad sobre las entidades creadas en Silver. Se reutiliza clase de validaciones preparada para ejecuciones genéricas.
# MAGIC
# MAGIC Escenario C: SALUD Y SERVICIOS MEDICOS<br />
# MAGIC Autor: John A. Sanchez | Fecha: 06/Jul/2026

# COMMAND ----------

# Reinicia el entorno de ejecucion
dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Importación de Librerías

# COMMAND ----------

# ============================================================
# Importa lib necesarias
# ============================================================
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, LongType, TimestampType
from pyspark.sql.functions import concat, lit, col, upper, date_format, floor, months_between, current_timestamp, when, array, array_remove, size, concat_ws, unix_timestamp
from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
import pytz
import json
from delta.tables import DeltaTable


# COMMAND ----------

# MAGIC %md
# MAGIC #### Parámetros

# COMMAND ----------

# ============================================================
# Parámetros de entorno
# ============================================================

# Zona silver
storage_base_silver = 'abfss://silver@dataknowdevdl.dfs.core.windows.net'

# Fecha Actual
tzInfo = pytz.timezone('America/Bogota')
fecha_calc = datetime.now(tz=tzInfo) - relativedelta(days=0)

fecha_hoy = fecha_calc.strftime("%Y-%m-%d")
fecha_hoy_anio = fecha_calc.strftime("%Y")
fecha_hoy_mes = fecha_calc.strftime("%m")
fecha_hoy_dia = fecha_calc.strftime("%d")

print("Hoy: ", fecha_hoy)
print("Anio: ", fecha_hoy_anio)
print("Mes: ", fecha_hoy_mes)
print("Dia: ", fecha_hoy_dia)


# COMMAND ----------

# Widgets para parametrizar el periodo de validación
dbutils.widgets.text("fecha_inicio", "", "Fecha Inicio (YYYY-MM-DD)")
dbutils.widgets.text("fecha_fin", "", "Fecha Fin (YYYY-MM-DD)")

# Resolver parámetros Widgets
fecha_inicio = dbutils.widgets.get("fecha_inicio").strip()
fecha_fin = dbutils.widgets.get("fecha_fin").strip()

# Si no se especifican fechas (NA o vacío), calcula fechas de últimos 5 días
if fecha_inicio in ('NA', '') or fecha_fin in ('NA', ''):
    ahora = datetime.now(tz=tzInfo)
    fecha_fin = (ahora - timedelta(days=1)).strftime("%Y-%m-%d 23:59:59")
    fecha_inicio = (ahora - timedelta(days=5)).strftime("%Y-%m-%d 00:00:00")
else:
    # ============================================================
    # Validación de fechas explícitas
    # Fuerza fallo del pipeline si parámetros son inválidos
    # ============================================================
    # --- fecha_inicio ---
    try:
        _dt_inicio = datetime.strptime(fecha_inicio, '%Y-%m-%d')
    except ValueError:
        raise ValueError(
            f"[QA - Parámetros] 'fecha_inicio' inválida: '{fecha_inicio}'. "
            f"Formato esperado: YYYY-MM-DD"
        )
    # comparacion de campo formateado vs original
    if _dt_inicio.strftime('%Y-%m-%d') != fecha_inicio:
        raise ValueError(
            f"[QA - Parámetros] 'fecha_inicio' con formato incorrecto: '{fecha_inicio}'. "
            f"Mes y día deben tener dos dígitos - esperado: {_dt_inicio.strftime('%Y-%m-%d')}"
        )

    # --- fecha_fin ---
    try:
        _dt_fin = datetime.strptime(fecha_fin, '%Y-%m-%d')
    except ValueError:
        raise ValueError(
            f"[QA - Parámetros] 'fecha_fin' inválida: '{fecha_fin}'. "
            f"Formato esperado: YYYY-MM-DD"
        )
    # comparacion de campo formateado vs original
    if _dt_fin.strftime('%Y-%m-%d') != fecha_fin:
        raise ValueError(
            f"[QA - Parámetros] 'fecha_fin' con formato incorrecto: '{fecha_fin}'. "
            f"Mes y día deben tener dos dígitos - esperado: {_dt_fin.strftime('%Y-%m-%d')}"
        )

    if _dt_inicio > _dt_fin:
        raise ValueError(
            f"[QA - Parámetros] fecha_inicio ({fecha_inicio}) no puede ser "
            f"mayor que fecha_fin ({fecha_fin})."
        )

    fecha_inicio = f"{fecha_inicio} 00:00:00"
    fecha_fin    = f"{fecha_fin} 23:59:59"

print(f"Período: {fecha_inicio} -> {fecha_fin}")

# COMMAND ----------

# ============================================================
# ID de ejecución QA: único por sesión (formato: yyyyMMdd_HHmmss)
# Se genera una sola vez y se reutiliza en todos los registros
# ============================================================
id_ejecucion = datetime.now(tz=tzInfo).strftime("%Y%m%d_%H%M%S")
print(id_ejecucion)


# COMMAND ----------

# MAGIC %md
# MAGIC #### Definición de Funciones

# COMMAND ----------

# MAGIC %md
# MAGIC Reutilización de clase base para evaluación de QA

# COMMAND ----------

class DataQAEngineer:
    """
    Clase: DataQAEngineer
    Autor: John A. Sanchez
    Versión: 1.0
    Fecha: 02/Dic/2025

    Descripción:
        Clase utilitaria para realizar evaluaciones de calidad de datos sobre entidades Silver y Gold.
        Implementa funciones para validar integridad referencial, completitud, oportunidad y registrar resultados QA.

    Métodos:
        - check_integridad_referencial: Valida si los valores de un campo en df_eval existen en df_dim.
        - check_completitud: Valida que los campos obligatorios o criticos no tengan valores nulos.
        - check_oportunidad: Valida la frescura del dato por registro (row-level). Para tablas maestro/catálogo de carga full.
        - check_oportunidad_transaccional: Valida la oportunidad de tablas transaccionales (carga incremental). Obtiene el MAX del campo de fecha y lo evalúa contra el timestamp actual. Retorna un DataFrame de UNA FILA.
        - registrar_resultado_qa: Registra el resultado de una validación en el DataFrame Maestro de QA.
    """

    # ============================================================
    # Función: check_integridad_referencial
    # Valida si los valores de un campo en df_eval existen en df_dim.
    # Utiliza left join: los registros sin match quedan con clave nula.
    # Retorna df_eval con la columna QA_VALIDACION_REF agregada.
    # ============================================================
    def check_integridad_referencial(df_eval, df_dim, col_eval, col_dim=None, nombre_dim="dimension"):
        """
        Valida la integridad referencial entre un DataFrame evaluado y una dimensión.

        Parámetros:
            df_eval   : DataFrame a evaluar (hechos, transaccional u otra entidad)
            df_dim    : DataFrame dimensional de referencia
            col_eval  : Campo en df_eval que referencia la dimensión
            col_dim   : Campo llave en df_dim (si es None, usa col_eval)
            nombre_dim: Nombre descriptivo de la dimensión para el mensaje de error

        Retorna:
            DataFrame con columna 'QA_VALIDACION_REF':
                'OK'          -> el valor existe en la dimensión
                'ERROR: ...'  -> el valor no fue encontrado en la dimensión
        """
        if col_dim is None:
            col_dim = col_eval

        df_keys = df_dim.select(col(col_dim).alias("ref_key")).distinct()
        df_joined = df_eval.join(df_keys, df_eval[col_eval] == col("ref_key"), "left")
        df_result = df_joined.withColumn(
            "QA_VALIDACION_REF",
            when(
                col("ref_key").isNull(),
                concat(
                    lit(f"ERROR: {col_eval}='"),
                    col(col_eval).cast("string"),
                    lit(f"' no existe en [{nombre_dim}]")
                )
            ).otherwise(lit("OK"))
        ).drop("ref_key")
        return df_result

    # ============================================================
    # Función: check_completitud
    # Valida que los campos obligatorios no tengan valores nulos.
    # Retorna df_eval con la columna QA_VALIDACION_COMP agregada.
    # ============================================================
    def check_completitud(df_eval, cols_obligatorias):
        """
        Valida que las columnas obligatorias no contengan valores nulos.

        Parámetros:
            df_eval           : DataFrame a evaluar
            cols_obligatorias : Lista de columnas que no deben ser nulas

        Retorna:
            DataFrame con columna 'QA_VALIDACION_COMP':
                'OK'         -> ningún campo obligatorio es nulo
                'ERROR: ...' -> lista de campos que contienen valor nulo
        """
        flags = array(*[
            when(col(c).isNull(), lit(c)).otherwise(lit(""))
            for c in cols_obligatorias
        ])
        campos_nulos = array_remove(flags, "")
        df_result = df_eval.withColumn(
            "QA_VALIDACION_COMP",
            when(
                size(campos_nulos) > 0,
                concat(
                    lit("ERROR: campos nulos: ["),
                    concat_ws(", ", campos_nulos),
                    lit("]")
                )
            ).otherwise(lit("OK"))
        )
        return df_result

    # ============================================================
    # Función: check_oportunidad_maestro
    # Valida la frescura del dato comparando un campo de fecha
    # contra el timestamp actual. Si la diferencia supera el
    # umbral en horas, el registro se marca como ERROR.
    # ============================================================
    def check_oportunidad_maestro(df_eval, col_fecha, umbral_horas=48):
        """
        Valida la oportunidad/frescura del dato por registro.

        Parámetros:
            df_eval      : DataFrame a evaluar
            col_fecha    : Campo de fecha/timestamp a evaluar
            umbral_horas : Umbral máximo de antigüedad en horas (default: 48)

        Retorna:
            DataFrame con columna 'QA_VALIDACION_OPORT':
                'OK'         -> dato dentro del umbral de frescura
                'ERROR: ...' -> dato supera el umbral definido
        """
        horas_diff = (
            unix_timestamp(current_timestamp()) - unix_timestamp(col(col_fecha))
        ) / 3600
        df_result = df_eval.withColumn(
            "QA_VALIDACION_OPORT",
            when(
                col(col_fecha).isNull(),
                lit(f"ERROR: [{col_fecha}] es nulo - no se puede evaluar oportunidad")
            ).when(
                horas_diff > umbral_horas,
                concat(
                    lit(f"ERROR: [{col_fecha}] supera umbral de {umbral_horas}h - desactualizado hace "),
                    horas_diff.cast("integer").cast("string"),
                    lit(" horas")
                )
            ).otherwise(lit("OK"))
        )
        return df_result

    # ============================================================
    # Función: check_oportunidad_transaccional
    # Para tablas con carga incremental (delta). Obtiene el MAX
    # del campo de fecha y lo evalúa contra el timestamp actual.
    # Retorna un DataFrame de UNA FILA con el resultado global.
    # No evalúa fila a fila — evita falsos positivos en registros
    # históricos de tablas con múltiples valores de fecha.
    # ============================================================
    def check_oportunidad_transaccional(df_eval, col_fecha, umbral_horas=48):
        """
        Valida la oportunidad de tablas transaccionales con carga incremental.

        A diferencia de check_oportunidad (row-level), evalúa el MAX del campo
        de fecha de toda la tabla y retorna un DataFrame de UNA SOLA FILA con
        el veredicto global. Si el MAX supera el umbral, la tabla entera falla.

        Se usa cuando la tabla tiene múltiples valores en col_fecha (carga delta),
        donde evaluar fila a fila generaría falsos positivos en registros históricos.

        Parámetros:
            df_eval      : DataFrame transaccional a evaluar
            col_fecha    : Campo de fecha/timestamp para calcular el MAX
            umbral_horas : Umbral máximo de antigüedad en horas (default: 48)

        Retorna:
            DataFrame de UNA FILA con columna 'QA_VALIDACION_OPORT':
                'OK'         -> MAX(col_fecha) dentro del umbral
                'ERROR: ...' -> MAX(col_fecha) supera el umbral, con detalle
                               de fecha y tiempo transcurrido
        """
        from pyspark.sql.functions import max as spark_max

        row = df_eval.agg(
            spark_max(unix_timestamp(col(col_fecha))).alias("max_ts"),
            spark_max(col(col_fecha)).alias("max_fecha")
        ).first()

        if row["max_ts"] is None:
            qa_val = f"ERROR: [{col_fecha}] sin valores válidos - tabla vacía o campo completamente nulo"
        else:
            horas_diff    = (datetime.now(tz=tzInfo).timestamp() - row["max_ts"]) / 3600
            max_fecha_str = row["max_fecha"].strftime("%Y-%m-%d %H:%M")

            if horas_diff > umbral_horas:
                dias       = int(horas_diff // 24)
                horas_rem  = int(horas_diff % 24)
                tiempo_str = f"{dias}d {horas_rem}h" if dias > 0 else f"{int(horas_diff)}h"
                qa_val = (
                    f"ERROR: MAX [{col_fecha}]={max_fecha_str} - "
                    f"desactualizado hace {tiempo_str} (umbral: {umbral_horas}h)"
                )
            else:
                qa_val = "OK"

        return spark.createDataFrame([{"QA_VALIDACION_OPORT": qa_val}])

    # ============================================================
    # Función: registrar_resultado_qa
    # Evalúa un df con columna _qa_validation y agrega una fila
    # de resumen al DataFrame Maestro global (df_master_qa).
    # ============================================================
    def registrar_resultado_qa(df_eval, tabla, categoria, descripcion="", zona="silver", col_qa="_qa_validation", es_tabla_nivel=False):
        """
        Registra el resultado de una validación en el DataFrame Maestro de QA.

        Parámetros:
            df_eval   : DataFrame evaluado con columna col_qa
            tabla     : Nombre descriptivo de la tabla/entidad evaluada
            categoria : Categoría ISO 25012 (usar constantes QA_*)
            descripcion: Descripción legible de la validación realizada
            zona      : Capa evaluada - 'silver' o 'gold' (default: 'silver')
            col_qa         : Campo de validación en df_eval (default: '_qa_validation')
            es_tabla_nivel : True cuando el df es un resumen de 1 fila (e.g. check_oportunidad_transaccional).
                             El campo col_qa se usa como mensaje directo en 'resultado' del maestro.

        Efecto:
            Actualiza df_master_qa global con una nueva fila de resultado.
        """
        global df_master_qa
        total   = df_eval.count()
        errores = df_eval.filter(col(col_qa) != "OK").count()
        if es_tabla_nivel:
            # Validación a nivel de tabla (check_oportunidad_transaccional u otro check de 1 fila)
            # El campo col_qa ya contiene el mensaje descriptivo del resultado
            qa_val    = df_eval.select(col(col_qa)).first()[0]
            estado    = "PASS" if errores == 0 else "FAIL"
            resultado = "Sin inconsistencias - verificación a nivel de tabla" if errores == 0 else qa_val
        elif errores == 0:
            resultado = f"Sin inconsistencias - {total} registros evaluados"
            estado    = "PASS"
        else:
            conformes = total - errores
            pct_error = round((errores / total) * 100, 1) if total > 0 else 0
            resultado = f"{errores} de {total} registros con error ({pct_error}%) - {conformes} conformes"
            estado    = "FAIL"
        nueva_fila = spark.createDataFrame(
            [(id_ejecucion, zona, tabla, categoria, descripcion, total, errores, resultado, estado,
            datetime.now(tz=tzInfo))],
            _SCHEMA_MASTER_QA
        )
        df_master_qa = df_master_qa.union(nueva_fila)


# COMMAND ----------

# ============================================================
# Inicialización: Schema, Categorías ISO y Maestro QA
# ============================================================

# Definicion Categorías de Calidad de Datos — ISO 25012
QA_COMPLETITUD = "completitud" # Valores nulos o faltantes en campos obligatorios
QA_CONSISTENCIA = "consistencia" # Integridad referencial, formatos, reglas de negocio
QA_EXACTITUD = "exactitud" # Valores fuera de dominio o rango permitido
QA_UNICIDAD = "unicidad" # Registros duplicados
QA_OPORTUNIDAD = "oportunidad" # Frescura / vigencia del dato

# Definición esquema tabla maestro QA
_SCHEMA_MASTER_QA = StructType([
    StructField("ID_EJECUCION", StringType(), False),  # Identificador único de la ejecución
    StructField("ZONA_EVALUADA", StringType(), False),  # silver / gold
    StructField("TABLA_EVALUADA", StringType(), False),  # Nombre de la entidad evaluada
    StructField("CATEGORIA_CALIDAD", StringType(), False),  # Categoría ISO 25012
    StructField("DESCRIPCION", StringType(), False),  # Descripción de la validación realizada
    StructField("TOTAL_REGISTROS", LongType(), False),  # Total de registros evaluados
    StructField("REGISTROS_ERROR", LongType(), False),  # Registros que no pasaron la validación
    StructField("RESULTADO", StringType(), False),  # Descripción breve del resultado
    StructField("ESTADO", StringType(), False),  # PASS / FAIL
    StructField("F_REGISTRO", TimestampType(), False),  # Timestamp del registro
])

# DataFrame Maestro acumulador - inicia vacío con el schema definido
df_master_qa = spark.createDataFrame([], _SCHEMA_MASTER_QA)


# COMMAND ----------

# MAGIC %md
# MAGIC #### Carga Entidades Silver

# COMMAND ----------

# =================================
# leer tablas delta desde storage
# =================================

# path delta de cada tabla
pais_path = f"{storage_base_silver}/dataknow_project/entidades/pais"
depto_path = f"{storage_base_silver}/dataknow_project/entidades/departamento"
ciudad_path = f"{storage_base_silver}/dataknow_project/entidades/ciudad"
eps_path = f"{storage_base_silver}/dataknow_project/entidades/eps"
red_sedes_path = f"{storage_base_silver}/dataknow_project/entidades/red_sedes"
pac_path = f"{storage_base_silver}/dataknow_project/entidades/pac_registro"
med_path = f"{storage_base_silver}/dataknow_project/entidades/med_planta"
hce_path = f"{storage_base_silver}/dataknow_project/entidades/hce_encuentros"
camas_path = f"{storage_base_silver}/dataknow_project/entidades/gcm_camas"
far_path = f"{storage_base_silver}/dataknow_project/entidades/far_dispensacion"
citas_path = f"{storage_base_silver}/dataknow_project/entidades/age_citas"

# **** Catálogos
df_pais_delta = spark.read.format("delta").load(pais_path)
df_depto_delta = spark.read.format("delta").load(depto_path)
df_ciudad_delta = spark.read.format("delta").load(ciudad_path)
df_eps_delta = spark.read.format("delta").load(eps_path)

# **** Maestros
df_red_sedes_delta = spark.read.format("delta").load(red_sedes_path)
df_pac_delta = spark.read.format("delta").load(pac_path)
df_med_delta = spark.read.format("delta").load(med_path)

# **** Transaccionales
df_hce_delta = (
    spark.read.format("delta")
    .load(hce_path)
    .filter(
        (col("FECHA_REGISTRO") >= fecha_inicio) &
        (col("FECHA_REGISTRO") <= fecha_fin)
    )
)

df_camas_delta = (
    spark.read.format("delta")
    .load(camas_path)
    .filter(
        (col("FECHA_HORA_REGISTRO") >= fecha_inicio) &
        (col("FECHA_HORA_REGISTRO") <= fecha_fin)
    )
)

df_far_delta = (
    spark.read.format("delta")
    .load(far_path)
    .filter(
        (col("FECHA_HORA_DISPENSACION") >= fecha_inicio) &
        (col("FECHA_HORA_DISPENSACION") <= fecha_fin)
    )
)

df_citas_delta = (
    spark.read.format("delta")
    .load(citas_path)
    .filter(
        (col("FECHA_HORA_AGENDAMIENTO") >= fecha_inicio) &
        (col("FECHA_HORA_AGENDAMIENTO") <= fecha_fin)
    )
)


# COMMAND ----------

# DBTITLE 1,Sección: Validaciones de Calidad de Datos
# MAGIC %md
# MAGIC #### Validaciones de Calidad de Datos

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 1. Integridad Referencial

# COMMAND ----------

# ============================================================
# Prueba: Integridad Referencial entre entidades Silver
# ============================================================

# departamento -> pais (ID_PAIS debe existir en df_pais_delta)
df_depto_qa = DataQAEngineer.check_integridad_referencial(
    df_eval    = df_depto_delta,
    df_dim     = df_pais_delta,
    col_eval   = "ID_PAIS", # campo en departamento
    col_dim    = "ID_PAIS", # campo llave en pais (mismo nombre, opcional omitir)
    nombre_dim = "pais"
)

# ciudad -> departamento (ID_DEPTO debe existir en df_depto_delta)
df_ciudad_qa = DataQAEngineer.check_integridad_referencial(
    df_eval    = df_ciudad_delta,
    df_dim     = df_depto_delta,
    col_eval   = "ID_DEPTO",
    nombre_dim = "departamento"
)

# eps -> pais (ID_PAIS debe existir en df_pais_delta)
df_eps_qa = DataQAEngineer.check_integridad_referencial(
    df_eval    = df_eps_delta,
    df_dim     = df_pais_delta,
    col_eval   = "ID_PAIS",
    nombre_dim = "pais"
)

# sedes -> ciudad (ID_CIUDAD debe existir en df_ciudad_delta)
df_red_sedes_qa = DataQAEngineer.check_integridad_referencial(
    df_eval    = df_red_sedes_delta,
    df_dim     = df_ciudad_delta,
    col_eval   = "ID_CIUDAD",
    nombre_dim = "ciudad"
)

# med_planta -> sede (ID_SEDE debe existir en df_red_sedes_delta)
df_med_qa = DataQAEngineer.check_integridad_referencial(
    df_eval    = df_med_delta,
    df_dim     = df_red_sedes_delta,
    col_eval   = "ID_SEDE",
    nombre_dim = "sede"
)


# COMMAND ----------

# DBTITLE 1,Sección: Completitud
# MAGIC %md
# MAGIC ##### 2. Completitud - Nulos por Columna

# COMMAND ----------

# ============================================================
# Definición de columnas obligatorias por entidad
# ============================================================
COLS_PAIS = ["ID_PAIS", "NOMBRE_PAIS"]
COLS_DEPTO = ["ID_DEPTO", "NOMBRE_DEPTO", "ID_PAIS"]
COLS_CIUDAD = ["ID_CIUDAD", "NOMBRE_CIUDAD", "ID_DEPTO"]
COLS_EPS = ["ID_EPS", "NOMBRE_EPS", "ID_PAIS"]
COLS_SEDES = ["NOMBRE_SEDE", "TIPO_SEDE", "NIVEL_COMPLEJIDAD"]
COLS_PAC = ["GENERO"]
COLS_MED_PLANTA = ["ESPECIALIDAD_PRINCIPAL", "TIPO_CONTRATO"]
COLS_HCE = ["ESPECIALIDAD_ATENDIDA"]
COLS_CITAS = ["ESPECIALIDAD_SOLICITADA"]

# Aplicar check de completitud a cada entidad
df_pais_qa = DataQAEngineer.check_completitud(df_pais_delta, COLS_PAIS)
df_depto_qa = DataQAEngineer.check_completitud(df_depto_qa, COLS_DEPTO)
df_ciudad_qa = DataQAEngineer.check_completitud(df_ciudad_qa, COLS_CIUDAD)
df_eps_qa = DataQAEngineer.check_completitud(df_eps_qa, COLS_EPS)
df_red_sedes_qa = DataQAEngineer.check_completitud(df_red_sedes_qa, COLS_SEDES)
df_pac_qa = DataQAEngineer.check_completitud(df_pac_delta, COLS_PAC)
df_med_qa = DataQAEngineer.check_completitud(df_med_qa, COLS_MED_PLANTA)
df_hce_qa2 = DataQAEngineer.check_completitud(df_hce_delta, COLS_HCE)
df_citas_qa = DataQAEngineer.check_completitud(df_citas_delta, COLS_CITAS)


# COMMAND ----------

# DBTITLE 1,Sección: Oportunidad
# MAGIC %md
# MAGIC ##### 3. Oportunidad - Frescura del Dato

# COMMAND ----------

# ============================================================
# Prueba sobre entidades dimensionales Silver
# Para tablas maestro o catalogos se usa F_ACTUAL como campo de referencia de frescura.
#   Ej: check_oportunidad_maestro(df_citas, col_fecha="F_ACTUAL", umbral_horas=24)
# Para tablas transaccionales se pasa el campo de fecha propio y se utiliza otra funcion
#   Ej: check_oportunidad_transaccional(df_citas, col_fecha="FECHA_CITA", umbral_horas=24)
# ============================================================
UMBRAL_HORAS = 48

# Catálogos y Maestros
df_pais_qa = DataQAEngineer.check_oportunidad_maestro(df_pais_qa, col_fecha="F_ACTUAL", umbral_horas=UMBRAL_HORAS)
df_depto_qa = DataQAEngineer.check_oportunidad_maestro(df_depto_qa, col_fecha="F_ACTUAL", umbral_horas=UMBRAL_HORAS)
df_ciudad_qa = DataQAEngineer.check_oportunidad_maestro(df_ciudad_qa, col_fecha="F_ACTUAL", umbral_horas=UMBRAL_HORAS)
df_eps_qa = DataQAEngineer.check_oportunidad_maestro(df_eps_qa, col_fecha="F_ACTUAL", umbral_horas=UMBRAL_HORAS)
df_red_sedes_qa = DataQAEngineer.check_oportunidad_maestro(df_red_sedes_qa, col_fecha="F_ACTUAL", umbral_horas=UMBRAL_HORAS)
df_med_qa = DataQAEngineer.check_oportunidad_maestro(df_med_qa, col_fecha="F_ACTUAL", umbral_horas=UMBRAL_HORAS)

# tabla transaccional con carga incremental — se evalúa el MAX, no fila a fila
df_hce_qa = DataQAEngineer.check_oportunidad_transaccional(df_hce_delta, col_fecha="FECHA_REGISTRO", umbral_horas=UMBRAL_HORAS)
df_camas_qa = DataQAEngineer.check_oportunidad_transaccional(df_camas_delta, col_fecha="FECHA_HORA_REGISTRO", umbral_horas=UMBRAL_HORAS)
df_citas_qa2 = DataQAEngineer.check_oportunidad_transaccional(df_citas_qa, col_fecha="FECHA_HORA_AGENDAMIENTO", umbral_horas=UMBRAL_HORAS)


# COMMAND ----------

# DBTITLE 1,Sección: DataFrame Maestro de QA
# MAGIC %md
# MAGIC ##### Registro Maestro de Resultados QA

# COMMAND ----------

# ============================================================
# Registrar resultados de las validaciones ejecutadas
# ============================================================

# ***** Consistencia: integridad referencial ****

DataQAEngineer.registrar_resultado_qa(
    df_depto_qa,
    tabla="departamento",
    categoria=QA_CONSISTENCIA,
    descripcion="integridad referencial",
    col_qa="QA_VALIDACION_REF"
)

DataQAEngineer.registrar_resultado_qa(
    df_ciudad_qa, 
    tabla="ciudad", 
    categoria=QA_CONSISTENCIA, 
    descripcion="integridad referencial",
    col_qa="QA_VALIDACION_REF"
)

DataQAEngineer.registrar_resultado_qa(
    df_eps_qa, 
    tabla="eps", 
    categoria=QA_CONSISTENCIA, 
    descripcion="integridad referencial",
    col_qa="QA_VALIDACION_REF"
)

DataQAEngineer.registrar_resultado_qa(
    df_red_sedes_qa, 
    tabla="red_sedes", 
    categoria=QA_CONSISTENCIA, 
    descripcion="integridad referencial",
    col_qa="QA_VALIDACION_REF"
)

DataQAEngineer.registrar_resultado_qa(
    df_med_qa, 
    tabla="med_planta", 
    categoria=QA_CONSISTENCIA, 
    descripcion="integridad referencial",
    col_qa="QA_VALIDACION_REF"
)


# COMMAND ----------

# ============================================================
# Registrar resultados de las validaciones ejecutadas
# ============================================================

# ***** Completitud: nulos en campos criticos ****

DataQAEngineer.registrar_resultado_qa(
    df_pais_qa, 
    tabla="pais", 
    categoria=QA_COMPLETITUD, 
    descripcion="validacion de campos criticos null "+str(COLS_PAIS),
    col_qa="QA_VALIDACION_COMP"
)

DataQAEngineer.registrar_resultado_qa(
    df_depto_qa,
    tabla="departamento",
    categoria=QA_COMPLETITUD,
    descripcion="validacion de campos criticos null "+str(COLS_DEPTO),
    col_qa="QA_VALIDACION_COMP"
)

DataQAEngineer.registrar_resultado_qa(
    df_ciudad_qa,
    tabla="ciudad",
    categoria=QA_COMPLETITUD,
    descripcion="validacion de campos criticos null "+str(COLS_CIUDAD),
    col_qa="QA_VALIDACION_COMP"
)

DataQAEngineer.registrar_resultado_qa(
    df_eps_qa,
    tabla="eps",
    categoria=QA_COMPLETITUD, 
    descripcion="validacion de campos criticos null "+str(COLS_EPS),
    col_qa="QA_VALIDACION_COMP"
)

DataQAEngineer.registrar_resultado_qa(
    df_red_sedes_qa,
    tabla="red_sedes",
    categoria=QA_COMPLETITUD, 
    descripcion="validacion de campos criticos null "+str(COLS_SEDES),
    col_qa="QA_VALIDACION_COMP"
)

DataQAEngineer.registrar_resultado_qa(
    df_pac_qa,
    tabla="pac_registro",
    categoria=QA_COMPLETITUD, 
    descripcion="validacion de campos criticos null "+str(COLS_PAC),
    col_qa="QA_VALIDACION_COMP"
)

DataQAEngineer.registrar_resultado_qa(
    df_med_qa,
    tabla="med_planta",
    categoria=QA_COMPLETITUD, 
    descripcion="validacion de campos criticos null "+str(COLS_MED_PLANTA),
    col_qa="QA_VALIDACION_COMP"
)

DataQAEngineer.registrar_resultado_qa(
    df_hce_qa2,
    tabla="hce_encuentros",
    categoria=QA_COMPLETITUD, 
    descripcion="validacion de campos criticos null "+str(COLS_HCE),
    col_qa="QA_VALIDACION_COMP"
)

DataQAEngineer.registrar_resultado_qa(
    df_citas_qa,
    tabla="age_citas",
    categoria=QA_COMPLETITUD, 
    descripcion="validacion de campos criticos null "+str(COLS_CITAS),
    col_qa="QA_VALIDACION_COMP"
)


# COMMAND ----------

# ============================================================
# Registrar resultados de las validaciones ejecutadas
# ============================================================

# ***** Oportunidad: frescura o actualidad del dato ****

DataQAEngineer.registrar_resultado_qa(
    df_pais_qa,
    tabla="pais",
    categoria=QA_OPORTUNIDAD,
    descripcion="actualidad del dato - umbral 48h",
    col_qa="QA_VALIDACION_OPORT"
)

DataQAEngineer.registrar_resultado_qa(
    df_depto_qa, 
    tabla="departamento",
    categoria=QA_OPORTUNIDAD,
    descripcion="actualidad del dato - umbral 48h",
    col_qa="QA_VALIDACION_OPORT"
)

DataQAEngineer.registrar_resultado_qa(
    df_ciudad_qa,
    tabla="ciudad",
    categoria=QA_OPORTUNIDAD,
    descripcion="actualidad del dato - umbral 48h",
    col_qa="QA_VALIDACION_OPORT"
)

DataQAEngineer.registrar_resultado_qa(
    df_eps_qa,
    tabla="eps",
    categoria=QA_OPORTUNIDAD,
    descripcion="actualidad del dato - umbral 48h",
    col_qa="QA_VALIDACION_OPORT"
)

DataQAEngineer.registrar_resultado_qa(
    df_red_sedes_qa,
    tabla="red_sedes",
    categoria=QA_OPORTUNIDAD,
    descripcion="actualidad del dato - umbral 48h",
    col_qa="QA_VALIDACION_OPORT"
)

DataQAEngineer.registrar_resultado_qa(
    df_med_qa,
    tabla="med_planta",
    categoria=QA_OPORTUNIDAD,
    descripcion="actualidad del dato - umbral 48h",
    col_qa="QA_VALIDACION_OPORT"
)

# Tabla transaccional, se debe enviar el parametro es_tabla_nivel=True
DataQAEngineer.registrar_resultado_qa(
    df_camas_qa, 
    tabla="gcm_camas", 
    categoria=QA_OPORTUNIDAD,
    descripcion="actualidad del dato - umbral 48h - transaccional",
    col_qa="QA_VALIDACION_OPORT", 
    es_tabla_nivel=True
)

# Tabla transaccional, se debe enviar el parametro es_tabla_nivel=True
DataQAEngineer.registrar_resultado_qa(
    df_hce_qa, 
    tabla="hce_encuentros", 
    categoria=QA_OPORTUNIDAD,
    descripcion="actualidad del dato - umbral 48h - transaccional",
    col_qa="QA_VALIDACION_OPORT", 
    es_tabla_nivel=True
)

# Tabla transaccional, se debe enviar el parametro es_tabla_nivel=True
DataQAEngineer.registrar_resultado_qa(
    df_citas_qa2, 
    tabla="age_citas", 
    categoria=QA_OPORTUNIDAD,
    descripcion="actualidad del dato - umbral 48h - transaccional",
    col_qa="QA_VALIDACION_OPORT", 
    es_tabla_nivel=True
)


# COMMAND ----------

# ============================================================
# Registrar resultados de las validaciones ejecutadas
# ============================================================

# ***** Exactitud: Valores fuera de dominio o rango permitido ****

DataQAEngineer.registrar_resultado_qa(
    df_pac_qa,
    tabla="pac_registro",
    categoria=QA_EXACTITUD,
    descripcion="valor de edad en rango anormal",
    col_qa="QA_EDAD"
)

DataQAEngineer.registrar_resultado_qa(
    df_med_qa,
    tabla="med_planta",
    categoria=QA_EXACTITUD,
    descripcion="sin jornada laboral",
    col_qa="QA_JORNADA_LABORAL"
)

DataQAEngineer.registrar_resultado_qa(
    df_hce_qa2,
    tabla="hce_encuentros",
    categoria=QA_EXACTITUD,
    descripcion="anomalia en diagnostico ppal CIE10",
    col_qa="QA_DIAGNOSTICO_PPAL_CIE10"
)

DataQAEngineer.registrar_resultado_qa(
    df_hce_qa2,
    tabla="hce_encuentros",
    categoria=QA_EXACTITUD,
    descripcion="valor facturado menor a 0",
    col_qa="QA_VALOR_FACTURADO_USD"
)

DataQAEngineer.registrar_resultado_qa(
    df_citas_qa,
    tabla="age_citas",
    categoria=QA_EXACTITUD,
    descripcion="hora inicio atencion invalido",
    col_qa="QA_HORA_INICIO_ATENCION"
)


# COMMAND ----------

# Reporte Maestro de QA
display(df_master_qa)

# COMMAND ----------

# DBTITLE 1,Sección: Persistencia Maestro QA
# MAGIC %md
# MAGIC #### Persistencia del Maestro QA
# MAGIC Escritura en Delta con modo append - cada ejecución acumula su resultado en el histórico.

# COMMAND ----------

# ============================================================
# Resumen de la ejecución actual
# ============================================================

SEP = "=" * 65
SEP2 = "-" * 65

n_exec_total = df_master_qa.count()
n_exec_pass  = df_master_qa.filter(col("ESTADO") == "PASS").count()
n_exec_fail  = df_master_qa.filter(col("ESTADO") == "FAIL").count()

print(f"\n{SEP}")
print(f"  REPORTE DE EJECUCION QA")
print(f"  ID Ejecucion : {id_ejecucion}")
print(f"  Zona         : silver")
print(f"  Fecha / Hora : {datetime.now(tz=tzInfo).strftime('%Y-%m-%d %H:%M:%S')}")
print(f"{SEP}")
print(f"  Total validaciones ejecutadas : {n_exec_total}")
print(f"  PASS                          : {n_exec_pass}")
print(f"  FAIL                          : {n_exec_fail}")
print(f"{SEP}")
print(f"  DETALLE POR VALIDACION")
print(f"{SEP}")

for row in df_master_qa.orderBy("CATEGORIA_CALIDAD", "TABLA_EVALUADA").collect():
    estado_label = "PASS" if row["ESTADO"] == "PASS" else "FAIL <<"
    print(f"\n  [{estado_label}]  {row['TABLA_EVALUADA']} | {row['CATEGORIA_CALIDAD']}")
    print(f"  {SEP2}")
    print(f"  Descripcion : {row['DESCRIPCION']}")
    print(f"  Resultado   : {row['RESULTADO']}")
    print(f"  Registros   : total={row['TOTAL_REGISTROS']}  errores={row['REGISTROS_ERROR']}")
    print(f"  Timestamp   : {row['F_REGISTRO']}")

print(f"\n{SEP}\n")

# ============================================================
# Persistencia del Maestro QA en tabla Delta
# Modo APPEND: cada ejecución agrega sus filas al histórico.
# ============================================================

path_maestro_qa = f"{storage_base_silver}/dataknow_project/qa/maestro_qa"

(
    df_master_qa
    .write
    .format("delta")
    .mode("append")
    .save(path_maestro_qa)
)


# display(df_historial_qa.orderBy(col("f_registro").desc()))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Actualización de entidades
# MAGIC Merge de los datos con las marcaciones de QA en entidades delta

# COMMAND ----------

# habilita autoMerge en tablas delta
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

# COMMAND ----------

# pais
DeltaTable.forPath(spark, pais_path).alias("base").merge(
    source = df_pais_qa.alias("nuevos_datos"),
    condition = "base.ID_PAIS = nuevos_datos.ID_PAIS"
).whenMatchedUpdateAll() \
 .whenNotMatchedInsertAll() \
 .execute()

df_pais_fin= spark.read.format("delta").load(pais_path)
print(df_pais_fin.count())

# COMMAND ----------

# departamento
DeltaTable.forPath(spark, depto_path).alias("base").merge(
    source = df_depto_qa.alias("nuevos_datos"),
    condition = "base.ID_DEPTO = nuevos_datos.ID_DEPTO"
).whenMatchedUpdateAll() \
 .whenNotMatchedInsertAll() \
 .execute()

df_depto_fin= spark.read.format("delta").load(depto_path)
print(df_depto_fin.count())

# COMMAND ----------

# ciudad
DeltaTable.forPath(spark, ciudad_path).alias("base").merge(
    source = df_ciudad_qa.alias("nuevos_datos"),
    condition = "base.ID_CIUDAD = nuevos_datos.ID_CIUDAD"
).whenMatchedUpdateAll() \
 .whenNotMatchedInsertAll() \
 .execute()

df_ciudad_fin= spark.read.format("delta").load(ciudad_path)
print(df_ciudad_fin.count())

# COMMAND ----------

# eps
DeltaTable.forPath(spark, eps_path).alias("base").merge(
    source = df_eps_qa.alias("nuevos_datos"),
    condition = "base.ID_EPS = nuevos_datos.ID_EPS"
).whenMatchedUpdateAll() \
 .whenNotMatchedInsertAll() \
 .execute()

df_eps_fin= spark.read.format("delta").load(eps_path)
print(df_eps_fin.count())

# COMMAND ----------

# red_sedes
DeltaTable.forPath(spark, red_sedes_path).alias("base").merge(
    source = df_red_sedes_qa.alias("nuevos_datos"),
    condition = "base.ID_SEDE = nuevos_datos.ID_SEDE"
).whenMatchedUpdateAll() \
 .whenNotMatchedInsertAll() \
 .execute()

df_sedes_fin= spark.read.format("delta").load(red_sedes_path)
print(df_sedes_fin.count())

# COMMAND ----------

# pac_registro
DeltaTable.forPath(spark, pac_path).alias("base").merge(
    source = df_pac_qa.alias("nuevos_datos"),
    condition = "base.ID_PACIENTE = nuevos_datos.ID_PACIENTE"
).whenMatchedUpdateAll() \
 .whenNotMatchedInsertAll() \
 .execute()

df_pac_fin= spark.read.format("delta").load(pac_path)
print(df_pac_fin.count())

# COMMAND ----------

# med_planta
DeltaTable.forPath(spark, med_path).alias("base").merge(
    source = df_med_qa.alias("nuevos_datos"),
    condition = "base.ID_MEDICO = nuevos_datos.ID_MEDICO"
).whenMatchedUpdateAll() \
 .whenNotMatchedInsertAll() \
 .execute()

df_med_fin= spark.read.format("delta").load(med_path)
print(df_med_fin.count())

# COMMAND ----------

# hce_encuentros
DeltaTable.forPath(spark, hce_path).alias("base").merge(
    source = df_hce_qa2.alias("nuevos_datos"),
    condition = "base.ID_ENCUENTRO = nuevos_datos.ID_ENCUENTRO"
).whenMatchedUpdateAll() \
 .whenNotMatchedInsertAll() \
 .execute()

df_hce_fin= spark.read.format("delta").load(hce_path)
print(df_hce_fin.count())

# COMMAND ----------

# gcm_camas
DeltaTable.forPath(spark, camas_path).alias("base").merge(
    source = df_camas_delta.alias("nuevos_datos"),
    condition = "base.ID_REGISTRO = nuevos_datos.ID_REGISTRO"
).whenMatchedUpdateAll() \
 .whenNotMatchedInsertAll() \
 .execute()

df_camas_fin= spark.read.format("delta").load(camas_path)
print(df_camas_fin.count())

# COMMAND ----------

# far_dispensacion
DeltaTable.forPath(spark, far_path).alias("base").merge(
    source = df_far_delta.alias("nuevos_datos"),
    condition = "base.ID_DISPENSACION = nuevos_datos.ID_DISPENSACION"
).whenMatchedUpdateAll() \
 .whenNotMatchedInsertAll() \
 .execute()

df_far_fin= spark.read.format("delta").load(far_path)
print(df_far_fin.count())

# COMMAND ----------

# age_citas
DeltaTable.forPath(spark, citas_path).alias("base").merge(
    source = df_citas_qa.alias("nuevos_datos"),
    condition = "base.ID_CITA = nuevos_datos.ID_CITA"
).whenMatchedUpdateAll() \
 .whenNotMatchedInsertAll() \
 .execute()

df_citas_fin= spark.read.format("delta").load(citas_path)
print(df_citas_fin.count())