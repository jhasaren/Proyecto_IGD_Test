# Databricks notebook source
# MAGIC %md
# MAGIC ### Procesamiento de Datos (Silver)
# MAGIC #### Prueba Ingeniería de Datos - Dataknow 
# MAGIC
# MAGIC En este script se aplica la estandarizacion, formateo, renombrado y seleccion de campos. Se aplican tambien ajustes de limpieza de datos que dependen de la propia fila como manejo de NULL, valores con anomalías o algunas imputaciones. Procesa lo que llego en los parquet a bronze y el resultado lo sobreescribe en la tabla silver, para las transaccionales los adiciona.
# MAGIC
# MAGIC Escenario C: SALUD Y SERVICIOS MEDICOS<br />
# MAGIC Autor: John A. Sanchez | Fecha: 05/Jul/2026

# COMMAND ----------

# MAGIC %md
# MAGIC #### Importación de Librerías

# COMMAND ----------

# Importa lib necesarias
# ===========================================================================
from pyspark.sql.types import StructType, StructField, IntegerType, StringType
from pyspark.sql.functions import concat, lit, col, upper, date_format, floor, months_between, current_timestamp
from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
import pytz
import json
from delta.tables import DeltaTable


# COMMAND ----------

# MAGIC %md
# MAGIC #### Parámetros

# COMMAND ----------

# Parámetros de entorno
storage_base_bronze = 'abfss://bronze@dataknowdevdl.dfs.core.windows.net'
storage_base_silver = 'abfss://silver@dataknowdevdl.dfs.core.windows.net'

# Fecha Actual
tzInfo = pytz.timezone('America/Bogota')
fecha_calc = datetime.now(tz=tzInfo) - relativedelta(days=0)

fecha_hoy = fecha_calc.strftime("%Y-%m-%d")
fecha_hoy_anio = fecha_calc.strftime("%Y")
fecha_hoy_mes = fecha_calc.strftime("%m")
fecha_hoy_dia = fecha_calc.strftime("%d")

print("Hoy: ", fecha_hoy)
print("Anio: ", fecha_hoy_anio)
print("Mes: ", fecha_hoy_mes)
print("Dia: ", fecha_hoy_dia)


# COMMAND ----------

# MAGIC %md
# MAGIC #### Definición de Funciones

# COMMAND ----------

# Crea schema en HIVE para las validaciones transicionales
spark.sql("DROP SCHEMA IF EXISTS temp CASCADE")
spark.sql("CREATE SCHEMA IF NOT EXISTS temp")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Procesamiento de Tablas

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Tabla: pais

# COMMAND ----------

# Carga
# ================

# Lee parquet desde Bronze
df_pais = spark.read.parquet(f"{storage_base_bronze}/dataknow_project/catalogos/{fecha_hoy_anio}/{fecha_hoy_mes}/{fecha_hoy_dia}/01_PAIS.parquet")
display(df_pais.limit(5))

# COMMAND ----------

# Limpieza y Estandarizacion
# ================

# Renombra columnas
df_pais_pre = df_pais.withColumnRenamed("id_pais", "ID_PAIS")\
                     .withColumnRenamed("nombre", "NOMBRE_PAIS")

# Formatea columna F_ACTUAL a timestamp
df_pais_pre = df_pais_pre.withColumn("F_ACTUAL", df_pais_pre.F_ACTUAL.cast("timestamp"))

# Selecciona columnas
df_pais_final = df_pais_pre.select("ID_PAIS", "NOMBRE_PAIS", "F_ACTUAL")

# Previsualización
display(df_pais_final)


# COMMAND ----------

# Ajustes, derivaciones y QA
# ==========================

# Escribe tabla en HIVE
df_pais_final.write.mode("overwrite").saveAsTable("temp.pais")

# COMMAND ----------

# Salida
# ================

# metadata corporativa
metadata_tabla = {
    "ingeniero_datos": "JOHN SANCHEZ",
    "owner": "PEDRO PEREZ",
    "sistema_origen": "SALUD_SERVICIOS_MEDICOS",
    "descripcion": "contiene los paises donde opera HealthNet Colombia, Peru, Ecuador"
}
# Convierte el diccionario a un String en formato JSON
metadata_json_str = json.dumps(metadata_tabla)

# Guarda tabla en Delta en storage con metadata personalizada
df_pais_final.write \
    .format("delta") \
    .mode("overwrite") \
    .option("userMetadata", metadata_json_str) \
    .save(f"{storage_base_silver}/dataknow_project/entidades/pais")

# COMMAND ----------

# # leer tabla delta desde storage
# df_pais_delta = spark.read.format("delta").load(f"{storage_base_silver}/dataknow_project/entidades/pais")
# display(df_pais_delta)

# # Ver history de la tabla Delta
# df_history = spark.sql(f"DESCRIBE HISTORY '{storage_base_silver}/dataknow_project/entidades/pais'")
# display(df_history)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Tabla: departamento

# COMMAND ----------

# Carga
# ================

# Lee parquet desde Bronze
df_depto = spark.read.parquet(f"{storage_base_bronze}/dataknow_project/catalogos/{fecha_hoy_anio}/{fecha_hoy_mes}/{fecha_hoy_dia}/02_DEPARTAMENTO.parquet")
display(df_depto.limit(5))

# COMMAND ----------

# Limpieza y Estandarizacion
# ================

# Renombra columnas
df_depto_pre = df_depto.withColumnRenamed("id_depto", "ID_DEPTO")\
                       .withColumnRenamed("nombre", "NOMBRE_DEPTO")\
                       .withColumnRenamed("id_pais", "ID_PAIS")

# Formatea columna F_ACTUAL a timestamp
df_depto_pre = df_depto_pre.withColumn("F_ACTUAL", df_depto_pre.F_ACTUAL.cast("timestamp"))

# Selecciona columnas
df_depto_pre = df_depto_pre.select("ID_DEPTO", "NOMBRE_DEPTO", "ID_PAIS", "F_ACTUAL")

# Previsualización
display(df_depto_pre.limit(5))


# COMMAND ----------

# Ajustes, derivaciones y QA
# ==========================

# Escribe tabla en HIVE
df_depto_pre.write.mode("overwrite").saveAsTable("temp.departamento")

# COMMAND ----------

# Salida
# ================

# metadata corporativa
metadata_tabla = {
    "ingeniero_datos": "JOHN SANCHEZ",
    "owner": "PEDRO PEREZ",
    "sistema_origen": "SALUD_SERVICIOS_MEDICOS",
    "descripcion": "contiene los departamentos donde tiene sedes HealthNet en los países de operacion"
}
# Convierte el diccionario a un String en formato JSON
metadata_json_str = json.dumps(metadata_tabla)

# Guarda tabla en Delta en storage con metadata personalizada
df_depto_pre.write \
    .format("delta") \
    .mode("overwrite") \
    .option("userMetadata", metadata_json_str) \
    .save(f"{storage_base_silver}/dataknow_project/entidades/departamento")

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Tabla: ciudad

# COMMAND ----------

# Carga
# ================

# Lee parquet desde Bronze
df_ciudad = spark.read.parquet(f"{storage_base_bronze}/dataknow_project/catalogos/{fecha_hoy_anio}/{fecha_hoy_mes}/{fecha_hoy_dia}/03_CIUDAD.parquet")
display(df_ciudad.limit(5))

# COMMAND ----------

# Limpieza y Estandarizacion
# ================

# Renombra columnas
df_ciudad_pre = df_ciudad.withColumnRenamed("id_ciudad", "ID_CIUDAD")\
                       .withColumnRenamed("nombre", "NOMBRE_CIUDAD")\
                       .withColumnRenamed("id_depto", "ID_DEPTO")

# Formatea columna F_ACTUAL a timestamp
df_ciudad_pre = df_ciudad_pre.withColumn("F_ACTUAL", df_ciudad_pre.F_ACTUAL.cast("timestamp"))

# Selecciona columnas
df_ciudad_pre = df_ciudad_pre.select("ID_CIUDAD", "NOMBRE_CIUDAD", "ID_DEPTO", "F_ACTUAL")

# Previsualización
display(df_ciudad_pre.limit(5))


# COMMAND ----------

# Ajustes, derivaciones y QA
# ==========================

# Escribe tabla en HIVE
df_ciudad_pre.write.mode("overwrite").saveAsTable("temp.ciudad")

# COMMAND ----------

# Salida
# ================

# metadata corporativa
metadata_tabla = {
    "ingeniero_datos": "JOHN SANCHEZ",
    "owner": "PEDRO PEREZ",
    "sistema_origen": "SALUD_SERVICIOS_MEDICOS",
    "descripcion": "contiene las ciudades en los departamentos donde opera HealthNet"
}
# Convierte el diccionario a un String en formato JSON
metadata_json_str = json.dumps(metadata_tabla)

# Guarda tabla en Delta en storage con metadata personalizada
df_ciudad_pre.write \
    .format("delta") \
    .mode("overwrite") \
    .option("userMetadata", metadata_json_str) \
    .save(f"{storage_base_silver}/dataknow_project/entidades/ciudad")

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Tabla: EPS

# COMMAND ----------

# Carga
# ================

# Lee parquet desde Bronze
df_eps = spark.read.parquet(f"{storage_base_bronze}/dataknow_project/catalogos/{fecha_hoy_anio}/{fecha_hoy_mes}/{fecha_hoy_dia}/04_EPS.parquet")
display(df_eps.limit(5))

# COMMAND ----------

# Limpieza y Estandarizacion
# ================

# Renombra columnas
df_eps_pre = df_eps.withColumnRenamed("id_eps", "ID_EPS")\
                   .withColumnRenamed("nombre", "NOMBRE_EPS")\
                   .withColumnRenamed("id_pais", "ID_PAIS")

# Formatea columna F_ACTUAL a timestamp
df_eps_pre = df_eps_pre.withColumn("F_ACTUAL", df_eps_pre.F_ACTUAL.cast("timestamp"))

# Selecciona columnas
df_eps_pre = df_eps_pre.select("ID_EPS", "NOMBRE_EPS", "ID_PAIS", "F_ACTUAL")

# Previsualización
display(df_eps_pre.limit(5))


# COMMAND ----------

# Ajustes, derivaciones y QA
# ==========================

# Escribe tabla en HIVE
df_eps_pre.write.mode("overwrite").saveAsTable("temp.eps")

# COMMAND ----------

# Salida
# ================

# metadata corporativa
metadata_tabla = {
    "ingeniero_datos": "JOHN SANCHEZ",
    "owner": "PEDRO PEREZ",
    "sistema_origen": "SALUD_SERVICIOS_MEDICOS",
    "descripcion": "contiene las EPS a las que pertenecen los pacientes que son atendidos por HealthNet"
}
# Convierte el diccionario a un String en formato JSON
metadata_json_str = json.dumps(metadata_tabla)

# Guarda tabla en Delta en storage con metadata personalizada
df_eps_pre.write \
    .format("delta") \
    .mode("overwrite") \
    .option("userMetadata", metadata_json_str) \
    .save(f"{storage_base_silver}/dataknow_project/entidades/eps")

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Tabla: red_sedes

# COMMAND ----------

# Carga
# ================

# Lee parquet desde Bronze
df_red_sedes = spark.read.parquet(f"{storage_base_bronze}/dataknow_project/maestros/{fecha_hoy_anio}/{fecha_hoy_mes}/{fecha_hoy_dia}/05_RED_SEDES.parquet")
display(df_red_sedes.limit(5))

# COMMAND ----------

# Limpieza y Estandarizacion
# ================

# Renombra columnas
df_red_sedes_pre = df_red_sedes.withColumnRenamed("id_sede", "ID_SEDE")\
                   .withColumnRenamed("nom_sede", "NOMBRE_SEDE")\
                   .withColumnRenamed("tip_sede", "TIPO_SEDE")\
                   .withColumnRenamed("id_ciudad", "ID_CIUDAD")\
                   .withColumnRenamed("id_pais", "ID_PAIS")\
                   .withColumnRenamed("cap_camas_gen", "CAPACIDAD_CAMA_GENERAL")\
                   .withColumnRenamed("cap_camas_uci", "CAPACIDAD_CAMA_UCI")\
                   .withColumnRenamed("cap_camas_cirugia", "CAPACIDAD_CAMA_CIRUGIA")\
                   .withColumnRenamed("cap_camas_urg", "CAPACIDAD_CAMA_URGENCIA")\
                   .withColumnRenamed("nivel_complejidad", "NIVEL_COMPLEJIDAD")

# Formatea columna F_ACTUAL a timestamp
df_red_sedes_pre = df_red_sedes_pre.withColumn("F_ACTUAL", df_red_sedes_pre.F_ACTUAL.cast("timestamp"))\
                                   .withColumn("NOMBRE_SEDE", upper(col("NOMBRE_SEDE")))\
                                   .withColumn("TIPO_SEDE", upper(col("TIPO_SEDE")))

# Formatear campos a integer
df_red_sedes_pre = df_red_sedes_pre.withColumn("CAPACIDAD_CAMA_GENERAL", df_red_sedes_pre.CAPACIDAD_CAMA_GENERAL.cast("integer"))\
                                   .withColumn("CAPACIDAD_CAMA_UCI", df_red_sedes_pre.CAPACIDAD_CAMA_UCI.cast("integer"))\
                                   .withColumn("CAPACIDAD_CAMA_CIRUGIA", df_red_sedes_pre.CAPACIDAD_CAMA_CIRUGIA.cast("integer"))\
                                   .withColumn("CAPACIDAD_CAMA_URGENCIA", df_red_sedes_pre.CAPACIDAD_CAMA_URGENCIA.cast("integer"))

# Selecciona columnas
df_red_sedes_pre = df_red_sedes_pre.select("ID_SEDE", "NOMBRE_SEDE", "TIPO_SEDE", "ID_CIUDAD", "ID_PAIS", "CAPACIDAD_CAMA_GENERAL", "CAPACIDAD_CAMA_UCI", "CAPACIDAD_CAMA_CIRUGIA", "CAPACIDAD_CAMA_URGENCIA", "NIVEL_COMPLEJIDAD", "F_ACTUAL")

# Previsualización
display(df_red_sedes_pre.limit(5))


# COMMAND ----------

# Ajustes, derivaciones y QA
# ==========================

# Escribe tabla en HIVE
df_red_sedes_pre.write.mode("overwrite").saveAsTable("temp.red_sedes")

# COMMAND ----------

# Salida
# ================

# metadata corporativa
metadata_tabla = {
    "ingeniero_datos": "JOHN SANCHEZ",
    "owner": "PEDRO PEREZ",
    "sistema_origen": "SALUD_SERVICIOS_MEDICOS",
    "descripcion": "contiene las sedes de la red de atención brindada por HealthNet"
}
# Convierte el diccionario a un String en formato JSON
metadata_json_str = json.dumps(metadata_tabla)

# Guarda tabla en Delta en storage con metadata personalizada
df_red_sedes_pre.write \
    .format("delta") \
    .mode("overwrite") \
    .option("userMetadata", metadata_json_str) \
    .save(f"{storage_base_silver}/dataknow_project/entidades/red_sedes")

# COMMAND ----------

# Ver history de la tabla Delta
df_history = spark.sql(f"DESCRIBE HISTORY '{storage_base_silver}/dataknow_project/entidades/red_sedes'")
display(df_history)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Tabla: pac_registro

# COMMAND ----------

# Carga
# ================

# Lee parquet desde Bronze
df_pac_reg = spark.read.parquet(f"{storage_base_bronze}/dataknow_project/maestros/{fecha_hoy_anio}/{fecha_hoy_mes}/{fecha_hoy_dia}/06_PAC_REGISTRO.parquet")
display(df_pac_reg.limit(5))
print(df_pac_reg.count())

# COMMAND ----------

# Limpieza y Estandarizacion
# ================

# Renombra columnas
df_pac_reg_pre = df_pac_reg.withColumnRenamed("pac_id", "ID_PACIENTE")\
                   .withColumnRenamed("tip_doc", "TIPO_DOCUMENTO")\
                   .withColumnRenamed("num_doc_hash", "NUMERO_DOCUMENTO")\
                   .withColumnRenamed("fec_nac", "FECHA_NACIMIENTO")\
                   .withColumnRenamed("genero", "GENERO")\
                   .withColumnRenamed("id_ciudad_res", "ID_CIUDAD_RESIDENCIA")\
                   .withColumnRenamed("tip_aseguradora", "TIPO_ASEGURADORA")\
                   .withColumnRenamed("id_eps", "ID_EPS")\
                   .withColumnRenamed("estrato_socioec", "ESTRATO_SOCIOECONOMICO")\
                   .withColumnRenamed("fec_primer_atencion", "FECHA_PRIMER_ATENCION")\
                   .withColumnRenamed("activo", "ACTIVO")

# Formatea columna F_ACTUAL a timestamp
df_pac_reg_pre = df_pac_reg_pre.withColumn("F_ACTUAL", df_pac_reg_pre.F_ACTUAL.cast("timestamp"))

# Formatear campos
df_pac_reg_pre = df_pac_reg_pre.withColumn("ESTRATO_SOCIOECONOMICO", df_pac_reg_pre.ESTRATO_SOCIOECONOMICO.cast("integer"))\
                                .withColumn("TIPO_ASEGURADORA", upper(col("TIPO_ASEGURADORA")))

# Selecciona columnas
df_pac_reg_pre = df_pac_reg_pre.select("ID_PACIENTE", "TIPO_DOCUMENTO", "NUMERO_DOCUMENTO", "FECHA_NACIMIENTO", "GENERO", "ID_CIUDAD_RESIDENCIA", "TIPO_ASEGURADORA", "ID_EPS", "ESTRATO_SOCIOECONOMICO", "FECHA_PRIMER_ATENCION", "ACTIVO", "F_ACTUAL")

# Previsualización
display(df_pac_reg_pre.limit(5))


# COMMAND ----------

# Ajustes, derivaciones y QA
# ==========================

# Calcula edad usando fecha actual contra fecha de nacimiento
df_pac_reg_calc = df_pac_reg_pre.withColumn("EDAD", floor(months_between(current_timestamp(), df_pac_reg_pre.FECHA_NACIMIENTO)/12))

# Escribe tabla en HIVE
df_pac_reg_calc.write.mode("overwrite").saveAsTable("temp.pac_registro")


# COMMAND ----------

# MAGIC %sql
# MAGIC --Tratamiento de la asignacion correcta del TIPO_DOCUMENTO
# MAGIC --Se evidencia que la asignacion del tipo de doc tiene anomalias ya que el sistema no controla ni valida este campo.
# MAGIC --En COLOMBIA esto esta causando reprocesos en las remisiones a otras entidades ya que son rechazadas por ser adulto con doc RC o TI.
# MAGIC SELECT TIPO_DOCUMENTO,COUNT(*)
# MAGIC FROM temp.pac_registro
# MAGIC GROUP BY TIPO_DOCUMENTO

# COMMAND ----------

# MAGIC %sql
# MAGIC --Obtiene registros que tienen registrado tipo_doc RC y la edad es adulta (COLOMBIA)
# MAGIC SELECT 
# MAGIC --*,e.ID_PAIS,p.NOMBRE_PAIS
# MAGIC COUNT(*)
# MAGIC FROM 
# MAGIC temp.pac_registro a
# MAGIC LEFT JOIN temp.eps e ON e.ID_EPS = a.ID_EPS
# MAGIC LEFT JOIN temp.pais p ON p.ID_PAIS = e.ID_PAIS
# MAGIC WHERE 
# MAGIC TIPO_DOCUMENTO NOT IN ('CC','PA')
# MAGIC AND EDAD >=18 AND EDAD <= 99
# MAGIC AND NOMBRE_PAIS = 'COLOMBIA'
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC --Actualiza los registros colocandole 'CC' por defecto. 
# MAGIC --Esto es importante ya que cuando se generan las remisiones si es un adulto con un doc distinto esta generando reprocesos.
# MAGIC UPDATE temp.pac_registro 
# MAGIC SET TIPO_DOCUMENTO = 'CC'
# MAGIC WHERE ID_PACIENTE IN (
# MAGIC     SELECT 
# MAGIC     DISTINCT a.ID_PACIENTE
# MAGIC     FROM 
# MAGIC     temp.pac_registro a
# MAGIC     LEFT JOIN temp.eps e ON e.ID_EPS = a.ID_EPS
# MAGIC     LEFT JOIN temp.pais p ON p.ID_PAIS = e.ID_PAIS
# MAGIC     WHERE 
# MAGIC     TIPO_DOCUMENTO NOT IN ('CC','PA')
# MAGIC     AND EDAD >=18 AND EDAD <= 99
# MAGIC     AND NOMBRE_PAIS = 'COLOMBIA'
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC --Valida que no existan registros
# MAGIC SELECT 
# MAGIC --*,e.ID_PAIS,p.NOMBRE_PAIS
# MAGIC COUNT(*)
# MAGIC FROM 
# MAGIC temp.pac_registro a
# MAGIC LEFT JOIN temp.eps e ON e.ID_EPS = a.ID_EPS
# MAGIC LEFT JOIN temp.pais p ON p.ID_PAIS = e.ID_PAIS
# MAGIC WHERE 
# MAGIC TIPO_DOCUMENTO NOT IN ('CC','PA')
# MAGIC AND EDAD >=18 AND EDAD <= 99
# MAGIC AND NOMBRE_PAIS = 'COLOMBIA'
# MAGIC --0

# COMMAND ----------

# MAGIC %sql
# MAGIC --Obtiene registros con fecha nac por fuera de rangos normales
# MAGIC SELECT 
# MAGIC --*,e.ID_PAIS,p.NOMBRE_PAIS
# MAGIC COUNT(*)
# MAGIC FROM 
# MAGIC temp.pac_registro a
# MAGIC LEFT JOIN temp.eps e ON e.ID_EPS = a.ID_EPS
# MAGIC LEFT JOIN temp.pais p ON p.ID_PAIS = e.ID_PAIS
# MAGIC WHERE 
# MAGIC EDAD < 0 OR EDAD > 110
# MAGIC --7000

# COMMAND ----------

# MAGIC %sql
# MAGIC --Crea tabla con tag de QA para la EDAD, valores OK o ERROR si la edad presenta inconsistencias
# MAGIC CREATE OR REPLACE TABLE temp.pac_registro_val AS
# MAGIC SELECT 
# MAGIC a.*,
# MAGIC CASE 
# MAGIC     WHEN b.ID_PACIENTE IS NULL THEN 'OK'
# MAGIC ELSE 'ERROR' END AS QA_EDAD
# MAGIC FROM temp.pac_registro a
# MAGIC LEFT JOIN (
# MAGIC     SELECT 
# MAGIC     DISTINCT a.ID_PACIENTE
# MAGIC     FROM 
# MAGIC     temp.pac_registro a
# MAGIC     LEFT JOIN temp.eps e ON e.ID_EPS = a.ID_EPS
# MAGIC     LEFT JOIN temp.pais p ON p.ID_PAIS = e.ID_PAIS
# MAGIC     WHERE 
# MAGIC     EDAD < 0 OR EDAD > 110
# MAGIC ) b ON b.ID_PACIENTE = a.ID_PACIENTE

# COMMAND ----------

# Crea df con datos desde HIVE limpios con tag qa para la edad
df_pac_reg_final = spark.sql("SELECT * FROM temp.pac_registro_val")
display(df_pac_reg_final.limit(5))

# COMMAND ----------

# Salida
# ================

# metadata corporativa
metadata_tabla = {
    "ingeniero_datos": "JOHN SANCHEZ",
    "owner": "PEDRO PEREZ",
    "sistema_origen": "SALUD_SERVICIOS_MEDICOS",
    "descripcion": "contiene la relacion de los pacientes que son atendidos en las sedes de HealthNet"
}
# Convierte el diccionario a un String en formato JSON
metadata_json_str = json.dumps(metadata_tabla)

# Guarda tabla en Delta en storage con metadata personalizada
df_pac_reg_final.write \
    .format("delta") \
    .mode("overwrite") \
    .option("userMetadata", metadata_json_str) \
    .save(f"{storage_base_silver}/dataknow_project/entidades/pac_registro")

# COMMAND ----------

# Ver history de la tabla Delta
df_history = spark.sql(f"DESCRIBE HISTORY '{storage_base_silver}/dataknow_project/entidades/pac_registro'")
display(df_history)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Tabla: med_planta

# COMMAND ----------

# Carga
# ================

# Lee parquet desde Bronze
df_med_planta = spark.read.parquet(f"{storage_base_bronze}/dataknow_project/maestros/{fecha_hoy_anio}/{fecha_hoy_mes}/{fecha_hoy_dia}/07_MED_PLANTA.parquet")
display(df_med_planta.limit(5))
print(df_med_planta.count())

# COMMAND ----------

# Limpieza y Estandarizacion
# ================

# Renombra columnas
df_med_planta_pre = df_med_planta.withColumnRenamed("med_id", "ID_MEDICO")\
                   .withColumnRenamed("esp_principal", "ESPECIALIDAD_PRINCIPAL")\
                   .withColumnRenamed("esp_secundaria", "ESPECIALIDAD_SECUNDARIA")\
                   .withColumnRenamed("id_sede", "ID_SEDE")\
                   .withColumnRenamed("fec_ingreso", "FECHA_INGRESO")\
                   .withColumnRenamed("tip_contrato", "TIPO_CONTRATO")\
                   .withColumnRenamed("jornada", "JORNADA_LABORAL")\
                   .withColumnRenamed("estado_activo", "ESTADO_ACTIVO")

# Formatea columna F_ACTUAL a timestamp
df_med_planta_pre = df_med_planta_pre.withColumn("F_ACTUAL", df_med_planta_pre.F_ACTUAL.cast("timestamp"))

# Formatear campos
df_med_planta_pre = df_med_planta_pre.withColumn("FECHA_INGRESO", df_med_planta_pre.FECHA_INGRESO.cast("date"))\
                                     .withColumn("ESPECIALIDAD_PRINCIPAL", upper(col("ESPECIALIDAD_PRINCIPAL")))\
                                     .withColumn("ESPECIALIDAD_SECUNDARIA", upper(col("ESPECIALIDAD_SECUNDARIA")))\
                                     .withColumn("TIPO_CONTRATO", upper(col("TIPO_CONTRATO")))\
                                     .withColumn("JORNADA_LABORAL", upper(col("JORNADA_LABORAL")))

# Selecciona columnas
df_med_planta_pre = df_med_planta_pre.select("ID_MEDICO", "ESPECIALIDAD_PRINCIPAL", "ESPECIALIDAD_SECUNDARIA", "ID_SEDE", "FECHA_INGRESO", "TIPO_CONTRATO", "JORNADA_LABORAL", "ESTADO_ACTIVO", "F_ACTUAL")

# Previsualización
display(df_med_planta_pre.limit(5))


# COMMAND ----------

# Ajustes, derivaciones y QA
# ==========================

# Escribe tabla en HIVE
df_med_planta_pre.write.mode("overwrite").saveAsTable("temp.med_planta")

# COMMAND ----------

# MAGIC %sql
# MAGIC --Validacion de medicos sin especialidad principal
# MAGIC SELECT count(*)
# MAGIC FROM temp.med_planta
# MAGIC WHERE ESPECIALIDAD_PRINCIPAL IS NULL 
# MAGIC --0

# COMMAND ----------

# MAGIC %sql
# MAGIC --Validacion de medicos sin fecha de ingreso, o por fuera de rango normal
# MAGIC SELECT COUNT(*)
# MAGIC FROM temp.med_planta
# MAGIC WHERE FECHA_INGRESO IS NULL OR FECHA_INGRESO >= current_date() OR FECHA_INGRESO <= '1910-01-01'

# COMMAND ----------

# MAGIC %sql
# MAGIC --Validacion de medicos sin tipo de contrato
# MAGIC --Esto se debe ajustar ya por temas legales se debe presentar en la auditoria
# MAGIC SELECT TIPO_CONTRATO,COUNT(*)
# MAGIC FROM temp.med_planta
# MAGIC GROUP BY TIPO_CONTRATO
# MAGIC --120 sin tipo de contrato

# COMMAND ----------

# MAGIC %sql
# MAGIC --Para los medicos sin tipo de contrato si la jornada es medio tiempo o turnos asignar contrato termino fijo, si es ordinaria asignar termino fijo
# MAGIC UPDATE temp.med_planta
# MAGIC SET TIPO_CONTRATO = CASE 
# MAGIC                         WHEN JORNADA_LABORAL = 'MEDIO TIEMPO' THEN 'TERMINO FIJO' 
# MAGIC                         WHEN JORNADA_LABORAL = 'TURNOS' THEN 'TERMINO FIJO' 
# MAGIC                     ELSE 'INDEFINIDO' END
# MAGIC WHERE TIPO_CONTRATO IS NULL

# COMMAND ----------

# MAGIC %sql
# MAGIC --Validacion luego del ajuste
# MAGIC SELECT TIPO_CONTRATO,COUNT(*)
# MAGIC FROM temp.med_planta
# MAGIC GROUP BY TIPO_CONTRATO
# MAGIC --120 sin tipo de contrato

# COMMAND ----------

# MAGIC %sql
# MAGIC --Validacion de medicos sin jornada laboral
# MAGIC SELECT JORNADA_LABORAL,COUNT(*)
# MAGIC FROM temp.med_planta
# MAGIC GROUP BY JORNADA_LABORAL

# COMMAND ----------

# MAGIC %sql
# MAGIC --Crea columna de marcacion para la jornada laboral cuando esta vacia
# MAGIC CREATE OR REPLACE TABLE temp.med_planta_val AS
# MAGIC SELECT 
# MAGIC *,
# MAGIC CASE 
# MAGIC     WHEN JORNADA_LABORAL IS NULL THEN 'ERROR' 
# MAGIC ELSE 'OK' END AS QA_JORNADA_LABORAL
# MAGIC FROM temp.med_planta

# COMMAND ----------

# Crea df con datos desde HIVE limpios con tags qa
df_med_planta_final = spark.sql("SELECT * FROM temp.med_planta_val")
display(df_med_planta_final.limit(5))

# COMMAND ----------

# Salida
# ================

# metadata corporativa
metadata_tabla = {
    "ingeniero_datos": "JOHN SANCHEZ",
    "owner": "PEDRO PEREZ",
    "sistema_origen": "SALUD_SERVICIOS_MEDICOS",
    "descripcion": "contiene los medicos de planta que estan asignados a cada sede de la red de atencion"
}
# Convierte el diccionario a un String en formato JSON
metadata_json_str = json.dumps(metadata_tabla)

# Guarda tabla en Delta en storage con metadata personalizada
df_med_planta_final.write \
    .format("delta") \
    .mode("overwrite") \
    .option("userMetadata", metadata_json_str) \
    .save(f"{storage_base_silver}/dataknow_project/entidades/med_planta")

# COMMAND ----------

# Ver history de la tabla Delta
df_history = spark.sql(f"DESCRIBE HISTORY '{storage_base_silver}/dataknow_project/entidades/med_planta'")
display(df_history)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Tabla: hce_encuentros

# COMMAND ----------

# Carga
# ================

# Lee parquet desde Bronze
df_hce = spark.read.parquet(f"{storage_base_bronze}/dataknow_project/transaccionales/{fecha_hoy_anio}/{fecha_hoy_mes}/{fecha_hoy_dia}/08_HCE_ENCUENTROS.parquet")
display(df_hce.limit(5))
print(df_hce.count())

# COMMAND ----------

# Limpieza y Estandarizacion
# ================

# Renombra columnas
df_hce_pre = df_hce.withColumnRenamed("id_encuentro", "ID_ENCUENTRO")\
                   .withColumnRenamed("pac_id", "ID_PACIENTE")\
                   .withColumnRenamed("med_id", "ID_MEDICO")\
                   .withColumnRenamed("id_sede", "ID_SEDE")\
                   .withColumnRenamed("fec_registro", "FECHA_REGISTRO")\
                   .withColumnRenamed("fec_inicio_atencion", "FECHA_INI_ATENCION")\
                   .withColumnRenamed("fec_egreso", "FECHA_FIN_ATENCION")\
                   .withColumnRenamed("tip_consulta", "TIPO_CONSULTA")\
                   .withColumnRenamed("esp_atendida", "ESPECIALIDAD_ATENDIDA")\
                   .withColumnRenamed("diag_principal_cie10", "DIAGNOSTICO_PPAL_CIE10")\
                   .withColumnRenamed("diag_sec1_cie10", "DIAGNOSTICO_SECUND_CIE10")\
                   .withColumnRenamed("cod_procedimientos", "PROCEDIMIENTOS_CUPS")\
                   .withColumnRenamed("vr_facturado", "VALOR_FACTURADO_USD")\
                   .withColumnRenamed("estado_factura", "ESTADO_FACTURA")

# Formatea columna F_ACTUAL a timestamp
df_hce_pre = df_hce_pre.withColumn("F_ACTUAL", df_hce_pre.F_ACTUAL.cast("timestamp"))\
                        .withColumn("FECHA_REGISTRO", df_hce_pre.FECHA_REGISTRO.cast("timestamp"))\
                        .withColumn("FECHA_INI_ATENCION", df_hce_pre.FECHA_INI_ATENCION.cast("timestamp"))\
                        .withColumn("FECHA_FIN_ATENCION", df_hce_pre.FECHA_FIN_ATENCION.cast("timestamp"))

# Formatear campos
df_hce_pre = df_hce_pre.withColumn("TIPO_CONSULTA", upper(col("TIPO_CONSULTA")))\
                        .withColumn("ESPECIALIDAD_ATENDIDA", upper(col("ESPECIALIDAD_ATENDIDA")))

# Selecciona columnas
df_hce_pre = df_hce_pre.select("ID_ENCUENTRO", "ID_PACIENTE", "ID_MEDICO", "ID_SEDE", "FECHA_REGISTRO", "FECHA_INI_ATENCION", "FECHA_FIN_ATENCION", "TIPO_CONSULTA", "ESPECIALIDAD_ATENDIDA", "DIAGNOSTICO_PPAL_CIE10", "DIAGNOSTICO_SECUND_CIE10", "PROCEDIMIENTOS_CUPS", "VALOR_FACTURADO_USD", "ESTADO_FACTURA", "F_ACTUAL")

# Previsualización
display(df_hce_pre.limit(5))


# COMMAND ----------

# Ajustes, derivaciones y QA
# ==========================

# Escribe tabla en HIVE
df_hce_pre.write.mode("overwrite").saveAsTable("temp.hce_encuentros")



# COMMAND ----------

# MAGIC %sql
# MAGIC --Validar si el codigo cie10 es correcto, nomeclatura LETRA+NUMERO+NUMERO
# MAGIC CREATE OR REPLACE TABLE temp.hce_encuentros_val AS
# MAGIC SELECT 
# MAGIC *,
# MAGIC CASE 
# MAGIC     WHEN REGEXP_LIKE(DIAGNOSTICO_PPAL_CIE10_ESTAND,'^[A-Z][0-9]{2}$') THEN 'OK' 
# MAGIC ELSE 'ERROR' END AS QA_DIAGNOSTICO_PPAL_CIE10,
# MAGIC CASE 
# MAGIC     WHEN REGEXP_LIKE(DIAGNOSTICO_SECUND_CIE10_ESTAND,'^[A-Z][0-9]{2}$') THEN 'OK' 
# MAGIC ELSE 'ERROR' END AS QA_DIAGNOSTICO_SECUND_CIE10
# MAGIC FROM (
# MAGIC     SELECT 
# MAGIC     *,
# MAGIC     --obtiene primeros tres numeros del CIE10
# MAGIC     SUBSTRING(DIAGNOSTICO_PPAL_CIE10,1,3) AS DIAGNOSTICO_PPAL_CIE10_ESTAND,
# MAGIC     SUBSTRING(DIAGNOSTICO_SECUND_CIE10,1,3) AS DIAGNOSTICO_SECUND_CIE10_ESTAND
# MAGIC     FROM temp.hce_encuentros
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC --Cantidad de registros con cod errado en CIE10
# MAGIC SELECT COUNT(*)
# MAGIC FROM temp.hce_encuentros_val
# MAGIC WHERE QA_DIAGNOSTICO_PPAL_CIE10 = 'ERROR' OR QA_DIAGNOSTICO_SECUND_CIE10 = 'ERROR'

# COMMAND ----------

# MAGIC %sql
# MAGIC --identificación de registros con valor facturado <= 0
# MAGIC CREATE OR REPLACE TABLE temp.hce_encuentros_val_2 AS
# MAGIC SELECT 
# MAGIC *,
# MAGIC CASE 
# MAGIC     WHEN VALOR_FACTURADO_USD > 0 THEN 'OK'
# MAGIC ELSE 'ERROR' END AS QA_VALOR_FACTURADO_USD
# MAGIC FROM temp.hce_encuentros_val
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC --Cant de registros sin valor facturacion
# MAGIC SELECT COUNT(*)
# MAGIC FROM temp.hce_encuentros_val_2
# MAGIC WHERE QA_VALOR_FACTURADO_USD = 'ERROR'

# COMMAND ----------

# MAGIC %sql
# MAGIC --Calcula columna tiempo_estadia_horas (dif entre FECHA_FIN_ATENCION Y FECHA_INI_ATENCION)
# MAGIC CREATE OR REPLACE TABLE temp.hce_encuentros_val_3 AS
# MAGIC SELECT 
# MAGIC *,
# MAGIC ROUND((DATEDIFF(minute,FECHA_INI_ATENCION,FECHA_FIN_ATENCION)/60),2) AS TIEMPO_ESTADIA_HORAS
# MAGIC FROM temp.hce_encuentros_val_2

# COMMAND ----------

# MAGIC %sql
# MAGIC --Cantidad de registros con tiempo de estadia negativo
# MAGIC SELECT COUNT(*)
# MAGIC FROM temp.hce_encuentros_val_3
# MAGIC WHERE TIEMPO_ESTADIA_HORAS < 0

# COMMAND ----------

# Crea df con datos desde HIVE limpios con tags qa
df_hce_final = spark.sql("SELECT * FROM temp.hce_encuentros_val_3")
display(df_hce_final.limit(5))

# COMMAND ----------

# Idempotencia 
# ===============================

# Tabla Delta en Storage
path_tabla_hce = f"{storage_base_silver}/dataknow_project/entidades/hce_encuentros"

# Valida si existe
if DeltaTable.isDeltaTable(spark, path_tabla_hce):
    
    # Obtiene en variables la fec_registro min y max para borrado del delta
    f_min = df_hce_final.select("FECHA_REGISTRO").agg({"FECHA_REGISTRO": "min"}).collect()[0][0]
    f_max = df_hce_final.select("FECHA_REGISTRO").agg({"FECHA_REGISTRO": "max"}).collect()[0][0]
    print(f_min)
    print(f_max)

    # Conexion a la tabla
    deltaTable_hce = DeltaTable.forPath(spark, path_tabla_hce)

    # Nota: La condición elimina lo que esté DENTRO del rango (>= f_min y <= f_max)
    deltaTable_hce.delete(
        (col("FECHA_REGISTRO") >= f_min) & (col("FECHA_REGISTRO") <= f_max)
    )

    print("se ejecuta el borrado en los datos para el periodo cargado")

else:
    print("No existe la tabla. No se realiza ninguna accion")
    

# COMMAND ----------

# Salida
# ================

# metadata corporativa
metadata_tabla = {
    "ingeniero_datos": "JOHN SANCHEZ",
    "owner": "PEDRO PEREZ",
    "sistema_origen": "SALUD_SERVICIOS_MEDICOS",
    "descripcion": "contiene el detalle del registro de la atencion brindada a cada paciente en la red de sedes"
}
# Convierte el diccionario a un String en formato JSON
metadata_json_str = json.dumps(metadata_tabla)

# Guarda tabla en Delta en storage con metadata personalizada
df_hce_final.write \
    .format("delta") \
    .mode("append") \
    .option("userMetadata", metadata_json_str) \
    .save(path_tabla_hce)

# COMMAND ----------

# Ver history de la tabla Delta
df_history = spark.sql(f"DESCRIBE HISTORY '{path_tabla_hce}'")
display(df_history)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Tabla: gcm_camas

# COMMAND ----------

# Carga
# ================

# Lee parquet desde Bronze
df_gcm_camas = spark.read.parquet(f"{storage_base_bronze}/dataknow_project/transaccionales/{fecha_hoy_anio}/{fecha_hoy_mes}/{fecha_hoy_dia}/09_GCM_CAMAS.parquet")
display(df_gcm_camas.limit(5))
print(df_gcm_camas.count())

# COMMAND ----------

# Limpieza y Estandarizacion
# ================

# Renombra columnas
df_gcm_camas_pre = df_gcm_camas.withColumnRenamed("id_registro_cama", "ID_REGISTRO")\
                   .withColumnRenamed("id_sede", "ID_SEDE")\
                   .withColumnRenamed("tip_unidad", "TIPO_UNIDAD")\
                   .withColumnRenamed("fec_hora_registro", "FECHA_HORA_REGISTRO")\
                   .withColumnRenamed("num_camas_ocupadas", "NUMERO_CAMAS_OCUPADAS")\
                   .withColumnRenamed("num_camas_disp", "NUMERO_CAMAS_DISPONIBLES")\
                   .withColumnRenamed("num_camas_mant", "NUMERO_CAMAS_MANTENIMIENTO")\
                   .withColumnRenamed("motivo_indisponibilidad", "MOTIVO_INDISPONIBILIDAD")

# Formatea columna F_ACTUAL a timestamp
df_gcm_camas_pre = df_gcm_camas_pre.withColumn("F_ACTUAL", df_gcm_camas_pre.F_ACTUAL.cast("timestamp"))\
                        .withColumn("FECHA_HORA_REGISTRO", df_gcm_camas_pre.FECHA_HORA_REGISTRO.cast("timestamp"))

# Formatear campos
df_gcm_camas_pre = df_gcm_camas_pre.withColumn("TIPO_UNIDAD", upper(col("TIPO_UNIDAD")))\
                        .withColumn("MOTIVO_INDISPONIBILIDAD", upper(col("MOTIVO_INDISPONIBILIDAD")))

# Selecciona columnas
df_gcm_camas_pre = df_gcm_camas_pre.select("ID_REGISTRO", "ID_SEDE", "TIPO_UNIDAD", "FECHA_HORA_REGISTRO", "NUMERO_CAMAS_OCUPADAS", "NUMERO_CAMAS_DISPONIBLES", "NUMERO_CAMAS_MANTENIMIENTO", "MOTIVO_INDISPONIBILIDAD","F_ACTUAL")

# Previsualización
display(df_gcm_camas_pre.limit(5))


# COMMAND ----------

# Idempotencia 
# ===============================

# Tabla Delta en Storage
path_tabla_camas = f"{storage_base_silver}/dataknow_project/entidades/gcm_camas"

# Valida si existe
if DeltaTable.isDeltaTable(spark, path_tabla_camas):
    
    # Obtiene en variables la fec_registro min y max para borrado del delta
    f_min = df_gcm_camas_pre.select("FECHA_HORA_REGISTRO").agg({"FECHA_HORA_REGISTRO": "min"}).collect()[0][0]
    f_max = df_gcm_camas_pre.select("FECHA_HORA_REGISTRO").agg({"FECHA_HORA_REGISTRO": "max"}).collect()[0][0]
    print(f_min)
    print(f_max)

    # Conexion a la tabla
    deltaTable_camas = DeltaTable.forPath(spark, path_tabla_camas)

    # Borra físicamente las filas en el rango de fechas
    deltaTable_camas.delete(
        (col("FECHA_HORA_REGISTRO") >= f_min) & (col("FECHA_HORA_REGISTRO") <= f_max)
    )

    print("se ejecuta el borrado en los datos para el periodo cargado")

else:
    print("No existe la tabla. No se realiza ninguna accion")

# COMMAND ----------

# Salida
# ================

# metadata corporativa
metadata_tabla = {
    "ingeniero_datos": "JOHN SANCHEZ",
    "owner": "PEDRO PEREZ",
    "sistema_origen": "SALUD_SERVICIOS_MEDICOS",
    "descripcion": "contiene el registro diario de cada sede sobre la disponibilidad de camas segun el tipo de unidad"
}
# Convierte el diccionario a un String en formato JSON
metadata_json_str = json.dumps(metadata_tabla)

# Guarda tabla en Delta en storage con metadata personalizada
df_gcm_camas_pre.write \
    .format("delta") \
    .mode("append") \
    .option("userMetadata", metadata_json_str) \
    .save(path_tabla_camas)

# COMMAND ----------

# Ver history de la tabla Delta
df_history = spark.sql(f"DESCRIBE HISTORY '{path_tabla_camas}'")
display(df_history)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Tabla: far_dispensacion

# COMMAND ----------

# Carga
# ================

# Lee parquet desde Bronze
df_far = spark.read.parquet(f"{storage_base_bronze}/dataknow_project/transaccionales/{fecha_hoy_anio}/{fecha_hoy_mes}/{fecha_hoy_dia}/10_FAR_DISPENSACION.parquet")
display(df_far.limit(5))
print(df_far.count())

# COMMAND ----------

# Limpieza y Estandarizacion
# ================

# Renombra columnas
df_far_pre = df_far.withColumnRenamed("id_dispensacion", "ID_DISPENSACION")\
                   .withColumnRenamed("id_encuentro", "ID_ENCUENTRO")\
                   .withColumnRenamed("pac_id", "ID_PACIENTE")\
                   .withColumnRenamed("id_sede", "ID_SEDE")\
                   .withColumnRenamed("fec_dispensacion", "FECHA_HORA_DISPENSACION")\
                   .withColumnRenamed("cod_medicamento", "CODIGO_MEDICAMENTO")\
                   .withColumnRenamed("nom_medicamento", "NOMBRE_MEDICAMENTO")\
                   .withColumnRenamed("cantidad", "CANTIDAD")\
                   .withColumnRenamed("vr_unitario", "VR_UNITARIO_USD")\
                   .withColumnRenamed("tip_prescripcion", "TIPO_PRESCRIPCION")

# Formatea columna F_ACTUAL a timestamp
df_far_pre = df_far_pre.withColumn("F_ACTUAL", df_far_pre.F_ACTUAL.cast("timestamp"))\
                        .withColumn("FECHA_HORA_DISPENSACION", df_far_pre.FECHA_HORA_DISPENSACION.cast("timestamp"))

# Formatear campos
df_far_pre = df_far_pre.withColumn("NOMBRE_MEDICAMENTO", upper(col("NOMBRE_MEDICAMENTO")))\
                        .withColumn("TIPO_PRESCRIPCION", upper(col("TIPO_PRESCRIPCION")))

# Selecciona columnas
df_far_pre = df_far_pre.select("ID_DISPENSACION", "ID_ENCUENTRO", "ID_PACIENTE", "ID_SEDE", "FECHA_HORA_DISPENSACION", "CODIGO_MEDICAMENTO", "NOMBRE_MEDICAMENTO", "CANTIDAD", "VR_UNITARIO_USD", "TIPO_PRESCRIPCION", "F_ACTUAL")

# Previsualización
display(df_far_pre.limit(5))


# COMMAND ----------

# Idempotencia 
# ===============================

# Tabla Delta en Storage
path_tabla_far = f"{storage_base_silver}/dataknow_project/entidades/far_dispensacion"

# Valida si existe
if DeltaTable.isDeltaTable(spark, path_tabla_far):
    
    # Obtiene en variables la fec_registro min y max para borrado del delta
    f_min = df_far_pre.select("FECHA_HORA_DISPENSACION").agg({"FECHA_HORA_DISPENSACION": "min"}).collect()[0][0]
    f_max = df_far_pre.select("FECHA_HORA_DISPENSACION").agg({"FECHA_HORA_DISPENSACION": "max"}).collect()[0][0]
    print(f_min)
    print(f_max)

    # Conexion a la tabla
    deltaTable_far = DeltaTable.forPath(spark, path_tabla_far)

    # Borra físicamente las filas en el rango de fechas
    deltaTable_far.delete(
        (col("FECHA_HORA_DISPENSACION") >= f_min) & (col("FECHA_HORA_DISPENSACION") <= f_max)
    )

    print("se ejecuta el borrado en los datos para el periodo cargado")

else:
    print("No existe la tabla. No se realiza ninguna accion")

# COMMAND ----------

# Salida
# ================

# metadata corporativa
metadata_tabla = {
    "ingeniero_datos": "JOHN SANCHEZ",
    "owner": "PEDRO PEREZ",
    "sistema_origen": "SALUD_SERVICIOS_MEDICOS",
    "descripcion": "contiene el registro diario de cada sede sobre la disponibilidad de camas segun el tipo de unidad"
}
# Convierte el diccionario a un String en formato JSON
metadata_json_str = json.dumps(metadata_tabla)

# Guarda tabla en Delta en storage con metadata personalizada
df_far_pre.write \
    .format("delta") \
    .mode("append") \
    .option("userMetadata", metadata_json_str) \
    .save(path_tabla_far)

# COMMAND ----------

# Ver history de la tabla Delta
df_history = spark.sql(f"DESCRIBE HISTORY '{path_tabla_far}'")
display(df_history)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Tabla: age_citas

# COMMAND ----------

# Carga
# ================

# Lee parquet desde Bronze
df_citas = spark.read.parquet(f"{storage_base_bronze}/dataknow_project/transaccionales/{fecha_hoy_anio}/{fecha_hoy_mes}/{fecha_hoy_dia}/11_AGE_CITAS.parquet")
display(df_citas.limit(5))
print(df_citas.count())

# COMMAND ----------

# Limpieza y Estandarizacion
# ================

# Renombra columnas
df_citas_pre = df_citas.withColumnRenamed("id_cita", "ID_CITA")\
                   .withColumnRenamed("pac_id", "ID_PACIENTE")\
                   .withColumnRenamed("med_id", "ID_MEDICO")\
                   .withColumnRenamed("id_sede", "ID_SEDE")\
                   .withColumnRenamed("fec_agendamiento", "FECHA_HORA_AGENDAMIENTO")\
                   .withColumnRenamed("fec_cita_programada", "FECHA_CITA_PROGRAMADA")\
                   .withColumnRenamed("hra_cita_programada", "HORA_CITA_PROGRAMADA")\
                   .withColumnRenamed("hra_llegada_paciente", "HORA_LLEGADA_PACIENTE")\
                   .withColumnRenamed("hra_inicio_atencion", "HORA_INICIO_ATENCION")\
                   .withColumnRenamed("esp_solicitada", "ESPECIALIDAD_SOLICITADA")\
                   .withColumnRenamed("tip_cita", "TIPO_CITA")\
                   .withColumnRenamed("estado_cita", "ESTADO_CITA")

# Formatea columna F_ACTUAL a timestamp
df_citas_pre = df_citas_pre.withColumn("F_ACTUAL", df_citas_pre.F_ACTUAL.cast("timestamp"))\
                        .withColumn("FECHA_HORA_AGENDAMIENTO", df_citas_pre.FECHA_HORA_AGENDAMIENTO.cast("timestamp"))\
                        .withColumn("FECHA_CITA_PROGRAMADA", df_citas_pre.FECHA_CITA_PROGRAMADA.cast("date"))

# formatea el campo hora en HH:MM:SS
df_citas_pre = df_citas_pre.withColumn("HORA_CITA_PROGRAMADA", date_format(col("HORA_CITA_PROGRAMADA"), "HH:mm:ss"))\
                        .withColumn("HORA_LLEGADA_PACIENTE", date_format(col("HORA_LLEGADA_PACIENTE"), "HH:mm:ss"))\
                        .withColumn("HORA_INICIO_ATENCION", date_format(col("HORA_INICIO_ATENCION"), "HH:mm:ss"))

# Formatear campos
df_citas_pre = df_citas_pre.withColumn("ESPECIALIDAD_SOLICITADA", upper(col("ESPECIALIDAD_SOLICITADA")))\
                        .withColumn("ESTADO_CITA", upper(col("ESTADO_CITA")))

# Selecciona columnas
df_citas_pre = df_citas_pre.select("ID_CITA", "ID_PACIENTE", "ID_MEDICO", "ID_SEDE", "FECHA_HORA_AGENDAMIENTO", "FECHA_CITA_PROGRAMADA", "HORA_CITA_PROGRAMADA", "HORA_LLEGADA_PACIENTE", "HORA_INICIO_ATENCION", "ESPECIALIDAD_SOLICITADA", "TIPO_CITA", "ESTADO_CITA", "F_ACTUAL")

# Previsualización
display(df_citas_pre.limit(5))


# COMMAND ----------

# Ajustes, derivaciones y QA
# ==========================

# Escribe tabla en HIVE
df_citas_pre.write.mode("overwrite").saveAsTable("temp.age_citas")

# COMMAND ----------

# MAGIC %sql
# MAGIC --Identificacion de estados disponibles
# MAGIC SELECT ESTADO_CITA,COUNT(*)
# MAGIC FROM temp.age_citas
# MAGIC GROUP BY ESTADO_CITA

# COMMAND ----------

# MAGIC %sql
# MAGIC --Identificacion de citas no atendidas con tiempo de llegada y atencion al paciente
# MAGIC CREATE OR REPLACE TABLE temp.age_citas_val AS
# MAGIC SELECT 
# MAGIC a.*,
# MAGIC CASE
# MAGIC     WHEN b.ID_CITA IS NULL THEN 'OK'
# MAGIC ELSE 'ERROR' END AS QA_HORA_INICIO_ATENCION
# MAGIC FROM temp.age_citas a
# MAGIC LEFT JOIN (
# MAGIC     SELECT DISTINCT ID_CITA
# MAGIC     FROM temp.age_citas
# MAGIC     WHERE ESTADO_CITA NOT IN ('ATENDIDA')
# MAGIC     AND (HORA_LLEGADA_PACIENTE IS NOT NULL OR HORA_INICIO_ATENCION IS NOT NULL)
# MAGIC ) b ON b.ID_CITA = a.ID_CITA
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC --Cant reg con error en la hora atencion (cita no atendida)
# MAGIC SELECT COUNT(*)
# MAGIC FROM temp.age_citas_val
# MAGIC WHERE QA_HORA_INICIO_ATENCION = 'ERROR'

# COMMAND ----------

# MAGIC %sql
# MAGIC --Deriva el campo tiempo atencion para las citas atendidas
# MAGIC CREATE OR REPLACE TABLE temp.age_citas_val_2 AS
# MAGIC SELECT 
# MAGIC *,
# MAGIC DATEDIFF(MINUTE, HORA_LLEGADA_PACIENTE, HORA_INICIO_ATENCION) as TIEMPO_ESPERA_MINUTOS
# MAGIC FROM temp.age_citas_val

# COMMAND ----------

# MAGIC %sql
# MAGIC --cant de registros con valor negativo, la hora de llegada es despues de la hora de atencion
# MAGIC SELECT COUNT(*)
# MAGIC FROM temp.age_citas_val_2
# MAGIC WHERE TIEMPO_ESPERA_MINUTOS < 0

# COMMAND ----------

# MAGIC %sql
# MAGIC --todo los registros con tiempo negativo, se imputa en el tiempo de llegada la misma hora de atencion
# MAGIC --actualiza tambien el tiempo de espera a 0
# MAGIC UPDATE temp.age_citas_val_2 
# MAGIC SET HORA_LLEGADA_PACIENTE = HORA_INICIO_ATENCION, TIEMPO_ESPERA_MINUTOS = 0
# MAGIC WHERE TIEMPO_ESPERA_MINUTOS < 0

# COMMAND ----------

# MAGIC %sql
# MAGIC --Cant registros con tiempo negativo luego de imputacion
# MAGIC SELECT COUNT(*)
# MAGIC FROM temp.age_citas_val_2 
# MAGIC WHERE TIEMPO_ESPERA_MINUTOS < 0

# COMMAND ----------

# Crea df con datos desde HIVE limpios con tags qa
df_citas_final = spark.sql("SELECT * FROM temp.age_citas_val_2")
display(df_citas_final.limit(5))

# COMMAND ----------

# Idempotencia 
# ===============================

# Tabla Delta en Storage
path_tabla_cit = f"{storage_base_silver}/dataknow_project/entidades/age_citas"

# Valida si existe
if DeltaTable.isDeltaTable(spark, path_tabla_cit):
    
    # Obtiene en variables la fec_registro min y max para borrado del delta
    f_min = df_citas_final.select("FECHA_HORA_AGENDAMIENTO").agg({"FECHA_HORA_AGENDAMIENTO": "min"}).collect()[0][0]
    f_max = df_citas_final.select("FECHA_HORA_AGENDAMIENTO").agg({"FECHA_HORA_AGENDAMIENTO": "max"}).collect()[0][0]
    print(f_min)
    print(f_max)

    # Conexion a la tabla
    deltaTable_cit = DeltaTable.forPath(spark, path_tabla_cit)

    # Borra físicamente las filas en el rango de fechas
    deltaTable_cit.delete(
        (col("FECHA_HORA_AGENDAMIENTO") >= f_min) & (col("FECHA_HORA_AGENDAMIENTO") <= f_max)
    )

    print("se ejecuta el borrado en los datos para el periodo cargado")

else:
    print("No existe la tabla. No se realiza ninguna accion")

# COMMAND ----------

# Salida
# ================

# metadata corporativa
metadata_tabla = {
    "ingeniero_datos": "JOHN SANCHEZ",
    "owner": "PEDRO PEREZ",
    "sistema_origen": "SALUD_SERVICIOS_MEDICOS",
    "descripcion": "contiene el registro del agendamiento programado de atención a cada paciente"
}
# Convierte el diccionario a un String en formato JSON
metadata_json_str = json.dumps(metadata_tabla)

# Guarda tabla en Delta en storage con metadata personalizada
df_citas_final.write \
    .format("delta") \
    .mode("append") \
    .option("userMetadata", metadata_json_str) \
    .save(path_tabla_cit)

# COMMAND ----------

# Ver history de la tabla Delta
df_history = spark.sql(f"DESCRIBE HISTORY '{path_tabla_cit}'")
display(df_history)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Elimina esquema HIVE

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP DATABASE temp CASCADE;