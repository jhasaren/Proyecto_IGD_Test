# Databricks notebook source
# MAGIC %md
# MAGIC ### Procesamiento de Datos (Gold)
# MAGIC #### Prueba Ingeniería de Datos - Dataknow 
# MAGIC
# MAGIC En este script se aplica las reglas de negocio sobre los datos para construir el modelo de datos limpio.
# MAGIC
# MAGIC Escenario C: SALUD Y SERVICIOS MEDICOS<br />
# MAGIC Autor: John A. Sanchez | Fecha: 07/Jul/2026

# COMMAND ----------

# Reinicia el entorno de ejecucion
dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Importación de Librerías

# COMMAND ----------

# ============================================================
# Importa lib necesarias
# ============================================================
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, LongType, TimestampType
from pyspark.sql.functions import concat, lit, col, upper, date_format, floor, months_between, current_timestamp, when, array, array_remove, size, concat_ws, unix_timestamp
from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
import pytz
import json
from delta.tables import DeltaTable


# COMMAND ----------

# MAGIC %md
# MAGIC #### Parámetros

# COMMAND ----------

# ============================================================
# Parámetros de entorno
# ============================================================

# Zonas de almacenamiento
storage_base_silver = 'abfss://silver@dataknowdevdl.dfs.core.windows.net'
storage_base_gold = 'abfss://gold@dataknowdevdl.dfs.core.windows.net'

# Fecha Actual
tzInfo = pytz.timezone('America/Bogota')
fecha_calc = datetime.now(tz=tzInfo) - relativedelta(days=0)

fecha_hoy = fecha_calc.strftime("%Y-%m-%d")
fecha_hoy_anio = fecha_calc.strftime("%Y")
fecha_hoy_mes = fecha_calc.strftime("%m")
fecha_hoy_dia = fecha_calc.strftime("%d")

print("Hoy: ", fecha_hoy)
print("Anio: ", fecha_hoy_anio)
print("Mes: ", fecha_hoy_mes)
print("Dia: ", fecha_hoy_dia)


# COMMAND ----------

# MAGIC %md
# MAGIC #### Definición de Funciones

# COMMAND ----------

# Eliminar schema si existe
spark.sql("DROP SCHEMA IF EXISTS temp CASCADE")

# COMMAND ----------

# Crea schema en HIVE para uso transicional
spark.sql("CREATE SCHEMA IF NOT EXISTS temp")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Carga Entidades Silver

# COMMAND ----------

# =================================
# leer tablas delta desde storage (silver)
# =================================

# path delta de cada tabla
pais_path = f"{storage_base_silver}/dataknow_project/entidades/pais"
depto_path = f"{storage_base_silver}/dataknow_project/entidades/departamento"
ciudad_path = f"{storage_base_silver}/dataknow_project/entidades/ciudad"
eps_path = f"{storage_base_silver}/dataknow_project/entidades/eps"
red_sedes_path = f"{storage_base_silver}/dataknow_project/entidades/red_sedes"
pac_path = f"{storage_base_silver}/dataknow_project/entidades/pac_registro"
med_path = f"{storage_base_silver}/dataknow_project/entidades/med_planta"
hce_path = f"{storage_base_silver}/dataknow_project/entidades/hce_encuentros"
camas_path = f"{storage_base_silver}/dataknow_project/entidades/gcm_camas"
far_path = f"{storage_base_silver}/dataknow_project/entidades/far_dispensacion"
citas_path = f"{storage_base_silver}/dataknow_project/entidades/age_citas"

# **** Catálogos
df_pais_delta = spark.read.format("delta").load(pais_path)
df_depto_delta = spark.read.format("delta").load(depto_path)
df_ciudad_delta = spark.read.format("delta").load(ciudad_path)
df_eps_delta = spark.read.format("delta").load(eps_path)

# **** Maestros
df_red_sedes_delta = spark.read.format("delta").load(red_sedes_path)
df_pac_delta = spark.read.format("delta").load(pac_path)
df_med_delta = spark.read.format("delta").load(med_path)

# **** Transaccionales
df_hce_delta = spark.read.format("delta").load(hce_path)
df_camas_delta = spark.read.format("delta").load(camas_path)
df_far_delta = spark.read.format("delta").load(far_path)
df_citas_delta = spark.read.format("delta").load(citas_path)


# COMMAND ----------

# MAGIC %md
# MAGIC #### Construcción vistas (Gold)

# COMMAND ----------

# Crear tablas HIVE
df_pais_delta.write.mode("overwrite").saveAsTable("temp.pais")
df_depto_delta.write.mode("overwrite").saveAsTable("temp.departamento")
df_ciudad_delta.write.mode("overwrite").saveAsTable("temp.ciudad")
df_eps_delta.write.mode("overwrite").saveAsTable("temp.eps")
df_red_sedes_delta.write.mode("overwrite").saveAsTable("temp.red_sedes")
df_pac_delta.write.mode("overwrite").saveAsTable("temp.pac_registro")
df_med_delta.write.mode("overwrite").saveAsTable("temp.med_planta")
df_hce_delta.write.mode("overwrite").saveAsTable("temp.hce_encuentros")
df_camas_delta.write.mode("overwrite").saveAsTable("temp.cgm_camas")
df_far_delta.write.mode("overwrite").saveAsTable("temp.far_dispensacion")
df_citas_delta.write.mode("overwrite").saveAsTable("temp.age_citas")


# COMMAND ----------

# MAGIC %md
# MAGIC ##### dim_pacientes

# COMMAND ----------

# MAGIC %sql
# MAGIC --dim_pacientes
# MAGIC CREATE OR REPLACE TABLE temp.dim_pacientes AS
# MAGIC SELECT 
# MAGIC p.ID_PACIENTE,
# MAGIC p.TIPO_DOCUMENTO,
# MAGIC p.NUMERO_DOCUMENTO,
# MAGIC p.FECHA_NACIMIENTO,
# MAGIC p.GENERO,
# MAGIC p.ID_CIUDAD_RESIDENCIA,
# MAGIC p.TIPO_ASEGURADORA,
# MAGIC p.ID_EPS,
# MAGIC p.ESTRATO_SOCIOECONOMICO,
# MAGIC p.FECHA_PRIMER_ATENCION,
# MAGIC p.ACTIVO,
# MAGIC p.EDAD,
# MAGIC CASE 
# MAGIC     WHEN p.EDAD >= 0 AND p.EDAD <= 12 THEN '0-12'
# MAGIC     WHEN p.EDAD >= 13 AND p.EDAD <= 17 THEN '13-17'
# MAGIC     WHEN p.EDAD >= 18 AND p.EDAD <= 40 THEN '18-40'
# MAGIC     WHEN p.EDAD >= 41 AND p.EDAD <= 65 THEN '41-65'
# MAGIC ELSE '+65' END AS RANGO_EDAD
# MAGIC FROM temp.pac_registro p
# MAGIC WHERE ( p.QA_EDAD = 'OK' AND p.QA_VALIDACION_COMP = 'OK' )
# MAGIC --93000

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM temp.dim_pacientes
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %md
# MAGIC ##### dim_medicos

# COMMAND ----------

# MAGIC %sql
# MAGIC --dim_medicos
# MAGIC CREATE OR REPLACE TABLE temp.dim_medicos AS
# MAGIC SELECT 
# MAGIC m.ID_MEDICO,
# MAGIC m.ESPECIALIDAD_PRINCIPAL,
# MAGIC CASE
# MAGIC     WHEN m.ESPECIALIDAD_SECUNDARIA IS NULL THEN 'NO REGISTRA'
# MAGIC ELSE m.ESPECIALIDAD_SECUNDARIA END AS ESPECIALIDAD_SECUNDARIA,
# MAGIC CASE
# MAGIC     WHEN s.NOMBRE_SEDE IS NULL THEN 'SIN RESOLVER'
# MAGIC ELSE s.NOMBRE_SEDE END AS NOMBRE_SEDE,
# MAGIC CASE
# MAGIC     WHEN s.TIPO_SEDE IS NULL THEN 'SIN RESOLVER'
# MAGIC ELSE s.TIPO_SEDE END AS TIPO_SEDE,
# MAGIC m.FECHA_INGRESO,
# MAGIC datediff(year,m.FECHA_INGRESO,current_date()) AS ANIOS_EXPERIENCIA,
# MAGIC m.TIPO_CONTRATO,
# MAGIC CASE
# MAGIC     WHEN m.QA_JORNADA_LABORAL = 'ERROR' THEN 'NO REGISTRA'
# MAGIC ELSE m.JORNADA_LABORAL END AS JORNADA_LABORAL,
# MAGIC m.ESTADO_ACTIVO
# MAGIC FROM temp.med_planta m
# MAGIC LEFT JOIN (
# MAGIC     SELECT 
# MAGIC     s.ID_SEDE,
# MAGIC     s.NOMBRE_SEDE,
# MAGIC     s.TIPO_SEDE
# MAGIC     FROM temp.red_sedes s
# MAGIC     WHERE (s.QA_VALIDACION_REF = 'OK' AND s.QA_VALIDACION_COMP = 'OK' AND s.QA_VALIDACION_OPORT = 'OK')
# MAGIC ) s ON s.ID_SEDE = m.ID_SEDE
# MAGIC WHERE (m.QA_VALIDACION_REF = 'OK' AND m.QA_VALIDACION_COMP = 'OK' AND m.QA_VALIDACION_OPORT = 'OK')
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM temp.dim_medicos
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %md
# MAGIC ##### dim_ubicacion

# COMMAND ----------

# MAGIC %sql
# MAGIC --crea dim_ubicacion
# MAGIC CREATE OR REPLACE TABLE temp.dim_ubicacion AS
# MAGIC SELECT 
# MAGIC c.ID_CIUDAD,
# MAGIC c.NOMBRE_CIUDAD,
# MAGIC CASE 
# MAGIC     WHEN d.NOMBRE_DEPTO IS NULL THEN 'SIN RESOLVER'
# MAGIC ELSE d.NOMBRE_DEPTO END AS NOMBRE_DEPTO,
# MAGIC CASE 
# MAGIC     WHEN d.NOMBRE_PAIS IS NULL THEN 'SIN RESOLVER'
# MAGIC ELSE d.NOMBRE_PAIS END AS NOMBRE_PAIS
# MAGIC FROM temp.ciudad c
# MAGIC LEFT JOIN (
# MAGIC     --depto
# MAGIC     SELECT 
# MAGIC     d.ID_DEPTO,
# MAGIC     d.NOMBRE_DEPTO,
# MAGIC     CASE 
# MAGIC         WHEN p.NOMBRE_PAIS IS NULL THEN 'SIN RESOLVER'
# MAGIC     ELSE p.NOMBRE_PAIS END AS NOMBRE_PAIS
# MAGIC     FROM temp.departamento d
# MAGIC     LEFT JOIN (
# MAGIC         --pais
# MAGIC         SELECT 
# MAGIC         p.ID_PAIS,
# MAGIC         p.NOMBRE_PAIS
# MAGIC         FROM temp.pais p
# MAGIC         WHERE (p.QA_VALIDACION_COMP = 'OK' AND p.QA_VALIDACION_OPORT = 'OK')
# MAGIC     ) p ON p.ID_PAIS = d.ID_PAIS
# MAGIC     WHERE (d.QA_VALIDACION_REF = 'OK' AND d.QA_VALIDACION_COMP = 'OK' AND d.QA_VALIDACION_OPORT = 'OK')
# MAGIC ) d ON d.ID_DEPTO = c.ID_DEPTO
# MAGIC WHERE (c.QA_VALIDACION_REF = 'OK' AND c.QA_VALIDACION_COMP = 'OK' AND c.QA_VALIDACION_OPORT = 'OK')

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM temp.dim_ubicacion

# COMMAND ----------

# MAGIC %md
# MAGIC ##### dim_sedes

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE temp.dim_sedes AS 
# MAGIC SELECT 
# MAGIC s.ID_SEDE,
# MAGIC s.NOMBRE_SEDE,
# MAGIC s.TIPO_SEDE,
# MAGIC s.CIUDAD,
# MAGIC s.DEPARTAMENTO,
# MAGIC s.PAIS,
# MAGIC s.CAPACIDAD_CAMA_GENERAL,
# MAGIC s.CAPACIDAD_CAMA_UCI,
# MAGIC s.CAPACIDAD_CAMA_CIRUGIA,
# MAGIC s.CAPACIDAD_CAMA_URGENCIA,
# MAGIC s.CAPACIDAD_TOTAL_CAMAS,
# MAGIC ROUND(((s.CAPACIDAD_CAMA_UCI / s.CAPACIDAD_TOTAL_CAMAS) * 100),1) AS PORCENT_CAMAS_UCI,
# MAGIC s.NIVEL_COMPLEJIDAD
# MAGIC FROM (
# MAGIC     SELECT 
# MAGIC     s.ID_SEDE,
# MAGIC     s.NOMBRE_SEDE,
# MAGIC     s.TIPO_SEDE,
# MAGIC     u.NOMBRE_CIUDAD AS CIUDAD,
# MAGIC     u.NOMBRE_DEPTO AS DEPARTAMENTO,
# MAGIC     u.NOMBRE_PAIS AS PAIS,
# MAGIC     s.CAPACIDAD_CAMA_GENERAL,
# MAGIC     s.CAPACIDAD_CAMA_UCI,
# MAGIC     s.CAPACIDAD_CAMA_CIRUGIA,
# MAGIC     s.CAPACIDAD_CAMA_URGENCIA,
# MAGIC     (s.CAPACIDAD_CAMA_GENERAL+s.CAPACIDAD_CAMA_UCI+s.CAPACIDAD_CAMA_CIRUGIA+s.CAPACIDAD_CAMA_URGENCIA) AS CAPACIDAD_TOTAL_CAMAS,
# MAGIC     s.NIVEL_COMPLEJIDAD
# MAGIC     FROM temp.red_sedes s
# MAGIC     LEFT JOIN (
# MAGIC         SELECT 
# MAGIC         u.ID_CIUDAD, u.NOMBRE_CIUDAD, u.NOMBRE_DEPTO, u.NOMBRE_PAIS
# MAGIC         FROM temp.dim_ubicacion u
# MAGIC     ) u ON u.ID_CIUDAD = s.ID_CIUDAD
# MAGIC     WHERE (s.QA_VALIDACION_REF = 'OK' AND s.QA_VALIDACION_COMP = 'OK' AND s.QA_VALIDACION_OPORT = 'OK')
# MAGIC ) s

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM temp.dim_sedes
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %md
# MAGIC ##### fact_consultas

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE temp.fact_consultas AS
# MAGIC SELECT 
# MAGIC h.ID_ENCUENTRO,
# MAGIC h.ID_PACIENTE,
# MAGIC h.ID_MEDICO,
# MAGIC h.ID_SEDE,
# MAGIC h.FECHA_REGISTRO,
# MAGIC h.FECHA_INI_ATENCION,
# MAGIC h.FECHA_FIN_ATENCION,
# MAGIC h.TIEMPO_ESTADIA_HORAS,
# MAGIC h.TIPO_CONSULTA,
# MAGIC CASE 
# MAGIC     WHEN h.QA_VALIDACION_COMP = 'ERROR' THEN 'NO REGISTRADA'
# MAGIC ELSE h.ESPECIALIDAD_ATENDIDA END AS ESPECIALIDAD_ATENDIDA,
# MAGIC h.DIAGNOSTICO_PPAL_CIE10_ESTAND AS DIAGNOSTICO_PPAL_CIE10,
# MAGIC h.DIAGNOSTICO_SECUND_CIE10_ESTAND AS DIAGNOSTICO_SECUND_CIE10,
# MAGIC CASE 
# MAGIC     WHEN h.PROCEDIMIENTOS_CUPS = '' THEN 'SIN PROCEDIMIENTOS'
# MAGIC ELSE h.PROCEDIMIENTOS_CUPS END AS PROCEDIMIENTOS_CUPS,
# MAGIC h.VALOR_FACTURADO_USD,
# MAGIC h.ESTADO_FACTURA
# MAGIC FROM temp.hce_encuentros h
# MAGIC WHERE (h.QA_DIAGNOSTICO_PPAL_CIE10 = 'OK' AND h.QA_VALOR_FACTURADO_USD = 'OK')
# MAGIC --1989000

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM temp.fact_consultas
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %md
# MAGIC ##### fact_ocupacion_camas

# COMMAND ----------

# MAGIC %sql
# MAGIC --Crea tabla con rangos de criticidad
# MAGIC CREATE OR REPLACE TABLE temp.fact_ocupacion_camas_prev AS
# MAGIC SELECT 
# MAGIC c.ID_REGISTRO,
# MAGIC c.ID_SEDE,
# MAGIC c.TIPO_UNIDAD,
# MAGIC c.FECHA_HORA_REGISTRO,
# MAGIC c.NUMERO_CAMAS_OCUPADAS,
# MAGIC c.NUMERO_CAMAS_DISPONIBLES,
# MAGIC c.NUMERO_CAMAS_MANTENIMIENTO,
# MAGIC c.PORCEN_OCUPACION_CAMAS,
# MAGIC CASE 
# MAGIC     --CRITICIDAD UCI
# MAGIC     WHEN c.TIPO_UNIDAD = 'UCI' AND c.PORCEN_OCUPACION_CAMAS > 85.0 AND c.PORCEN_OCUPACION_CAMAS <= 100.0 THEN 'CRITICO'
# MAGIC     WHEN c.TIPO_UNIDAD = 'UCI' AND c.PORCEN_OCUPACION_CAMAS > 50.0 AND c.PORCEN_OCUPACION_CAMAS <= 85.0 THEN 'PRECAUCION'
# MAGIC     WHEN c.TIPO_UNIDAD = 'UCI' AND c.PORCEN_OCUPACION_CAMAS >= 0.0 AND c.PORCEN_OCUPACION_CAMAS <= 50.0 THEN 'NORMAL'
# MAGIC     --CRITICIDAD URGENCIAS
# MAGIC     WHEN c.TIPO_UNIDAD = 'URGENCIAS' AND c.PORCEN_OCUPACION_CAMAS > 90.0 AND c.PORCEN_OCUPACION_CAMAS <= 100.0 THEN 'CRITICO'
# MAGIC     WHEN c.TIPO_UNIDAD = 'URGENCIAS' AND c.PORCEN_OCUPACION_CAMAS > 50.0 AND c.PORCEN_OCUPACION_CAMAS <= 90.0 THEN 'PRECAUCION'
# MAGIC     WHEN c.TIPO_UNIDAD = 'URGENCIAS' AND c.PORCEN_OCUPACION_CAMAS >= 0.0 AND c.PORCEN_OCUPACION_CAMAS <= 50.0 THEN 'NORMAL'
# MAGIC     --CRITICIDAD GENERAL
# MAGIC     WHEN c.TIPO_UNIDAD = 'GENERAL' AND c.PORCEN_OCUPACION_CAMAS > 88.0 AND c.PORCEN_OCUPACION_CAMAS <= 100.0 THEN 'CRITICO'
# MAGIC     WHEN c.TIPO_UNIDAD = 'GENERAL' AND c.PORCEN_OCUPACION_CAMAS > 50.0 AND c.PORCEN_OCUPACION_CAMAS <= 88.0 THEN 'PRECAUCION'
# MAGIC     WHEN c.TIPO_UNIDAD = 'GENERAL' AND c.PORCEN_OCUPACION_CAMAS >= 0.0 AND c.PORCEN_OCUPACION_CAMAS <= 50.0 THEN 'NORMAL'
# MAGIC     --CIRUGIA NO TIENE CRITICIDAD
# MAGIC ELSE 'NA' END AS CLASIFICACION_ESTADO,
# MAGIC c.MOTIVO_INDISPONIBILIDAD
# MAGIC FROM (
# MAGIC     SELECT 
# MAGIC     c.ID_REGISTRO,
# MAGIC     c.ID_SEDE,
# MAGIC     c.TIPO_UNIDAD,
# MAGIC     c.FECHA_HORA_REGISTRO,
# MAGIC     c.NUMERO_CAMAS_OCUPADAS,
# MAGIC     c.NUMERO_CAMAS_DISPONIBLES,
# MAGIC     c.NUMERO_CAMAS_MANTENIMIENTO,
# MAGIC     ROUND(((c.NUMERO_CAMAS_OCUPADAS/(c.NUMERO_CAMAS_OCUPADAS+c.NUMERO_CAMAS_DISPONIBLES))*100),1) AS PORCEN_OCUPACION_CAMAS,
# MAGIC     c.MOTIVO_INDISPONIBILIDAD
# MAGIC     FROM temp.cgm_camas c
# MAGIC     --Nota: para el ejercicio a esta tabla no se le aplico ninguna regla de QA, por lo tanto no lleva exclusiones
# MAGIC ) c

# COMMAND ----------

# MAGIC %sql
# MAGIC --Crea tabla con ultimo registro reportado por sede, tipo_unidad y dia 
# MAGIC --Nota: se evidencia que una sede puede reportar hasta 3 veces en el mismo dia
# MAGIC CREATE OR REPLACE TABLE temp.fact_ocupacion_camas_last
# MAGIC SELECT * EXCEPT(rn)
# MAGIC FROM (
# MAGIC     SELECT *,
# MAGIC         ROW_NUMBER() OVER (
# MAGIC             PARTITION BY ID_SEDE, TIPO_UNIDAD, CAST(FECHA_HORA_REGISTRO AS DATE)
# MAGIC             ORDER BY FECHA_HORA_REGISTRO DESC
# MAGIC         ) AS rn
# MAGIC     FROM temp.fact_ocupacion_camas_prev
# MAGIC ) t
# MAGIC WHERE rn = 1

# COMMAND ----------

# MAGIC %sql
# MAGIC --Crea tabla final con agregacion
# MAGIC CREATE OR REPLACE TABLE temp.fact_ocupacion_camas_agg AS
# MAGIC SELECT * EXCEPT(CANT)
# MAGIC FROM (
# MAGIC     SELECT 
# MAGIC     c.ID_SEDE,
# MAGIC     c.TIPO_UNIDAD,
# MAGIC     CAST(c.FECHA_HORA_REGISTRO AS DATE) AS FECHA,
# MAGIC     c.NUMERO_CAMAS_OCUPADAS,
# MAGIC     c.NUMERO_CAMAS_DISPONIBLES,
# MAGIC     c.PORCEN_OCUPACION_CAMAS,
# MAGIC     c.CLASIFICACION_ESTADO,
# MAGIC     COUNT(*) AS CANT
# MAGIC     FROM temp.fact_ocupacion_camas_last c
# MAGIC     GROUP BY 
# MAGIC     c.ID_SEDE,
# MAGIC     c.TIPO_UNIDAD,
# MAGIC     CAST(c.FECHA_HORA_REGISTRO AS DATE),
# MAGIC     c.NUMERO_CAMAS_OCUPADAS,
# MAGIC     c.NUMERO_CAMAS_DISPONIBLES,
# MAGIC     c.PORCEN_OCUPACION_CAMAS,
# MAGIC     c.CLASIFICACION_ESTADO
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM temp.fact_ocupacion_camas_agg
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %md
# MAGIC ##### fact_tiempos_espera

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE temp.fact_tiempos_espera AS
# MAGIC SELECT 
# MAGIC a.ID_CITA,
# MAGIC a.ID_PACIENTE,
# MAGIC a.ID_MEDICO,
# MAGIC a.ID_SEDE,
# MAGIC a.FECHA_HORA_AGENDAMIENTO,
# MAGIC a.FECHA_CITA_PROGRAMADA,
# MAGIC a.HORA_CITA_PROGRAMADA,
# MAGIC a.HORA_LLEGADA_PACIENTE,
# MAGIC a.HORA_INICIO_ATENCION,
# MAGIC a.TIEMPO_ESPERA_MINUTOS,
# MAGIC a.ESPECIALIDAD_SOLICITADA,
# MAGIC a.TIPO_CITA,
# MAGIC a.ESTADO_CITA
# MAGIC FROM temp.age_citas a
# MAGIC WHERE (a.QA_HORA_INICIO_ATENCION = 'OK' AND a.QA_VALIDACION_COMP = 'OK')
# MAGIC AND a.ESTADO_CITA = 'ATENDIDA'
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM temp.fact_tiempos_espera
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %md
# MAGIC ##### fact_costos_atencion

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE temp.fact_costos_atencion_prev AS
# MAGIC --valor total atención
# MAGIC SELECT 
# MAGIC a.ID_ENCUENTRO,
# MAGIC a.TIPO_CONSULTA,
# MAGIC a.DIAGNOSTICO_PPAL_CIE10,
# MAGIC a.VALOR_FACTURADO_USD_CONSULTA,
# MAGIC a.VALOR_FACTURADO_USD_MEDICAMENTOS,
# MAGIC (a.VALOR_FACTURADO_USD_CONSULTA+a.VALOR_FACTURADO_USD_MEDICAMENTOS) AS VALOR_TOTAL_USD_ATENCION,
# MAGIC a.ESTADO_FACTURA
# MAGIC FROM (
# MAGIC     --valor consulta y valor medicamentos
# MAGIC     SELECT 
# MAGIC     c.ID_ENCUENTRO,
# MAGIC     c.TIPO_CONSULTA,
# MAGIC     c.DIAGNOSTICO_PPAL_CIE10,
# MAGIC     c.VALOR_FACTURADO_USD AS VALOR_FACTURADO_USD_CONSULTA,
# MAGIC     CASE 
# MAGIC         WHEN f.SUM_VR_TOTAL_DISP IS NULL THEN 0
# MAGIC     ELSE f.SUM_VR_TOTAL_DISP END AS VALOR_FACTURADO_USD_MEDICAMENTOS,
# MAGIC     c.ESTADO_FACTURA
# MAGIC     FROM temp.fact_consultas c
# MAGIC     LEFT JOIN (
# MAGIC         --costo facturado de dispensacion medicamentos
# MAGIC         SELECT 
# MAGIC         ID_ENCUENTRO,
# MAGIC         SUM(VR_TOTAL_DISP) AS SUM_VR_TOTAL_DISP
# MAGIC         FROM (
# MAGIC             --Calcula vr total por entrega de medicamento
# MAGIC             SELECT 
# MAGIC             f.ID_ENCUENTRO,
# MAGIC             f.CANTIDAD,
# MAGIC             f.VR_UNITARIO_USD,
# MAGIC             (f.CANTIDAD * f.VR_UNITARIO_USD) AS VR_TOTAL_DISP,
# MAGIC             f.TIPO_PRESCRIPCION
# MAGIC             FROM temp.far_dispensacion f
# MAGIC         )
# MAGIC         GROUP BY 
# MAGIC         ID_ENCUENTRO
# MAGIC     ) f ON f.ID_ENCUENTRO = c.ID_ENCUENTRO
# MAGIC ) a

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM temp.fact_costos_atencion_prev
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE temp.fact_costos_atencion_agg AS
# MAGIC --crea tabla agregado de fact_costos_atencion
# MAGIC SELECT 
# MAGIC f.DIAGNOSTICO_PPAL_CIE10,
# MAGIC f.TIPO_CONSULTA,
# MAGIC SUM(f.VALOR_TOTAL_USD_ATENCION) AS COSTO_TOTAL
# MAGIC FROM temp.fact_costos_atencion_prev f
# MAGIC GROUP BY 
# MAGIC f.DIAGNOSTICO_PPAL_CIE10,
# MAGIC f.TIPO_CONSULTA

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM temp.fact_costos_atencion_agg
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %md
# MAGIC ##### fact_alertas_epidemiologicas

# COMMAND ----------

# MAGIC %sql
# MAGIC --Cant consultas x dia, ubicacion y cie10 (CIE1O se asume solo capitulo medico -letra- para que en la agrupacion del ejercicio de alertas sea mas claro)
# MAGIC CREATE OR REPLACE TABLE temp.fact_alertas_epid_prev AS
# MAGIC SELECT 
# MAGIC h.CIUDAD,
# MAGIC h.DEPARTAMENTO,
# MAGIC h.PAIS,
# MAGIC CAST(h.FECHA_REGISTRO AS DATE) AS FECHA_REGISTRO,
# MAGIC SUBSTRING(h.DIAGNOSTICO_PPAL_CIE10, 1, 1) AS CAP_DIAGNOSTICO_PPAL_CIE10,
# MAGIC COUNT(*) AS CANTIDAD_CONSULTAS_DIA
# MAGIC FROM (
# MAGIC     --encuentros con ubicacion geografica (ciudad, depto, pais)
# MAGIC     SELECT 
# MAGIC     f.ID_ENCUENTRO,
# MAGIC     f.ID_SEDE,
# MAGIC     s.CIUDAD,
# MAGIC     s.DEPARTAMENTO,
# MAGIC     s.PAIS,
# MAGIC     f.FECHA_REGISTRO,
# MAGIC     f.DIAGNOSTICO_PPAL_CIE10
# MAGIC     FROM temp.fact_consultas f
# MAGIC     LEFT JOIN temp.dim_sedes s ON s.ID_SEDE = f.ID_SEDE
# MAGIC ) h
# MAGIC GROUP BY 
# MAGIC h.CIUDAD,
# MAGIC h.DEPARTAMENTO,
# MAGIC h.PAIS,
# MAGIC CAST(h.FECHA_REGISTRO AS DATE),
# MAGIC SUBSTRING(h.DIAGNOSTICO_PPAL_CIE10, 1, 1)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM temp.fact_alertas_epid_prev
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %sql
# MAGIC --Crea tabla con calculo promedio historico consultas - ult 8 semanas
# MAGIC CREATE OR REPLACE TABLE temp.fact_alertas_epid_prom AS 
# MAGIC SELECT
# MAGIC CIUDAD,
# MAGIC DEPARTAMENTO,
# MAGIC PAIS,
# MAGIC CAP_DIAGNOSTICO_PPAL_CIE10,
# MAGIC ROUND(AVG(CANTIDAD_CONSULTAS_DIA), 1) AS PROMEDIO_ULT_8_SEMANAS
# MAGIC FROM temp.fact_alertas_epid_prev
# MAGIC WHERE 
# MAGIC FECHA_REGISTRO >= ADD_MONTHS(CURRENT_DATE(), -2) --ultimos 2 meses (8 semanas)
# MAGIC GROUP BY
# MAGIC CIUDAD,
# MAGIC DEPARTAMENTO,
# MAGIC PAIS,
# MAGIC CAP_DIAGNOSTICO_PPAL_CIE10

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM temp.fact_alertas_epid_prom
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %sql
# MAGIC --Calcula promedio diario de los ultimos 5 dias por region y capitulo CIE10
# MAGIC CREATE OR REPLACE TABLE temp.fact_alertas_epid_actual AS 
# MAGIC SELECT
# MAGIC CIUDAD,
# MAGIC DEPARTAMENTO,
# MAGIC PAIS,
# MAGIC CAP_DIAGNOSTICO_PPAL_CIE10,
# MAGIC SUM(CANTIDAD_CONSULTAS_DIA) AS TOTAL_CONSULTAS_ULT_5_DIAS,
# MAGIC ROUND(AVG(CANTIDAD_CONSULTAS_DIA), 1) AS PROM_DIARIO_ULT_5_DIAS,
# MAGIC COUNT(DISTINCT FECHA_REGISTRO) AS DIAS_CON_CONSULTAS
# MAGIC FROM temp.fact_alertas_epid_prev
# MAGIC --WHERE FECHA_REGISTRO >= DATE_ADD(CURRENT_DATE(), -5) --ultimos 5 dias
# MAGIC WHERE FECHA_REGISTRO >= DATE_ADD('2026-07-05', -5) --ultimos 5 dias (se quema la fecha para el ejercicio -rango de datos cargado-)
# MAGIC GROUP BY
# MAGIC CIUDAD,
# MAGIC DEPARTAMENTO,
# MAGIC PAIS,
# MAGIC CAP_DIAGNOSTICO_PPAL_CIE10

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM temp.fact_alertas_epid_actual

# COMMAND ----------

# MAGIC %sql
# MAGIC --Tabla final con alertas de brote epidemiologico
# MAGIC --Regla: 
# MAGIC --alerta cuando el promedio diario de los ultimos 5 dias 
# MAGIC --supera en mas del 40% el promedio diario 
# MAGIC CREATE OR REPLACE TABLE temp.fact_alertas_epidemiologicas AS
# MAGIC SELECT
# MAGIC a.CIUDAD,
# MAGIC a.DEPARTAMENTO,
# MAGIC a.PAIS,
# MAGIC a.CAP_DIAGNOSTICO_PPAL_CIE10 AS CODIGO_CIE10,
# MAGIC CURRENT_DATE() AS FECHA_ALERTA, --fecha de generacion del reporte
# MAGIC a.PROM_DIARIO_ULT_5_DIAS AS VOLUMEN_ACTUAL_ULT_5_DIAS, --ult 5 dias
# MAGIC p.PROMEDIO_ULT_8_SEMANAS AS PROMEDIO_HISTORICO_ULT_8_SEM, --ult 8 semanas
# MAGIC ROUND(
# MAGIC     ((a.PROM_DIARIO_ULT_5_DIAS - p.PROMEDIO_ULT_8_SEMANAS)
# MAGIC     / p.PROMEDIO_ULT_8_SEMANAS) * 100
# MAGIC , 1) AS PORCENT_DESVIACION
# MAGIC FROM temp.fact_alertas_epid_actual a
# MAGIC INNER JOIN temp.fact_alertas_epid_prom p
# MAGIC ON (
# MAGIC     a.CIUDAD = p.CIUDAD AND 
# MAGIC     a.DEPARTAMENTO = p.DEPARTAMENTO AND 
# MAGIC     a.PAIS = p.PAIS AND 
# MAGIC     a.CAP_DIAGNOSTICO_PPAL_CIE10 = p.CAP_DIAGNOSTICO_PPAL_CIE10
# MAGIC     )
# MAGIC WHERE
# MAGIC -- Solo registros donde el volumen actual supera en >40% el promedio historico
# MAGIC a.PROM_DIARIO_ULT_5_DIAS > (p.PROMEDIO_ULT_8_SEMANAS * 1.4)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM temp.fact_alertas_epidemiologicas
# MAGIC ORDER BY PORCENT_DESVIACION DESC
# MAGIC
# MAGIC /*
# MAGIC Ej: En los últimos 5 días se están atendiendo un 70.0% más consultas por día de lo normal para el capitulo diagnostico CIE10 (K - enfermedades del aparato digestivo) en Tulua, valle
# MAGIC */

# COMMAND ----------

# MAGIC %md
# MAGIC ##### dim_complejidad_paciente

# COMMAND ----------

# MAGIC %sql
# MAGIC --cant diagnosticos por paciente
# MAGIC CREATE OR REPLACE TABLE temp.paciente_diagnosticos AS
# MAGIC SELECT 
# MAGIC ID_PACIENTE,
# MAGIC COLLECT_LIST(SUBSTRING(DIAGNOSTICO_PPAL_CIE10,1,1)) AS DIAGNOSTICOS, --Se obtiene solo capitulo -letra- para efectos del ejercicio
# MAGIC SIZE(COLLECT_LIST(SUBSTRING(DIAGNOSTICO_PPAL_CIE10,1,1))) AS CANT_DIAGNOSTICOS
# MAGIC FROM temp.fact_consultas
# MAGIC WHERE FECHA_REGISTRO >= ADD_MONTHS(current_date(), -12) --1 año atras
# MAGIC --AND ID_PACIENTE = '11748'
# MAGIC GROUP BY 
# MAGIC ID_PACIENTE

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM temp.paciente_diagnosticos

# COMMAND ----------

# MAGIC %sql
# MAGIC --crea tabla repeticion de diagnosticos por paciente
# MAGIC CREATE OR REPLACE TABLE temp.paciente_diagnosticos_cronicos AS
# MAGIC SELECT
# MAGIC ID_PACIENTE,
# MAGIC CAP_DIAGNOSTICO_CIE10,
# MAGIC COUNT(*) AS VECES_DIAGNOSTICADO
# MAGIC FROM (
# MAGIC     SELECT 
# MAGIC     ID_PACIENTE,
# MAGIC     SUBSTRING(DIAGNOSTICO_PPAL_CIE10,1,1) AS CAP_DIAGNOSTICO_CIE10 --Se obtiene solo capitulo -letra- para efectos del ejercicio
# MAGIC     FROM temp.fact_consultas
# MAGIC     WHERE FECHA_REGISTRO >= ADD_MONTHS(current_date(), -12) --1 año atras
# MAGIC )
# MAGIC --WHERE id_paciente = '11748'
# MAGIC GROUP BY 
# MAGIC ID_PACIENTE, CAP_DIAGNOSTICO_CIE10

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM temp.paciente_diagnosticos_cronicos
# MAGIC WHERE ID_PACIENTE = '11748'

# COMMAND ----------

# MAGIC %sql
# MAGIC --crea tabla con cant de diagnosticos citas y repeticion (cronico)
# MAGIC CREATE OR REPLACE TABLE temp.paciente_diagnosticos_cronico AS
# MAGIC SELECT 
# MAGIC d.ID_PACIENTE,
# MAGIC d.DIAGNOSTICOS,
# MAGIC d.CANT_DIAGNOSTICOS,
# MAGIC m.MAX_VECES_DIAGNOSTICO
# MAGIC FROM temp.paciente_diagnosticos d
# MAGIC LEFT JOIN (
# MAGIC     --max de diagnosticos recibidos (cronicos)
# MAGIC     SELECT 
# MAGIC     ID_PACIENTE,
# MAGIC     max(VECES_DIAGNOSTICADO) AS MAX_VECES_DIAGNOSTICO
# MAGIC     FROM temp.paciente_diagnosticos_cronicos
# MAGIC     --WHERE ID_PACIENTE = '11748'
# MAGIC     GROUP BY ID_PACIENTE
# MAGIC ) m ON m.ID_PACIENTE = d.ID_PACIENTE

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM temp.paciente_diagnosticos_cronico

# COMMAND ----------

# MAGIC %sql
# MAGIC --busca en el campo DIAGNOSTICOS si hay que inicien por C* (Oncologias)
# MAGIC CREATE OR REPLACE TABLE temp.paciente_diagnosticos_eval AS
# MAGIC SELECT 
# MAGIC ID_PACIENTE,
# MAGIC DIAGNOSTICOS,
# MAGIC CANT_DIAGNOSTICOS,
# MAGIC MAX_VECES_DIAGNOSTICO,
# MAGIC CASE 
# MAGIC     WHEN exists(DIAGNOSTICOS, x -> x LIKE 'C%') THEN 'S'
# MAGIC ELSE 'N' END AS DIAGNOSTICO_ONCOLOGIA --se utiliza CAP C del CIE10 para Oncologias
# MAGIC FROM temp.paciente_diagnosticos_cronico
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM temp.paciente_diagnosticos_eval
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %sql
# MAGIC --Crea tabla con clasificacion del perfil aplicando reglas de negocio
# MAGIC -- Reglas:
# MAGIC --Bajo (menos de 2 consultas al año y sin diagnósticos crónicos), 
# MAGIC --Moderado (2 a 5 consultas o un diagnóstico crónico), 
# MAGIC --Alto (más de 5 consultas o dos o más diagnósticos crónicos), y
# MAGIC --Muy Alto (hospitalizaciones o diagnósticos oncológicos en el ano). (CIE10 = C*)
# MAGIC CREATE OR REPLACE TABLE temp.dim_complejidad_paciente AS 
# MAGIC SELECT 
# MAGIC ID_PACIENTE,
# MAGIC DIAGNOSTICOS,
# MAGIC CANT_DIAGNOSTICOS,
# MAGIC MAX_VECES_DIAGNOSTICO,
# MAGIC DIAGNOSTICO_ONCOLOGIA,
# MAGIC CASE 
# MAGIC     WHEN DIAGNOSTICO_ONCOLOGIA = 'S' THEN 'MUY ALTO' --paciente oncologico (CIE10 = C*)
# MAGIC     WHEN CANT_DIAGNOSTICOS > 5 OR MAX_VECES_DIAGNOSTICO >= 3 THEN 'ALTO'
# MAGIC     WHEN (CANT_DIAGNOSTICOS >= 2 AND CANT_DIAGNOSTICOS <= 5) OR MAX_VECES_DIAGNOSTICO = 2 THEN 'MODERADO'
# MAGIC     WHEN CANT_DIAGNOSTICOS < 2 AND MAX_VECES_DIAGNOSTICO = 1 THEN 'BAJO'
# MAGIC ELSE 'SIN CLASIFICAR' END AS PERFIL_COMPLEJIDAD_PACIENTE
# MAGIC FROM temp.paciente_diagnosticos_eval
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC PERFIL_COMPLEJIDAD_PACIENTE,COUNT(*)
# MAGIC FROM temp.dim_complejidad_paciente
# MAGIC GROUP BY PERFIL_COMPLEJIDAD_PACIENTE

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM temp.dim_complejidad_paciente
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %md
# MAGIC #### Salida de datos (Gold)

# COMMAND ----------

# DBTITLE 1,dim_pacientes
# dim_pacientes
# ================

path_pacientes = f"{storage_base_gold}/dataknow_project/entidades/dim_pacientes"

# Crea df con datos desde HIVE
df_dim_pacientes = spark.sql("SELECT * FROM temp.dim_pacientes")

# metadata corporativa
metadata_tabla = {
    "ingeniero_datos": "JOHN SANCHEZ",
    "owner": "PEDRO PEREZ",
    "sistema_origen": "SALUD_SERVICIOS_MEDICOS",
    "descripcion": "vista dimensional de pacientes"
}
# Convierte el diccionario a un String en formato JSON
metadata_json_str = json.dumps(metadata_tabla)

# Guarda tabla en Delta en storage con metadata personalizada
df_dim_pacientes.write \
    .format("delta") \
    .mode("overwrite") \
    .option("userMetadata", metadata_json_str) \
    .save(path_pacientes)

# COMMAND ----------

# DBTITLE 1,dim_medicos
# dim_medicos
# ================

path_medicos = f"{storage_base_gold}/dataknow_project/entidades/dim_medicos"

# Crea df con datos desde HIVE
df_dim_medicos = spark.sql("SELECT * FROM temp.dim_medicos")

# metadata corporativa
metadata_tabla = {
    "ingeniero_datos": "JOHN SANCHEZ",
    "owner": "PEDRO PEREZ",
    "sistema_origen": "SALUD_SERVICIOS_MEDICOS",
    "descripcion": "vista dimensional de medicos"
}
# Convierte el diccionario a un String en formato JSON
metadata_json_str = json.dumps(metadata_tabla)

# Guarda tabla en Delta en storage con metadata personalizada
df_dim_medicos.write \
    .format("delta") \
    .mode("overwrite") \
    .option("userMetadata", metadata_json_str) \
    .save(path_medicos)

# COMMAND ----------

# DBTITLE 1,dim_ubicacion
# dim_ubicacion
# ================

path_ubicacion = f"{storage_base_gold}/dataknow_project/entidades/dim_ubicacion"

# Crea df con datos desde HIVE
df_dim_ubicacion = spark.sql("SELECT * FROM temp.dim_ubicacion")

# metadata corporativa
metadata_tabla = {
    "ingeniero_datos": "JOHN SANCHEZ",
    "owner": "PEDRO PEREZ",
    "sistema_origen": "SALUD_SERVICIOS_MEDICOS",
    "descripcion": "vista dimensional de ubicaciones geograficas"
}
# Convierte el diccionario a un String en formato JSON
metadata_json_str = json.dumps(metadata_tabla)

# Guarda tabla en Delta en storage con metadata personalizada
df_dim_ubicacion.write \
    .format("delta") \
    .mode("overwrite") \
    .option("userMetadata", metadata_json_str) \
    .save(path_ubicacion)

# COMMAND ----------

# DBTITLE 1,dim_sedes
# dim_sedes
# ================

path_sedes = f"{storage_base_gold}/dataknow_project/entidades/dim_sedes"

# Crea df con datos desde HIVE
df_dim_sedes = spark.sql("SELECT * FROM temp.dim_sedes")

# metadata corporativa
metadata_tabla = {
    "ingeniero_datos": "JOHN SANCHEZ",
    "owner": "PEDRO PEREZ",
    "sistema_origen": "SALUD_SERVICIOS_MEDICOS",
    "descripcion": "vista dimensional de sedes de atencion"
}
# Convierte el diccionario a un String en formato JSON
metadata_json_str = json.dumps(metadata_tabla)

# Guarda tabla en Delta en storage con metadata personalizada
df_dim_sedes.write \
    .format("delta") \
    .mode("overwrite") \
    .option("userMetadata", metadata_json_str) \
    .save(path_sedes)

# COMMAND ----------

# DBTITLE 1,fact_consultas
# fact_consultas
# ================

path_consultas = f"{storage_base_gold}/dataknow_project/entidades/fact_consultas"

# Crea df con datos desde HIVE
df_fact_consultas = spark.sql("SELECT * FROM temp.fact_consultas")

# metadata corporativa
metadata_tabla = {
    "ingeniero_datos": "JOHN SANCHEZ",
    "owner": "PEDRO PEREZ",
    "sistema_origen": "SALUD_SERVICIOS_MEDICOS",
    "descripcion": "vista de hechos de consultas"
}
# Convierte el diccionario a un String en formato JSON
metadata_json_str = json.dumps(metadata_tabla)

# Guarda tabla en Delta en storage con metadata personalizada
df_fact_consultas.write \
    .format("delta") \
    .mode("overwrite") \
    .option("userMetadata", metadata_json_str) \
    .save(path_consultas)

# COMMAND ----------

# DBTITLE 1,fact_ocupacion_camas
# fact_ocupacion_camas
# ================

path_camas = f"{storage_base_gold}/dataknow_project/entidades/fact_ocupacion_camas"

# Crea df con datos desde HIVE
df_fact_ocupacion_camas = spark.sql("SELECT * FROM temp.fact_ocupacion_camas_agg")

# metadata corporativa
metadata_tabla = {
    "ingeniero_datos": "JOHN SANCHEZ",
    "owner": "PEDRO PEREZ",
    "sistema_origen": "SALUD_SERVICIOS_MEDICOS",
    "descripcion": "vista de hechos de ocupacion de camas"
}
# Convierte el diccionario a un String en formato JSON
metadata_json_str = json.dumps(metadata_tabla)

# Guarda tabla en Delta en storage con metadata personalizada
df_fact_ocupacion_camas.write \
    .format("delta") \
    .mode("overwrite") \
    .option("userMetadata", metadata_json_str) \
    .save(path_camas)

# COMMAND ----------

# DBTITLE 1,fact_tiempos_espera
# fact_tiempos_espera
# ================

path_tiempos = f"{storage_base_gold}/dataknow_project/entidades/fact_tiempos_espera"

# Crea df con datos desde HIVE
df_fact_tiempos_espera = spark.sql("SELECT * FROM temp.fact_tiempos_espera")

# metadata corporativa
metadata_tabla = {
    "ingeniero_datos": "JOHN SANCHEZ",
    "owner": "PEDRO PEREZ",
    "sistema_origen": "SALUD_SERVICIOS_MEDICOS",
    "descripcion": "vista de hechos de tiempos de espera"
}
# Convierte el diccionario a un String en formato JSON
metadata_json_str = json.dumps(metadata_tabla)

# Guarda tabla en Delta en storage con metadata personalizada
df_fact_tiempos_espera.write \
    .format("delta") \
    .mode("overwrite") \
    .option("userMetadata", metadata_json_str) \
    .save(path_tiempos)

# COMMAND ----------

# DBTITLE 1,fact_costos_atencion
# fact_costos_atencion
# ================

path_costos = f"{storage_base_gold}/dataknow_project/entidades/fact_costos_atencion"

# Crea df con datos desde HIVE
df_fact_costos_atencion = spark.sql("SELECT * FROM temp.fact_costos_atencion_agg")

# metadata corporativa
metadata_tabla = {
    "ingeniero_datos": "JOHN SANCHEZ",
    "owner": "PEDRO PEREZ",
    "sistema_origen": "SALUD_SERVICIOS_MEDICOS",
    "descripcion": "vista de hechos de costos de atencion"
}
# Convierte el diccionario a un String en formato JSON
metadata_json_str = json.dumps(metadata_tabla)

# Guarda tabla en Delta en storage con metadata personalizada
df_fact_costos_atencion.write \
    .format("delta") \
    .mode("overwrite") \
    .option("userMetadata", metadata_json_str) \
    .save(path_costos)

# COMMAND ----------

# DBTITLE 1,fact_alertas_epidemiologicas
# fact_alertas_epidemiologicas
# ================

path_alertas = f"{storage_base_gold}/dataknow_project/entidades/fact_alertas_epidemiologicas"

# Crea df con datos desde HIVE
df_fact_alertas_epidemiologicas = spark.sql("SELECT * FROM temp.fact_alertas_epidemiologicas")

# metadata corporativa
metadata_tabla = {
    "ingeniero_datos": "JOHN SANCHEZ",
    "owner": "PEDRO PEREZ",
    "sistema_origen": "SALUD_SERVICIOS_MEDICOS",
    "descripcion": "vista de hechos de costos de alertas epidemiologicas"
}
# Convierte el diccionario a un String en formato JSON
metadata_json_str = json.dumps(metadata_tabla)

# Guarda tabla en Delta en storage con metadata personalizada
df_fact_alertas_epidemiologicas.write \
    .format("delta") \
    .mode("overwrite") \
    .option("userMetadata", metadata_json_str) \
    .save(path_alertas)

# COMMAND ----------

# DBTITLE 1,dim_complejidad_paciente
# dim_complejidad_paciente
# ================

path_perfil = f"{storage_base_gold}/dataknow_project/entidades/dim_complejidad_paciente"

# Crea df con datos desde HIVE
df_dim_complejidad_paciente = spark.sql("SELECT * FROM temp.dim_complejidad_paciente")

# metadata corporativa
metadata_tabla = {
    "ingeniero_datos": "JOHN SANCHEZ",
    "owner": "PEDRO PEREZ",
    "sistema_origen": "SALUD_SERVICIOS_MEDICOS",
    "descripcion": "vista de dimension del perfil del paciente segun complejidad"
}
# Convierte el diccionario a un String en formato JSON
metadata_json_str = json.dumps(metadata_tabla)

# Guarda tabla en Delta en storage con metadata personalizada
df_dim_complejidad_paciente.write \
    .format("delta") \
    .mode("overwrite") \
    .option("userMetadata", metadata_json_str) \
    .save(path_perfil)

# COMMAND ----------

# DBTITLE 1,validacion cant registros gold
# Carga tablas delta desde Gold
df_pacientes = spark.read.format("delta").load(path_pacientes)
df_medicos = spark.read.format("delta").load(path_medicos)
df_ubicacion = spark.read.format("delta").load(path_ubicacion)
df_sedes = spark.read.format("delta").load(path_sedes)
df_consultas = spark.read.format("delta").load(path_consultas)
df_camas = spark.read.format("delta").load(path_camas)
df_tiempos = spark.read.format("delta").load(path_tiempos)
df_costos = spark.read.format("delta").load(path_costos)
df_alertas = spark.read.format("delta").load(path_alertas)
df_perfil = spark.read.format("delta").load(path_perfil)

print('dim_pacientes: ',df_pacientes.count())
print('dim_medicos: ',df_medicos.count())
print('dim_ubicacion: ',df_ubicacion.count())
print('dim_sedes: ',df_sedes.count())
print('fact_consultas: ',df_consultas.count())
print('fact_ocupacion_camas: ',df_camas.count())
print('fact_tiempos_espera: ',df_tiempos.count())
print('fact_costos_atencion: ',df_costos.count())
print('fact_alertas_epidemiologicas: ',df_alertas.count())
print('dim_complejidad_paciente: ',df_perfil.count())

# COMMAND ----------

# MAGIC %md
# MAGIC #### Eliminar esquema HIVE (temporal)

# COMMAND ----------

# Eliminar schema si existe
spark.sql("DROP SCHEMA IF EXISTS temp CASCADE")