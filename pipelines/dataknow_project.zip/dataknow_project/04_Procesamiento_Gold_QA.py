# Databricks notebook source
# DBTITLE 1,Encabezado
# MAGIC %md
# MAGIC ### Evaluaciones de Calidad (Gold)
# MAGIC #### Prueba Ingeniería de Datos - Dataknow 
# MAGIC
# MAGIC En este script se realizan una serie de evaluaciones de calidad sobre las entidades creadas en Gold. Se reutiliza clase de validaciones preparada para ejecuciones genéricas.
# MAGIC
# MAGIC Escenario C: SALUD Y SERVICIOS MEDICOS<br />
# MAGIC Autor: John A. Sanchez | Fecha: 08/Jul/2026

# COMMAND ----------

# Reinicia el entorno de ejecucion
dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Importación de Librerías

# COMMAND ----------

# ============================================================
# Importa lib necesarias
# ============================================================
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, LongType, TimestampType
from pyspark.sql.functions import concat, lit, col, upper, date_format, floor, months_between, current_timestamp, when, array, array_remove, size, concat_ws, unix_timestamp
from pyspark.sql.functions import count as spark_count
from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
import pytz
import json
from delta.tables import DeltaTable


# COMMAND ----------

# MAGIC %md
# MAGIC #### Parámetros

# COMMAND ----------

# ============================================================
# Parámetros de entorno
# ============================================================

# Zonas
storage_base_silver = 'abfss://silver@dataknowdevdl.dfs.core.windows.net'
storage_base_gold = 'abfss://gold@dataknowdevdl.dfs.core.windows.net'

# Fecha Actual
tzInfo = pytz.timezone('America/Bogota')
fecha_calc = datetime.now(tz=tzInfo) - relativedelta(days=0)

fecha_hoy = fecha_calc.strftime("%Y-%m-%d")
fecha_hoy_anio = fecha_calc.strftime("%Y")
fecha_hoy_mes = fecha_calc.strftime("%m")
fecha_hoy_dia = fecha_calc.strftime("%d")

print("Hoy: ", fecha_hoy)
print("Anio: ", fecha_hoy_anio)
print("Mes: ", fecha_hoy_mes)
print("Dia: ", fecha_hoy_dia)


# COMMAND ----------

# Nota: se omite el uso de widget de fecha. No es necesario en las evaluaciones implementadas en esta capa gold.

# # Widgets para parametrizar el periodo de validación
# dbutils.widgets.text("fecha_inicio", "", "Fecha Inicio (YYYY-MM-DD)")
# dbutils.widgets.text("fecha_fin", "", "Fecha Fin (YYYY-MM-DD)")

# # Resolver parámetros Widgets
# fecha_inicio = dbutils.widgets.get("fecha_inicio").strip()
# fecha_fin = dbutils.widgets.get("fecha_fin").strip()

# # Si no se especifican fechas (NA o vacío), calcula fechas de últimos 5 días
# if fecha_inicio in ('NA', '') or fecha_fin in ('NA', ''):
#     ahora = datetime.now(tz=tzInfo)
#     fecha_fin = (ahora - timedelta(days=1)).strftime("%Y-%m-%d 23:59:59")
#     fecha_inicio = (ahora - timedelta(days=5)).strftime("%Y-%m-%d 00:00:00")
# else:
#     # ============================================================
#     # Validación de fechas explícitas
#     # Fuerza fallo del pipeline si parámetros son inválidos
#     # ============================================================
#     # --- fecha_inicio ---
#     try:
#         _dt_inicio = datetime.strptime(fecha_inicio, '%Y-%m-%d')
#     except ValueError:
#         raise ValueError(
#             f"[QA - Parámetros] 'fecha_inicio' inválida: '{fecha_inicio}'. "
#             f"Formato esperado: YYYY-MM-DD"
#         )
#     # comparacion de campo formateado vs original
#     if _dt_inicio.strftime('%Y-%m-%d') != fecha_inicio:
#         raise ValueError(
#             f"[QA - Parámetros] 'fecha_inicio' con formato incorrecto: '{fecha_inicio}'. "
#             f"Mes y día deben tener dos dígitos - esperado: {_dt_inicio.strftime('%Y-%m-%d')}"
#         )

#     # --- fecha_fin ---
#     try:
#         _dt_fin = datetime.strptime(fecha_fin, '%Y-%m-%d')
#     except ValueError:
#         raise ValueError(
#             f"[QA - Parámetros] 'fecha_fin' inválida: '{fecha_fin}'. "
#             f"Formato esperado: YYYY-MM-DD"
#         )
#     # comparacion de campo formateado vs original
#     if _dt_fin.strftime('%Y-%m-%d') != fecha_fin:
#         raise ValueError(
#             f"[QA - Parámetros] 'fecha_fin' con formato incorrecto: '{fecha_fin}'. "
#             f"Mes y día deben tener dos dígitos - esperado: {_dt_fin.strftime('%Y-%m-%d')}"
#         )

#     if _dt_inicio > _dt_fin:
#         raise ValueError(
#             f"[QA - Parámetros] fecha_inicio ({fecha_inicio}) no puede ser "
#             f"mayor que fecha_fin ({fecha_fin})."
#         )

#     fecha_inicio = f"{fecha_inicio} 00:00:00"
#     fecha_fin    = f"{fecha_fin} 23:59:59"

# print(f"Período: {fecha_inicio} -> {fecha_fin}")

# COMMAND ----------

# ============================================================
# ID de ejecución QA: único por sesión (formato: yyyyMMdd_HHmmss)
# Se genera una sola vez y se reutiliza en todos los registros
# ============================================================
id_ejecucion = datetime.now(tz=tzInfo).strftime("%Y%m%d_%H%M%S")
print(id_ejecucion)


# COMMAND ----------

# MAGIC %md
# MAGIC #### Definición de Funciones

# COMMAND ----------

# MAGIC %md
# MAGIC Reutilización de clase base para evaluación de QA

# COMMAND ----------

# DBTITLE 1,Clase base de QA
class DataQAEngineer:
    """
    Clase: DataQAEngineer
    Autor: John A. Sanchez
    Versión: 1.0
    Fecha: 02/Dic/2025

    Descripción:
        Clase utilitaria para realizar evaluaciones de calidad de datos sobre entidades Silver y Gold.
        Implementa funciones para validar integridad referencial, completitud,exactitud, oportunidad y registrar resultados QA.

    Métodos:
        - check_integridad_referencial: Valida si los valores de un campo en df_eval existen en df_dim.
        - check_completitud: Valida que los campos obligatorios o criticos no tengan valores nulos.
        - check_oportunidad: Valida la frescura del dato por registro (row-level). Para tablas maestro/catálogo de carga full.
        - check_oportunidad_transaccional: Valida la oportunidad de tablas transaccionales (carga incremental). Obtiene el MAX del campo de fecha y lo evalúa contra el timestamp actual. Retorna un DataFrame de UNA FILA.
        - registrar_resultado_qa: Registra el resultado de una validación en el DataFrame Maestro de QA.
        - check_unicidad: Valida que una o varias columnas clave no presenten duplicados en una dimensión Gold.
        - check_huerfanos_fact: Valida que una FK de un hecho Gold tenga correspondencia en la dimensión Gold referenciada.
        - check_exactitud_derivada: Valida reglas de exactitud sobre columnas derivadas o calculadas en entidades Gold.
    """

    # ============================================================
    # Función: check_integridad_referencial
    # Valida si los valores de un campo en df_eval existen en df_dim.
    # Utiliza left join: los registros sin match quedan con clave nula.
    # Retorna df_eval con la columna QA_VALIDACION_REF agregada.
    # ============================================================
    def check_integridad_referencial(df_eval, df_dim, col_eval, col_dim=None, nombre_dim="dimension"):
        """
        Valida la integridad referencial entre un DataFrame evaluado y una dimensión.

        Parámetros:
            df_eval   : DataFrame a evaluar (hechos, transaccional u otra entidad)
            df_dim    : DataFrame dimensional de referencia
            col_eval  : Campo en df_eval que referencia la dimensión
            col_dim   : Campo llave en df_dim (si es None, usa col_eval)
            nombre_dim: Nombre descriptivo de la dimensión para el mensaje de error

        Retorna:
            DataFrame con columna 'QA_VALIDACION_REF':
                'OK'          -> el valor existe en la dimensión
                'ERROR: ...'  -> el valor no fue encontrado en la dimensión
        """
        if col_dim is None:
            col_dim = col_eval

        df_keys = df_dim.select(col(col_dim).alias("ref_key")).distinct()
        df_joined = df_eval.join(df_keys, df_eval[col_eval] == col("ref_key"), "left")
        df_result = df_joined.withColumn(
            "QA_VALIDACION_REF",
            when(
                col("ref_key").isNull(),
                concat(
                    lit(f"ERROR: {col_eval}='"),
                    col(col_eval).cast("string"),
                    lit(f"' no existe en [{nombre_dim}]")
                )
            ).otherwise(lit("OK"))
        ).drop("ref_key")
        return df_result

    # ============================================================
    # Función: check_completitud
    # Valida que los campos obligatorios no tengan valores nulos.
    # Retorna df_eval con la columna QA_VALIDACION_COMP agregada.
    # ============================================================
    def check_completitud(df_eval, cols_obligatorias):
        """
        Valida que las columnas obligatorias no contengan valores nulos.

        Parámetros:
            df_eval           : DataFrame a evaluar
            cols_obligatorias : Lista de columnas que no deben ser nulas

        Retorna:
            DataFrame con columna 'QA_VALIDACION_COMP':
                'OK'         -> ningún campo obligatorio es nulo
                'ERROR: ...' -> lista de campos que contienen valor nulo
        """
        flags = array(*[
            when(col(c).isNull(), lit(c)).otherwise(lit(""))
            for c in cols_obligatorias
        ])
        campos_nulos = array_remove(flags, "")
        df_result = df_eval.withColumn(
            "QA_VALIDACION_COMP",
            when(
                size(campos_nulos) > 0,
                concat(
                    lit("ERROR: campos nulos: ["),
                    concat_ws(", ", campos_nulos),
                    lit("]")
                )
            ).otherwise(lit("OK"))
        )
        return df_result

    # ============================================================
    # Función: check_oportunidad_maestro
    # Valida la frescura del dato comparando un campo de fecha
    # contra el timestamp actual. Si la diferencia supera el
    # umbral en horas, el registro se marca como ERROR.
    # ============================================================
    def check_oportunidad_maestro(df_eval, col_fecha, umbral_horas=48):
        """
        Valida la oportunidad/frescura del dato por registro.

        Parámetros:
            df_eval      : DataFrame a evaluar
            col_fecha    : Campo de fecha/timestamp a evaluar
            umbral_horas : Umbral máximo de antigüedad en horas (default: 48)

        Retorna:
            DataFrame con columna 'QA_VALIDACION_OPORT':
                'OK'         -> dato dentro del umbral de frescura
                'ERROR: ...' -> dato supera el umbral definido
        """
        horas_diff = (
            unix_timestamp(current_timestamp()) - unix_timestamp(col(col_fecha))
        ) / 3600
        df_result = df_eval.withColumn(
            "QA_VALIDACION_OPORT",
            when(
                col(col_fecha).isNull(),
                lit(f"ERROR: [{col_fecha}] es nulo - no se puede evaluar oportunidad")
            ).when(
                horas_diff > umbral_horas,
                concat(
                    lit(f"ERROR: [{col_fecha}] supera umbral de {umbral_horas}h - desactualizado hace "),
                    horas_diff.cast("integer").cast("string"),
                    lit(" horas")
                )
            ).otherwise(lit("OK"))
        )
        return df_result

    # ============================================================
    # Función: check_oportunidad_transaccional
    # Para tablas con carga incremental (delta). Obtiene el MAX
    # del campo de fecha y lo evalúa contra el timestamp actual.
    # Retorna un DataFrame de UNA FILA con el resultado global.
    # No evalúa fila a fila — evita falsos positivos en registros
    # históricos de tablas con múltiples valores de fecha.
    # ============================================================
    def check_oportunidad_transaccional(df_eval, col_fecha, umbral_horas=48):
        """
        Valida la oportunidad de tablas transaccionales con carga incremental.

        A diferencia de check_oportunidad (row-level), evalúa el MAX del campo
        de fecha de toda la tabla y retorna un DataFrame de UNA SOLA FILA con
        el veredicto global. Si el MAX supera el umbral, la tabla entera falla.

        Se usa cuando la tabla tiene múltiples valores en col_fecha (carga delta),
        donde evaluar fila a fila generaría falsos positivos en registros históricos.

        Parámetros:
            df_eval      : DataFrame transaccional a evaluar
            col_fecha    : Campo de fecha/timestamp para calcular el MAX
            umbral_horas : Umbral máximo de antigüedad en horas (default: 48)

        Retorna:
            DataFrame de UNA FILA con columna 'QA_VALIDACION_OPORT':
                'OK'         -> MAX(col_fecha) dentro del umbral
                'ERROR: ...' -> MAX(col_fecha) supera el umbral, con detalle
                               de fecha y tiempo transcurrido
        """
        from pyspark.sql.functions import max as spark_max

        row = df_eval.agg(
            spark_max(unix_timestamp(col(col_fecha))).alias("max_ts"),
            spark_max(col(col_fecha)).alias("max_fecha")
        ).first()

        if row["max_ts"] is None:
            qa_val = f"ERROR: [{col_fecha}] sin valores válidos - tabla vacía o campo completamente nulo"
        else:
            horas_diff    = (datetime.now(tz=tzInfo).timestamp() - row["max_ts"]) / 3600
            max_fecha_str = row["max_fecha"].strftime("%Y-%m-%d %H:%M")

            if horas_diff > umbral_horas:
                dias       = int(horas_diff // 24)
                horas_rem  = int(horas_diff % 24)
                tiempo_str = f"{dias}d {horas_rem}h" if dias > 0 else f"{int(horas_diff)}h"
                qa_val = (
                    f"ERROR: MAX [{col_fecha}]={max_fecha_str} - "
                    f"desactualizado hace {tiempo_str} (umbral: {umbral_horas}h)"
                )
            else:
                qa_val = "OK"

        return spark.createDataFrame([{"QA_VALIDACION_OPORT": qa_val}])

    # ============================================================
    # Función: check_unicidad
    # Valida que la llave de negocio no tenga registros duplicados.
    # Retorna df_eval con la columna QA_VALIDACION_UNIC agregada.
    # ============================================================
    def check_unicidad(df_eval, cols_clave):
        """
        Valida que una o varias columnas clave no presenten duplicados.

        Parámetros:
            df_eval    : DataFrame a evaluar
            cols_clave : Lista de columnas que conforman la llave de unicidad

        Retorna:
            DataFrame con columna 'QA_VALIDACION_UNIC':
                'OK'         -> la llave es única en el DataFrame
                'ERROR: ...' -> la llave presenta duplicados
        """
        from pyspark.sql.functions import count as spark_count

        # Calcular llaves duplicadas
        df_dup = df_eval.groupBy(*cols_clave) \
            .agg(spark_count(lit(1)).alias("dup_count")) \
            .filter(col("dup_count") > 1)

        # Renombrar columnas clave en df_dup para evitar AMBIGUOUS_REFERENCE en el join
        # (df_eval y df_dup compartian los mismos nombres de columna)
        df_dup_ren = df_dup
        for c in cols_clave:
            df_dup_ren = df_dup_ren.withColumnRenamed(c, f"_dup_{c}")

        # Condicion de join usando nombres sin colision
        cond_join = None
        for c in cols_clave:
            new_cond = df_eval[c].eqNullSafe(df_dup_ren[f"_dup_{c}"])
            cond_join = new_cond if cond_join is None else (cond_join & new_cond)

        # Referencia explícita al lado izquierdo del join para evitar ambigüedad
        llave_valor = concat_ws(
            ", ",
            *[when(df_eval[c].isNull(), lit("NULL")).otherwise(df_eval[c].cast("string")) for c in cols_clave]
        )

        df_result = df_eval.join(df_dup_ren, cond_join, "left").withColumn(
            "QA_VALIDACION_UNIC",
            when(
                col("dup_count").isNotNull(),
                concat(
                    lit(f"ERROR: llave duplicada [{', '.join(cols_clave)}]=("),
                    llave_valor,
                    lit(") - "),
                    col("dup_count").cast("string"),
                    lit(" registros")
                )
            ).otherwise(lit("OK"))
        )

        # Eliminar columnas temporales del join
        for c in cols_clave:
            df_result = df_result.drop(f"_dup_{c}")
        df_result = df_result.drop("dup_count")

        return df_result

    # ============================================================
    # Función: check_huerfanos_fact
    # Valida que los valores de una FK en un hecho Gold existan
    # en la dimensión Gold correspondiente.
    # Retorna df_eval con la columna QA_HUERFANO_FACT agregada.
    # ============================================================
    def check_huerfanos_fact(df_eval, df_dim, col_eval, col_dim=None, nombre_dim="dimension"):
        """
        Valida que una llave foránea de una tabla de hechos Gold
        tenga correspondencia en la dimensión Gold referenciada.

        A diferencia de check_integridad_referencial (Silver), trabaja
        sobre el modelo dimensional Gold ya ensamblado: detecta registros
        de hechos cuyos identificadores no existen en las dimensiones Gold,
        consecuencia del filtrado de calidad aplicado en Silver.

        Parámetros:
            df_eval    : DataFrame de hechos Gold a evaluar
            df_dim     : DataFrame de la dimensión Gold de referencia
            col_eval   : Columna FK en el hecho
            col_dim    : Columna PK en la dimensión (si None, usa col_eval)
            nombre_dim : Nombre descriptivo de la dimensión Gold

        Retorna:
            DataFrame con columna 'QA_HUERFANO_FACT':
                'OK'         -> FK existe en la dimensión Gold
                'ERROR: ...' -> FK sin correspondencia en la dimensión Gold
        """
        if col_dim is None:
            col_dim = col_eval

        df_keys = df_dim.select(col(col_dim).alias("dim_key")).distinct()
        df_joined = df_eval.join(df_keys, df_eval[col_eval] == col("dim_key"), "left")
        df_result = df_joined.withColumn(
            "QA_HUERFANO_FACT",
            when(
                col("dim_key").isNull(),
                concat(
                    lit(f"ERROR: {col_eval}='"),
                    col(col_eval).cast("string"),
                    lit(f"' sin correspondencia en [{nombre_dim}] Gold")
                )
            ).otherwise(lit("OK"))
        ).drop("dim_key")
        return df_result

    # ============================================================
    # Función: check_exactitud_derivada
    # Valida reglas de exactitud en columnas derivadas/calculadas.
    # Retorna df_eval con una nueva columna QA_<nombre_regla>.
    # ============================================================
    def check_exactitud_derivada(df_eval, nombre_regla, condicion_error, mensaje_error):
        """
        Valida una regla de exactitud sobre una columna derivada o calculada
        en entidades Gold.

        Parámetros:
            df_eval         : DataFrame a evaluar
            nombre_regla    : Sufijo del nombre de la columna QA a crear
            condicion_error : Expresión booleana Spark; True indica error
            mensaje_error   : Mensaje descriptivo cuando la fila incumple la regla

        Retorna:
            DataFrame con columna QA_<nombre_regla>:
                'OK'         -> la fila cumple la regla derivada
                'ERROR: ...' -> la fila incumple la regla derivada
        """
        col_qa = f"QA_{nombre_regla}"
        df_result = df_eval.withColumn(
            col_qa,
            when(condicion_error, lit(f"ERROR: {mensaje_error}")).otherwise(lit("OK"))
        )
        return df_result

    # ============================================================
    # Función: registrar_resultado_qa
    # Evalúa un df con columna _qa_validation y agrega una fila
    # de resumen al DataFrame Maestro global (df_master_qa).
    # ============================================================
    def registrar_resultado_qa(df_eval, tabla, categoria, descripcion="", zona="silver", col_qa="_qa_validation", es_tabla_nivel=False):
        """
        Registra el resultado de una validación en el DataFrame Maestro de QA.

        Parámetros:
            df_eval   : DataFrame evaluado con columna col_qa
            tabla     : Nombre descriptivo de la tabla/entidad evaluada
            categoria : Categoría ISO 25012 (usar constantes QA_*)
            descripcion: Descripción legible de la validación realizada
            zona      : Capa evaluada - 'silver' o 'gold' (default: 'silver')
            col_qa         : Campo de validación en df_eval (default: '_qa_validation')
            es_tabla_nivel : True cuando el df es un resumen de 1 fila (e.g. check_oportunidad_transaccional).
                             El campo col_qa se usa como mensaje directo en 'resultado' del maestro.

        Efecto:
            Actualiza df_master_qa global con una nueva fila de resultado.
        """
        global df_master_qa
        total   = df_eval.count()
        errores = df_eval.filter(col(col_qa) != "OK").count()
        if es_tabla_nivel:
            # Validación a nivel de tabla (check_oportunidad_transaccional u otro check de 1 fila)
            # El campo col_qa ya contiene el mensaje descriptivo del resultado
            qa_val    = df_eval.select(col(col_qa)).first()[0]
            estado    = "PASS" if errores == 0 else "FAIL"
            resultado = "Sin inconsistencias - verificación a nivel de tabla" if errores == 0 else qa_val
        elif errores == 0:
            resultado = f"Sin inconsistencias - {total} registros evaluados"
            estado    = "PASS"
        else:
            conformes = total - errores
            pct_error = round((errores / total) * 100, 1) if total > 0 else 0
            resultado = f"{errores} de {total} registros con error ({pct_error}%) - {conformes} conformes"
            estado    = "FAIL"
        nueva_fila = spark.createDataFrame(
            [(id_ejecucion, zona, tabla, categoria, descripcion, total, errores, resultado, estado,
            datetime.now(tz=tzInfo))],
            _SCHEMA_MASTER_QA
        )
        df_master_qa = df_master_qa.union(nueva_fila)


# COMMAND ----------

# ============================================================
# Inicialización: Schema, Categorías ISO y Maestro QA
# ============================================================

# Definicion Categorías de Calidad de Datos — ISO 25012
QA_COMPLETITUD = "completitud" # Valores nulos o faltantes en campos obligatorios
QA_CONSISTENCIA = "consistencia" # Integridad referencial, formatos, reglas de negocio
QA_EXACTITUD = "exactitud" # Valores fuera de dominio o rango permitido
QA_UNICIDAD = "unicidad" # Registros duplicados
QA_OPORTUNIDAD = "oportunidad" # Frescura / vigencia del dato

# Definición esquema tabla maestro QA
_SCHEMA_MASTER_QA = StructType([
    StructField("ID_EJECUCION", StringType(), False),  # Identificador único de la ejecución
    StructField("ZONA_EVALUADA", StringType(), False),  # silver / gold
    StructField("TABLA_EVALUADA", StringType(), False),  # Nombre de la entidad evaluada
    StructField("CATEGORIA_CALIDAD", StringType(), False),  # Categoría ISO 25012
    StructField("DESCRIPCION", StringType(), False),  # Descripción de la validación realizada
    StructField("TOTAL_REGISTROS", LongType(), False),  # Total de registros evaluados
    StructField("REGISTROS_ERROR", LongType(), False),  # Registros que no pasaron la validación
    StructField("RESULTADO", StringType(), False),  # Descripción breve del resultado
    StructField("ESTADO", StringType(), False),  # PASS / FAIL
    StructField("F_REGISTRO", TimestampType(), False),  # Timestamp del registro
])

# DataFrame Maestro acumulador - inicia vacío con el schema definido
df_master_qa = spark.createDataFrame([], _SCHEMA_MASTER_QA)


# COMMAND ----------

# DBTITLE 1,Carga entidades Gold
# MAGIC %md
# MAGIC #### Carga Entidades Gold

# COMMAND ----------

# =================================
# leer tablas delta desde storage gold
# =================================

# path delta de cada tabla
pacientes_path = f"{storage_base_gold}/dataknow_project/entidades/dim_pacientes"
medicos_path = f"{storage_base_gold}/dataknow_project/entidades/dim_medicos"
sedes_path = f"{storage_base_gold}/dataknow_project/entidades/dim_sedes"
fact_consultas_path = f"{storage_base_gold}/dataknow_project/entidades/fact_consultas"
fact_tiempos_path = f"{storage_base_gold}/dataknow_project/entidades/fact_tiempos_espera"

# lee tablas delta desde gold
df_dim_pacientes = spark.read.format("delta").load(pacientes_path)
df_dim_medicos = spark.read.format("delta").load(medicos_path)
df_dim_sedes = spark.read.format("delta").load(sedes_path)
df_fact_consultas = spark.read.format("delta").load(fact_consultas_path)
df_fact_tiempos = spark.read.format("delta").load(fact_tiempos_path)


# COMMAND ----------

# DBTITLE 1,Sección: Validaciones de Calidad de Datos
# MAGIC %md
# MAGIC #### Validaciones de Calidad de Datos (Gold)

# COMMAND ----------

# DBTITLE 1,Regla 1 unicidad
# MAGIC %md
# MAGIC ##### 1. Unicidad de llaves en dimensiones

# COMMAND ----------

# ============================================================
# Prueba: Unicidad de llaves en dimensiones Gold (no duplicados)
# ============================================================

# ID_PACIENTE en dim_pacientes
df_dim_pacientes_qa = DataQAEngineer.check_unicidad(
    df_eval = df_dim_pacientes,
    cols_clave = ["ID_PACIENTE"]
)

DataQAEngineer.registrar_resultado_qa(
    df_dim_pacientes_qa,
    tabla="dim_pacientes",
    categoria=QA_UNICIDAD,
    descripcion="unicidad de llave de negocio ['ID_PACIENTE']",
    zona="gold",
    col_qa="QA_VALIDACION_UNIC"
)


# ID_MEDICO en dim_medicos
df_dim_medicos_qa = DataQAEngineer.check_unicidad(
    df_eval = df_dim_medicos,
    cols_clave = ["ID_MEDICO"]
)

DataQAEngineer.registrar_resultado_qa(
    df_dim_medicos_qa,
    tabla="dim_medicos",
    categoria=QA_UNICIDAD,
    descripcion="unicidad de llave de negocio ['ID_MEDICO']",
    zona="gold",
    col_qa="QA_VALIDACION_UNIC"
)


# ID_SEDE en dim_sedes
df_dim_sedes_qa = DataQAEngineer.check_unicidad(
    df_eval = df_dim_sedes,
    cols_clave = ["ID_SEDE"]
)

DataQAEngineer.registrar_resultado_qa(
    df_dim_sedes_qa,
    tabla="dim_sedes",
    categoria=QA_UNICIDAD,
    descripcion="unicidad de llave de negocio ['ID_SEDE']",
    zona="gold",
    col_qa="QA_VALIDACION_UNIC"
)


# COMMAND ----------

# DBTITLE 1,Regla 2 huérfanos
# MAGIC %md
# MAGIC ##### 2. Consistencia - Huérfanos en tablas de hechos

# COMMAND ----------

# MAGIC %md
# MAGIC fact_consultas

# COMMAND ----------

# ============================================================
# Prueba: Huérfanos en fact_consultas vs dimensiones Gold
# ============================================================

# ID_PACIENTE -> dim_pacientes
df_check = DataQAEngineer.check_huerfanos_fact(
    df_eval    = df_fact_consultas,
    df_dim     = df_dim_pacientes,
    col_eval   = "ID_PACIENTE",
    nombre_dim = "dim_pacientes"
)

DataQAEngineer.registrar_resultado_qa(
    df_check,
    tabla       = "fact_consultas",
    categoria   = QA_CONSISTENCIA,
    descripcion = "huerfanos: ID_PACIENTE sin match en dim_pacientes Gold",
    zona        = "gold",
    col_qa      = "QA_HUERFANO_FACT"
)

# ID_MEDICO -> dim_medicos
df_check = DataQAEngineer.check_huerfanos_fact(
    df_eval    = df_fact_consultas,
    df_dim     = df_dim_medicos,
    col_eval   = "ID_MEDICO",
    nombre_dim = "dim_medicos"
)

DataQAEngineer.registrar_resultado_qa(
    df_check,
    tabla       = "fact_consultas",
    categoria   = QA_CONSISTENCIA,
    descripcion = "huerfanos: ID_MEDICO sin match en dim_medicos Gold",
    zona        = "gold",
    col_qa      = "QA_HUERFANO_FACT"
)

# ID_SEDE -> dim_sedes
df_check = DataQAEngineer.check_huerfanos_fact(
    df_eval    = df_fact_consultas,
    df_dim     = df_dim_sedes,
    col_eval   = "ID_SEDE",
    nombre_dim = "dim_sedes"
)

DataQAEngineer.registrar_resultado_qa(
    df_check,
    tabla       = "fact_consultas",
    categoria   = QA_CONSISTENCIA,
    descripcion = "huerfanos: ID_SEDE sin match en dim_sedes Gold",
    zona        = "gold",
    col_qa      = "QA_HUERFANO_FACT"
)


# COMMAND ----------

# MAGIC %md
# MAGIC fact_tiempos_espera

# COMMAND ----------

# ============================================================
# Prueba: Huérfanos en fact_tiempos_espera vs dimensiones Gold
# ============================================================

# ID_PACIENTE -> dim_pacientes
df_check = DataQAEngineer.check_huerfanos_fact(
    df_eval    = df_fact_tiempos,
    df_dim     = df_dim_pacientes,
    col_eval   = "ID_PACIENTE",
    nombre_dim = "dim_pacientes"
)

DataQAEngineer.registrar_resultado_qa(
    df_check,
    tabla       = "fact_tiempos_espera",
    categoria   = QA_CONSISTENCIA,
    descripcion = "huerfanos: ID_PACIENTE sin match en dim_pacientes Gold",
    zona        = "gold",
    col_qa      = "QA_HUERFANO_FACT"
)

# ID_MEDICO -> dim_medicos
df_check = DataQAEngineer.check_huerfanos_fact(
    df_eval    = df_fact_tiempos,
    df_dim     = df_dim_medicos,
    col_eval   = "ID_MEDICO",
    nombre_dim = "dim_medicos"
)

DataQAEngineer.registrar_resultado_qa(
    df_check,
    tabla       = "fact_tiempos_espera",
    categoria   = QA_CONSISTENCIA,
    descripcion = "huerfanos: ID_MEDICO sin match en dim_medicos Gold",
    zona        = "gold",
    col_qa      = "QA_HUERFANO_FACT"
)

# ID_SEDE -> dim_sedes
df_check = DataQAEngineer.check_huerfanos_fact(
    df_eval    = df_fact_tiempos,
    df_dim     = df_dim_sedes,
    col_eval   = "ID_SEDE",
    nombre_dim = "dim_sedes"
)

DataQAEngineer.registrar_resultado_qa(
    df_check,
    tabla       = "fact_tiempos_espera",
    categoria   = QA_CONSISTENCIA,
    descripcion = "huerfanos: ID_SEDE sin match en dim_sedes Gold",
    zona        = "gold",
    col_qa      = "QA_HUERFANO_FACT"
)


# COMMAND ----------

# DBTITLE 1,Regla 3 exactitud derivada
# MAGIC %md
# MAGIC ##### 3. Exactitud - Columnas derivadas y calculadas

# COMMAND ----------

# ============================================================
# Prueba: Exactitud de columnas derivadas/calculadas en Gold
# ============================================================

# dim_pacientes: RANGO_EDAD debe corresponder con EDAD
cond_error = (
    ((col("EDAD") >= 0) & (col("EDAD") <= 12) & (col("RANGO_EDAD") != "0-12")) |
    ((col("EDAD") >= 13) & (col("EDAD") <= 17) & (col("RANGO_EDAD") != "13-17")) |
    ((col("EDAD") >= 18) & (col("EDAD") <= 40) & (col("RANGO_EDAD") != "18-40")) |
    ((col("EDAD") >= 41) & (col("EDAD") <= 65) & (col("RANGO_EDAD") != "41-65")) |
    ((col("EDAD") > 65) & (col("RANGO_EDAD") != "65+")) |
    col("EDAD").isNull() |
    col("RANGO_EDAD").isNull()
)
df_dim_pacientes_exac = DataQAEngineer.check_exactitud_derivada(
    df_eval = df_dim_pacientes,
    nombre_regla = "RANGO_EDAD",
    condicion_error = cond_error,
    mensaje_error = "RANGO_EDAD no corresponde con EDAD"
)
DataQAEngineer.registrar_resultado_qa(
    df_dim_pacientes_exac,
    tabla = "dim_pacientes",
    categoria = QA_EXACTITUD,
    descripcion = "exactitud derivada: correspondencia entre EDAD y RANGO_EDAD",
    zona = "gold",
    col_qa = "QA_RANGO_EDAD"
)

# dim_medicos: ANIOS_EXPERIENCIA no puede ser negativo y debe ser coherente con FECHA_INGRESO
cond_error = (
    col("ANIOS_EXPERIENCIA").isNull() |
    col("FECHA_INGRESO").isNull() |
    (col("ANIOS_EXPERIENCIA") < 0)
)
df_dim_medicos_exac = DataQAEngineer.check_exactitud_derivada(
    df_eval = df_dim_medicos,
    nombre_regla = "ANIOS_EXPERIENCIA",
    condicion_error = cond_error,
    mensaje_error = "ANIOS_EXPERIENCIA invalido o inconsistente con FECHA_INGRESO"
)
DataQAEngineer.registrar_resultado_qa(
    df_dim_medicos_exac,
    tabla = "dim_medicos",
    categoria = QA_EXACTITUD,
    descripcion = "exactitud derivada: ANIOS_EXPERIENCIA no negativo y coherente con FECHA_INGRESO",
    zona = "gold",
    col_qa = "QA_ANIOS_EXPERIENCIA"
)

# dim_sedes: CAPACIDAD_TOTAL_CAMAS debe ser suma exacta de sus componentes
cond_error = (
    col("CAPACIDAD_TOTAL_CAMAS").isNull() |
    col("CAPACIDAD_CAMA_GENERAL").isNull() |
    col("CAPACIDAD_CAMA_UCI").isNull() |
    col("CAPACIDAD_CAMA_CIRUGIA").isNull() |
    col("CAPACIDAD_CAMA_URGENCIA").isNull() |
    (
        col("CAPACIDAD_TOTAL_CAMAS") != (
            col("CAPACIDAD_CAMA_GENERAL") +
            col("CAPACIDAD_CAMA_UCI") +
            col("CAPACIDAD_CAMA_CIRUGIA") +
            col("CAPACIDAD_CAMA_URGENCIA")
        )
    )
)
df_dim_sedes_total_exac = DataQAEngineer.check_exactitud_derivada(
    df_eval = df_dim_sedes,
    nombre_regla = "CAPACIDAD_TOTAL_CAMAS",
    condicion_error = cond_error,
    mensaje_error = "CAPACIDAD_TOTAL_CAMAS no corresponde a la suma de capacidades por tipo"
)
DataQAEngineer.registrar_resultado_qa(
    df_dim_sedes_total_exac,
    tabla = "dim_sedes",
    categoria = QA_EXACTITUD,
    descripcion = "exactitud derivada: suma de capacidades igual a CAPACIDAD_TOTAL_CAMAS",
    zona = "gold",
    col_qa = "QA_CAPACIDAD_TOTAL_CAMAS"
)

# dim_sedes: PORCENT_CAMAS_UCI debe estar entre 0 y 100
cond_error = (
    col("PORCENT_CAMAS_UCI").isNull() |
    col("CAPACIDAD_CAMA_UCI").isNull() |
    col("CAPACIDAD_TOTAL_CAMAS").isNull() |
    (col("CAPACIDAD_TOTAL_CAMAS") <= 0) |
    (col("PORCENT_CAMAS_UCI") < 0) |
    (col("PORCENT_CAMAS_UCI") > 100)
)
df_dim_sedes_pct_exac = DataQAEngineer.check_exactitud_derivada(
    df_eval = df_dim_sedes,
    nombre_regla = "PORCENT_CAMAS_UCI",
    condicion_error = cond_error,
    mensaje_error = "PORCENT_CAMAS_UCI fuera de rango"
)
DataQAEngineer.registrar_resultado_qa(
    df_dim_sedes_pct_exac,
    tabla = "dim_sedes",
    categoria = QA_EXACTITUD,
    descripcion = "exactitud derivada: rango de PORCENT_CAMAS_UCI",
    zona = "gold",
    col_qa = "QA_PORCENT_CAMAS_UCI"
)


# COMMAND ----------

# Reporte Maestro de QA
display(df_master_qa)

# COMMAND ----------

# DBTITLE 1,Sección: Persistencia Maestro QA
# MAGIC %md
# MAGIC #### Persistencia del Maestro QA
# MAGIC Escritura en Delta con modo append - cada ejecución acumula su resultado en el histórico.

# COMMAND ----------

# DBTITLE 1,Persistencia y log de ejecución
# ============================================================
# Resumen de la ejecución actual
# ============================================================

SEP = "=" * 65
SEP2 = "-" * 65

n_exec_total = df_master_qa.count()
n_exec_pass  = df_master_qa.filter(col("ESTADO") == "PASS").count()
n_exec_fail  = df_master_qa.filter(col("ESTADO") == "FAIL").count()

print(f"\n{SEP}")
print(f"  REPORTE DE EJECUCION QA")
print(f"  ID Ejecucion : {id_ejecucion}")
print(f"  Zona         : gold")
print(f"  Fecha / Hora : {datetime.now(tz=tzInfo).strftime('%Y-%m-%d %H:%M:%S')}")
print(f"{SEP}")
print(f"  Total validaciones ejecutadas : {n_exec_total}")
print(f"  PASS                          : {n_exec_pass}")
print(f"  FAIL                          : {n_exec_fail}")
print(f"{SEP}")
print(f"  DETALLE POR VALIDACION")
print(f"{SEP}")

for row in df_master_qa.orderBy("CATEGORIA_CALIDAD", "TABLA_EVALUADA").collect():
    estado_label = "PASS" if row["ESTADO"] == "PASS" else "FAIL <<"
    print(f"\n  [{estado_label}]  {row['TABLA_EVALUADA']} | {row['CATEGORIA_CALIDAD']}")
    print(f"  {SEP2}")
    print(f"  Descripcion : {row['DESCRIPCION']}")
    print(f"  Resultado   : {row['RESULTADO']}")
    print(f"  Registros   : total={row['TOTAL_REGISTROS']}  errores={row['REGISTROS_ERROR']}")
    print(f"  Timestamp   : {row['F_REGISTRO']}")

print(f"\n{SEP}\n")

# ============================================================
# Persistencia del Maestro QA en tabla Delta
# Modo APPEND: cada ejecución agrega sus filas al histórico.
# ============================================================

path_maestro_qa = f"{storage_base_silver}/dataknow_project/qa/maestro_qa"

(
    df_master_qa
    .write
    .format("delta")
    .mode("append")
    .save(path_maestro_qa)
)

print(f"Maestro QA persistido en: {path_maestro_qa}\n")
